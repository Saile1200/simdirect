'use strict';
/* SimDirect — plan de vuelo + mapa en vivo conectado a MSFS 2024 */

const $ = (s) => document.querySelector(s);
const NM_R = 3440.065;
const toRad = (d) => d * Math.PI / 180;
const toDeg = (r) => r * 180 / Math.PI;
const uid = () => Math.random().toString(36).slice(2, 9);
const esc = (s) => String(s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

function distNm(a, b) {
  const dLat = toRad(b.lat - a.lat), dLon = toRad(b.lon - a.lon);
  const h = Math.sin(dLat / 2) ** 2 + Math.cos(toRad(a.lat)) * Math.cos(toRad(b.lat)) * Math.sin(dLon / 2) ** 2;
  return 2 * NM_R * Math.asin(Math.min(1, Math.sqrt(h)));
}
function bearing(a, b) {
  const y = Math.sin(toRad(b.lon - a.lon)) * Math.cos(toRad(b.lat));
  const x = Math.cos(toRad(a.lat)) * Math.sin(toRad(b.lat)) - Math.sin(toRad(a.lat)) * Math.cos(toRad(b.lat)) * Math.cos(toRad(b.lon - a.lon));
  return (toDeg(Math.atan2(y, x)) + 360) % 360;
}
const fmtAlt = (a) => (a >= 18000 ? 'FL' + String(Math.round(a / 100)).padStart(3, '0') : Math.round(a).toLocaleString('es-ES') + ' ft');
const fmtTime = (h) => { if (!isFinite(h) || h < 0) return '—'; const m = Math.round(h * 60); return `${Math.floor(m / 60)}h ${String(m % 60).padStart(2, '0')}m`; };
const fmtNm = (d) => (d < 10 ? d.toFixed(1) : Math.round(d).toLocaleString('es-ES')) + ' nm';
const fmtCrs = (c) => String(Math.round(c) % 360).padStart(3, '0') + '°';

function toast(msg, ms = 2600) {
  const t = $('#toast'); t.textContent = msg; t.classList.add('show');
  clearTimeout(toast._t); toast._t = setTimeout(() => t.classList.remove('show'), ms);
}
function store(key, val) { try { if (val === undefined) return JSON.parse(localStorage.getItem(key)); localStorage.setItem(key, JSON.stringify(val)); } catch (e) { return null; } }

/* ------------------------------------------------------------------ estado */
function apt(code) { const a = AIRPORTS[code]; return a ? { code, name: a.name, lat: a.lat, lon: a.lon, elev: a.elev } : null; }
function newPlan() { return { name: 'Nuevo plan', dep: null, arr: null, cruiseAlt: 35000, aircraftId: 'a320', waypoints: [] }; }
function examplePlan() {
  const p = newPlan();
  p.name = 'LEBL-LEMD'; p.dep = apt('LEBL'); p.arr = apt('LEMD');
  p.waypoints = [
    { id: uid(), name: 'WP1', lat: 41.42, lon: 1.35, alt: 0 },
    { id: uid(), name: 'WP2', lat: 41.30, lon: 0.10, alt: 0 },
    { id: uid(), name: 'WP3', lat: 41.00, lon: -1.40, alt: 0 },
    { id: uid(), name: 'WP4', lat: 40.70, lon: -2.60, alt: 0 },
  ];
  return p;
}
let plan = store('simdirect.draft') || examplePlan();
if (!plan.waypoints) plan = examplePlan();
let live = null, liveMode = 'offline', follow = false, placing = null, serverOk = false;
let trail = [];

const aircraft = () => AIRCRAFT.find((a) => a.id === plan.aircraftId) || AIRCRAFT[0];
// sirve para todos los aviones: solo distinguimos avión de línea o avioneta
const isGA = () => ['c172', 'tbm9'].includes(plan.aircraftId) || (plan.aircraftId === 'sim' && (aircraft().cruiseTas || 0) < 200);
document.querySelectorAll('#acMode button').forEach((b) => b.onclick = () => {
  plan.aircraftId = b.dataset.mode === 'ga' ? 'c172' : 'a320';
  plan.cruiseAlt = aircraft().cruiseAlt; fillForm(); autoAltitudes(); render();
});

function routePoints() {
  const p = [];
  if (plan.dep) p.push({ name: plan.dep.code, lat: plan.dep.lat, lon: plan.dep.lon, alt: plan.dep.elev || 0, kind: 'dep' });
  plan.waypoints.forEach((w, i) => p.push({ ...w, kind: 'wp', idx: i }));
  if (plan.arr) p.push({ name: plan.arr.code, lat: plan.arr.lat, lon: plan.arr.lon, alt: plan.arr.elev || 0, kind: 'arr' });
  return p;
}
function computeRoute() {
  const pts = routePoints(), legs = [], cum = [0];
  for (let i = 1; i < pts.length; i++) {
    const d = distNm(pts[i - 1], pts[i]);
    legs.push({ d, crs: bearing(pts[i - 1], pts[i]) });
    cum.push(cum[i - 1] + d);
  }
  return { pts, legs, cum, total: cum[cum.length - 1] || 0 };
}
function estimates(r) {
  const ac = aircraft(), cruise = plan.cruiseAlt;
  const depE = plan.dep ? plan.dep.elev || 0 : (r.pts[0] ? r.pts[0].alt : 0);
  const arrE = plan.arr ? plan.arr.elev || 0 : (r.pts.length ? r.pts[r.pts.length - 1].alt : 0);
  let climbD = Math.max(0, (cruise - depE) / ac.climbFtNm), descD = Math.max(0, (cruise - arrE) / ac.descFtNm);
  if (climbD + descD > r.total && climbD + descD > 0) { const f = r.total / (climbD + descD); climbD *= f; descD *= f; }
  const cruiseD = Math.max(0, r.total - climbD - descD);
  const time = (climbD + descD) / (ac.cruiseTas * 0.72) + cruiseD / ac.cruiseTas;
  const fuel = time * ac.burnKgH, reserve = 0.75 * ac.burnKgH;
  return { climbD, descD, cruiseD, time, fuel, reserve, todDist: r.total - descD, depE, arrE };
}
function idealAlt(along, r, est) {
  const ac = aircraft();
  return Math.min(plan.cruiseAlt, est.depE + along * ac.climbFtNm, est.arrE + (r.total - along) * ac.descFtNm);
}
function roundAlt(a) { return a >= 18000 ? Math.round(a / 1000) * 1000 : Math.round(a / 500) * 500; }
function autoAltitudes(onlyId) {
  const r = computeRoute(), est = estimates(r);
  r.pts.forEach((p, i) => {
    if (p.kind !== 'wp') return;
    const w = plan.waypoints[p.idx];
    if (!onlyId || w.id === onlyId) w.alt = roundAlt(idealAlt(r.cum[i], r, est));
  });
}
function pointAt(r, d) {
  for (let i = 0; i < r.legs.length; i++) {
    if (d <= r.cum[i + 1] || i === r.legs.length - 1) {
      const t = r.legs[i].d ? Math.max(0, Math.min(1, (d - r.cum[i]) / r.legs[i].d)) : 0;
      const a = r.pts[i], b = r.pts[i + 1];
      return { lat: a.lat + (b.lat - a.lat) * t, lon: a.lon + (b.lon - a.lon) * t };
    }
  }
  return null;
}
/* Proyecta la posición del avión sobre la ruta: tramo, distancia recorrida y desvío lateral */
function progress(r, pos) {
  if (!pos || r.pts.length < 2) return null;
  let best = null;
  for (let i = 0; i < r.legs.length; i++) {
    const a = r.pts[i], b = r.pts[i + 1], k = Math.cos(toRad(a.lat));
    const bx = (b.lon - a.lon) * k * 60, by = (b.lat - a.lat) * 60;
    const px = (pos.lon - a.lon) * k * 60, py = (pos.lat - a.lat) * 60;
    const L2 = bx * bx + by * by;
    const t = L2 ? Math.max(0, Math.min(1, (px * bx + py * by) / L2)) : 0;
    const xtk = Math.hypot(px - t * bx, py - t * by);
    if (!best || xtk < best.xtk - 0.01) best = { leg: i, t, xtk };
  }
  const along = r.cum[best.leg] + best.t * r.legs[best.leg].d;
  let next = best.leg + 1;
  if (best.t > 0.995 && next < r.pts.length - 1) next++;
  return { ...best, along, next, distNext: distNm(pos, r.pts[next]), remaining: Math.max(0, r.total - along) };
}

/* ------------------------------------------------------------------ mapa */
const WORLD = L.latLngBounds([[-85, -180], [85, 180]]);
const map = L.map('map', { zoomControl: true, worldCopyJump: false, minZoom: 2, maxBounds: WORLD, maxBoundsViscosity: 1.0 }).setView([40.4, -2.5], 6);
/* un solo mundo: el mapa no se repite y no puedes salirte */
const _tl = L.tileLayer;
L.tileLayer = (url, o) => _tl(url, Object.assign({ noWrap: true, bounds: WORLD }, o || {}));
/* si la ventana se abre escondida detrás de MSFS el mapa mide 0 px y se quedaba en gris:
   se recalcula al aparecer, al cambiar de tamaño y al volver a la ventana */
const fitMinZoom = () => {
  const s = map.getSize(); if (!s.x || !s.y) return;
  const z = map.getBoundsZoom(WORLD, true);
  map.setMinZoom(isFinite(z) ? Math.max(2, Math.min(4, Math.ceil(z))) : 2);
};
const refreshMap = () => { map.invalidateSize(false); fitMinZoom(); };
map.on('resize', fitMinZoom);
addEventListener('focus', refreshMap);
document.addEventListener('visibilitychange', () => { if (!document.hidden) setTimeout(refreshMap, 100); });
try { new ResizeObserver(refreshMap).observe(document.getElementById('map')); } catch (e) { /* */ }
setTimeout(refreshMap, 50); setTimeout(refreshMap, 1500);
map.attributionControl.setPrefix(false);
const esriImg = () => L.tileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}', { maxZoom: 19, maxNativeZoom: 18, attribution: '© Esri, Maxar, Earthstar' });
const esriLabels = () => L.tileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/Reference/World_Boundaries_and_Places/MapServer/tile/{z}/{y}/{x}', { maxZoom: 19, maxNativeZoom: 18 });
const esriRoads = () => L.tileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/Reference/World_Transportation/MapServer/tile/{z}/{y}/{x}', { maxZoom: 19, maxNativeZoom: 18, opacity: .55 });
const baseLayers = {
  'Satélite + nombres': L.layerGroup([esriImg(), esriRoads(), esriLabels()]),
  'Satélite': esriImg(),
  'Oscuro (aviación)': L.layerGroup([L.tileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/Canvas/World_Dark_Gray_Base/MapServer/tile/{z}/{y}/{x}', { maxZoom: 19, maxNativeZoom: 16, attribution: '© Esri' }), L.tileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/Canvas/World_Dark_Gray_Reference/MapServer/tile/{z}/{y}/{x}', { maxZoom: 19, maxNativeZoom: 16 })]),
  'Calles': L.tileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/World_Street_Map/MapServer/tile/{z}/{y}/{x}', { maxZoom: 19, attribution: '© Esri' }),
  'Relieve': L.tileLayer('https://{s}.tile.opentopomap.org/{z}/{x}/{y}.png', { maxZoom: 17, attribution: '© OpenStreetMap © OpenTopoMap' }),
  'Topográfico': L.tileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/World_Topo_Map/MapServer/tile/{z}/{y}/{x}', { maxZoom: 19, attribution: '© Esri' }),
  'OpenStreetMap': L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', { maxZoom: 19, attribution: '© OpenStreetMap' }),
};
const layerCtl = L.control.layers(baseLayers, null, { position: 'topleft' }).addTo(map);
const savedLayer = store('simdirect.layer');
(baseLayers[savedLayer] || baseLayers['Satélite + nombres']).addTo(map);
map.on('baselayerchange', (e) => store('simdirect.layer', e.name));

/* Google Maps oficial (Map Tiles API) si el usuario pone su clave en Configurar */
async function addGoogleLayers(key) {
  if (!key || addGoogleLayers.done) return false;
  const mk = async (mapType, layerTypes) => {
    const r = await fetch('https://tile.googleapis.com/v1/createSession?key=' + encodeURIComponent(key), {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ mapType, language: 'es-ES', region: 'ES', ...(layerTypes ? { layerTypes } : {}) }),
    });
    if (!r.ok) throw new Error('clave no válida o API sin activar');
    const s = (await r.json()).session;
    return L.tileLayer(`https://tile.googleapis.com/v1/2dtiles/{z}/{x}/{y}?session=${s}&key=${encodeURIComponent(key)}`,
      { maxZoom: 21, maxNativeZoom: 20, attribution: '© Google' });
  };
  try {
    const hybrid = await mk('satellite', ['layerRoadmap']);
    const road = await mk('roadmap');
    layerCtl.addBaseLayer(hybrid, 'Google satélite'); baseLayers['Google satélite'] = hybrid;
    layerCtl.addBaseLayer(road, 'Google mapa'); baseLayers['Google mapa'] = road;
    addGoogleLayers.done = true;
    if (savedLayer && baseLayers[savedLayer] && savedLayer.startsWith('Google')) {
      map.eachLayer((l) => { if (l instanceof L.TileLayer || l instanceof L.LayerGroup) if (Object.values(baseLayers).includes(l)) map.removeLayer(l); });
      baseLayers[savedLayer].addTo(map);
    }
    return true;
  } catch (e) { toast('Google Maps: ' + e.message, 4000); return false; }
}
addGoogleLayers(store('simdirect.googleKey'));
const routeLayer = L.layerGroup().addTo(map);
const trailLine = L.polyline([], { color: '#3cc8ff', weight: 2, opacity: .8 }).addTo(map);
let planeMarker = null;

const FollowCtl = L.Control.extend({
  options: { position: 'bottomleft' },
  onAdd() {
    const b = L.DomUtil.create('button', 'map-btn'); b.id = 'btnFollow'; b.textContent = '✈ Seguir avión';
    L.DomEvent.disableClickPropagation(b);
    b.onclick = toggleFollow; return b;
  },
});
const FitCtl = L.Control.extend({
  options: { position: 'bottomleft' },
  onAdd() {
    const b = L.DomUtil.create('button', 'map-btn'); b.textContent = '⤢ Ver ruta';
    L.DomEvent.disableClickPropagation(b); b.onclick = fitRoute; return b;
  },
});
map.addControl(new FitCtl()); map.addControl(new FollowCtl());

function toggleFollow() {
  follow = !follow;
  document.querySelectorAll('#btnFollow, #btnFollow2').forEach((b) => { b.classList.toggle('on', follow); });
  if (follow && live) map.panTo([live.lat, live.lon]);
}
function fitRoute() {
  const pts = routePoints();
  if (pts.length) map.fitBounds(L.latLngBounds(pts.map((p) => [p.lat, p.lon])).pad(0.15));
}
map.on('dragstart', () => { if (follow) toggleFollow(); });

function iconFor(p) {
  const cls = p.kind === 'wp' ? 'wp-dot' : 'apt-dot';
  return L.divIcon({ className: 'wp-icon', iconSize: [14, 14], iconAnchor: [7, 7],
    html: `<div class="${cls}"></div><div class="wp-label">${esc(p.name)}<br><small>${fmtAlt(p.alt)}</small></div>` });
}
function drawMap(r, est) {
  routeLayer.clearLayers();
  if (r.pts.length > 1) {
    L.polyline(r.pts.map((p) => [p.lat, p.lon]), { color: '#ff4fd8', weight: 3, opacity: .9 }).addTo(routeLayer);
  }
  r.pts.forEach((p) => {
    const m = L.marker([p.lat, p.lon], { icon: iconFor(p), draggable: true, autoPan: true }).addTo(routeLayer);
    m.on('dragend', (e) => {
      const ll = e.target.getLatLng();
      if (p.kind === 'wp') { const w = plan.waypoints[p.idx]; w.lat = ll.lat; w.lon = ll.lng; }
      else { const a = p.kind === 'dep' ? plan.dep : plan.arr; a.lat = ll.lat; a.lon = ll.lng; }
      render();
    });
  });
  if (r.pts.length > 1 && est.descD > 0 && est.todDist > 0) {
    const tod = pointAt(r, est.todDist);
    if (tod) L.marker([tod.lat, tod.lon], { interactive: false,
      icon: L.divIcon({ className: '', iconSize: [0, 0], html: '<span class="tod-icon">T/D</span>' }) }).addTo(routeLayer);
  }
}

map.on('click', (e) => {
  const ll = e.latlng;
  if (window.Pushback && window.Pushback.onMapClick(ll)) return;
  if (placing) {
    const code = (placing.code || (placing.which === 'dep' ? 'SAL' : 'LLE')).toUpperCase();
    plan[placing.which] = { code, name: code, lat: ll.lat, lon: ll.lng, elev: 0 };
    placing = null; $('#placeBanner').classList.add('hidden');
    render(); toast('Aeropuerto colocado. Ajusta su elevación si la conoces.');
    return;
  }
  if (!$('#clickAdd').checked) return;
  addWaypoint(ll.lat, ll.lng);
});

function addWaypoint(lat, lon) {
  const pts = routePoints(), np = { lat, lon };
  const minK = plan.dep ? 1 : 0, maxK = plan.arr ? pts.length - 1 : pts.length;
  let bestK = maxK, bestCost = Infinity;
  for (let k = minK; k <= maxK; k++) {
    let cost;
    if (pts.length === 0) cost = 0;
    else if (k === 0) cost = distNm(np, pts[0]);
    else if (k === pts.length) cost = distNm(pts[pts.length - 1], np);
    else cost = distNm(pts[k - 1], np) + distNm(np, pts[k]) - distNm(pts[k - 1], pts[k]);
    if (cost < bestCost) { bestCost = cost; bestK = k; }
  }
  const wpIndex = bestK - (plan.dep ? 1 : 0);
  let n = plan.waypoints.length + 1;
  while (plan.waypoints.some((w) => w.name === 'WP' + n)) n++;
  const w = { id: uid(), name: 'WP' + n, lat, lon, alt: plan.cruiseAlt };
  plan.waypoints.splice(wpIndex, 0, w);
  autoAltitudes(w.id);
  render();
}

/* ------------------------------------------------------------------ panel */
const aptList = $('#aptList');
aptList.innerHTML = Object.entries(AIRPORTS).map(([c, a]) => `<option value="${c}">${esc(a.name)}</option>`).join('');
$('#aircraft').innerHTML = AIRCRAFT.map((a) => `<option value="${a.id}">${esc(a.name)}</option>`).join('');

function fillForm() {
  if (window.Proc) setTimeout(() => window.Proc.renderBox(), 0);
  $('#planName').value = plan.name;
  $('#aircraft').value = plan.aircraftId;
  const ga = isGA();
  document.querySelectorAll('#acMode button').forEach((b) => b.classList.toggle('on', (b.dataset.mode === 'ga') === ga));
  $('#cruiseAlt').value = plan.cruiseAlt;
  $('#depCode').value = plan.dep ? plan.dep.code : '';
  $('#arrCode').value = plan.arr ? plan.arr.code : '';
  $('#depElev').value = plan.dep ? plan.dep.elev : '';
  $('#arrElev').value = plan.arr ? plan.arr.elev : '';
}

function drawStats(r, est) {
  const ac = aircraft();
  const warn = plan.cruiseAlt > ac.ceiling ? `<div class="stat wide" style="border-color:var(--bad)"><span>⚠ El crucero supera el techo del ${esc(ac.name)} (${fmtAlt(ac.ceiling)})</span></div>` : '';
  $('#stats').innerHTML = `
    <div class="stat"><b>${fmtNm(r.total)}</b><span>Distancia total</span></div>
    <div class="stat"><b>${fmtTime(est.time)}</b><span>Tiempo estimado</span></div>
    <div class="stat"><b>${Math.round(est.fuel).toLocaleString('es-ES')} kg</b><span>Combustible de viaje (est.)</span></div>
    <div class="stat"><b>${Math.round(est.fuel + est.reserve).toLocaleString('es-ES')} kg</b><span>Con reserva 45 min</span></div>
    <div class="stat wide"><b>${fmtNm(est.descD)}</b><span>Inicio de descenso (T/D) antes del destino · regla 3:1</span></div>${warn}`;
}

function drawList(r, prog) {
  const html = r.pts.map((p, i) => {
    const leg = i > 0 ? `<div class="leg">↳ ${fmtCrs(r.legs[i - 1].crs)} · ${fmtNm(r.legs[i - 1].d)} · acum. ${fmtNm(r.cum[i])}</div>` : '';
    const isNext = prog && prog.next === i ? ' next' : '';
    if (p.kind !== 'wp') {
      return `<li class="apt${isNext}"><span class="num">${p.kind === 'dep' ? 'SAL' : 'LLE'}</span>
        <span class="apt-name">${esc(p.name)}</span><span class="num">${fmtAlt(p.alt)}</span>${leg}</li>`;
    }
    return `<li class="${isNext.trim()}" data-id="${p.id}"><span class="num">${p.idx + 1}</span>
      <input class="name" data-f="name" value="${esc(p.name)}" maxlength="8">
      <input type="number" data-f="alt" value="${Math.round(p.alt)}" step="500" title="Altitud (ft)">
      <button class="del" title="Eliminar">✕</button>${leg}</li>`;
  }).join('');
  $('#wpList').innerHTML = html || '<li class="apt"><span></span><span class="hint">Sin puntos todavía</span></li>';
}

$('#wpList').addEventListener('change', (e) => {
  const li = e.target.closest('li[data-id]'); if (!li) return;
  const w = plan.waypoints.find((x) => x.id === li.dataset.id); if (!w) return;
  if (e.target.dataset.f === 'name') w.name = e.target.value.toUpperCase().trim() || w.name;
  if (e.target.dataset.f === 'alt') w.alt = Math.max(0, Number(e.target.value) || 0);
  render();
});
$('#wpList').addEventListener('click', (e) => {
  if (!e.target.classList.contains('del')) return;
  const id = e.target.closest('li').dataset.id;
  plan.waypoints = plan.waypoints.filter((w) => w.id !== id); render();
});

$('#planName').onchange = (e) => { plan.name = e.target.value.trim() || 'Plan'; render(); };
$('#aircraft').onchange = (e) => {
  plan.aircraftId = e.target.value;
  plan.cruiseAlt = aircraft().cruiseAlt; fillForm(); autoAltitudes(); render();
};
$('#cruiseAlt').onchange = (e) => { plan.cruiseAlt = Math.max(500, Number(e.target.value) || 1000); autoAltitudes(); render(); };
function setAirport(which) {
  const code = $('#' + which + 'Code').value.toUpperCase().trim();
  if (!code) { plan[which] = null; render(); return; }
  const a = apt(code);
  if (a) { plan[which] = a; fillForm(); render(); map.panTo([a.lat, a.lon]); return; }
  startPlacing(which, code);
}
function startPlacing(which, code) {
  placing = { which, code };
  $('#placeBanner').textContent = `Toca el mapa para colocar ${code || (which === 'dep' ? 'la salida' : 'la llegada')}`;
  $('#placeBanner').classList.remove('hidden');
  document.body.classList.remove('menu-open');
}
$('#depCode').onchange = () => setAirport('dep');
$('#arrCode').onchange = () => setAirport('arr');
$('#depPlace').onclick = () => startPlacing('dep', $('#depCode').value.toUpperCase().trim());
$('#arrPlace').onclick = () => startPlacing('arr', $('#arrCode').value.toUpperCase().trim());
$('#depElev').onchange = (e) => { if (plan.dep) { plan.dep.elev = Number(e.target.value) || 0; render(); } };
$('#arrElev').onchange = (e) => { if (plan.arr) { plan.arr.elev = Number(e.target.value) || 0; render(); } };

$('#btnAutoAlt').onclick = () => { autoAltitudes(); render(); toast('Altitudes calculadas según el perfil del avión'); };
$('#btnReverse').onclick = () => { [plan.dep, plan.arr] = [plan.arr, plan.dep]; plan.waypoints.reverse(); fillForm(); autoAltitudes(); render(); };
$('#btnClear').onclick = () => { if (confirm('¿Borrar todos los checkpoints?')) { plan.waypoints = []; render(); } };
$('#btnNew').onclick = () => { if (confirm('¿Empezar un plan nuevo?')) { plan = newPlan(); fillForm(); render(); } };
$('#btnTrail').onclick = () => { trail = []; trailLine.setLatLngs([]); };
$('#btnFollow2').onclick = toggleFollow;

document.querySelectorAll('.tab[data-tab]').forEach((t) => t.onclick = () => {
  document.querySelectorAll('.tab').forEach((x) => x.classList.toggle('active', x === t));
  document.querySelectorAll('.panel').forEach((p) => p.classList.toggle('active', p.id === 'tab-' + t.dataset.tab));
});
$('#menuBtn').onclick = () => document.body.classList.toggle('menu-open');

/* ------------------------------------------------------------------ guardar / abrir */
async function api(path, opts) {
  const r = await fetch(path, opts);
  if (!r.ok) throw new Error(r.status);
  return r.json();
}
$('#btnSave').onclick = async () => {
  try {
    if (serverOk) await api('/api/plans', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ name: plan.name, plan }) });
    else { const all = store('simdirect.saved') || {}; all[plan.name] = plan; store('simdirect.saved', all); }
    toast(`Plan «${plan.name}» guardado`);
  } catch (e) { toast('No se pudo guardar: ' + e.message); }
};
$('#btnOpen').onclick = async () => {
  let names = [];
  try { names = serverOk ? await api('/api/plans') : Object.keys(store('simdirect.saved') || {}); } catch (e) { /* vacío */ }
  const body = $('#dlgBody');
  body.innerHTML = `<h3>Abrir plan</h3>${names.length ? '' : '<p class="hint">No hay planes guardados todavía.</p>'}
    <ul class="dlg-list">${names.map((n) => `<li><button data-open="${esc(n)}">${esc(n)}</button><button data-del="${esc(n)}" title="Borrar">🗑</button></li>`).join('')}</ul>
    <button id="dlgClose">Cerrar</button>`;
  const dlg = $('#dlg'); dlg.showModal();
  $('#dlgClose').onclick = () => dlg.close();
  body.querySelectorAll('[data-open]').forEach((b) => b.onclick = async () => {
    const n = b.dataset.open;
    try {
      const p = serverOk ? await api('/api/plans/' + encodeURIComponent(n)) : (store('simdirect.saved') || {})[n];
      if (p && p.waypoints) { plan = p; fillForm(); render(); fitRoute(); dlg.close(); }
    } catch (e) { toast('No se pudo abrir'); }
  });
  body.querySelectorAll('[data-del]').forEach((b) => b.onclick = async () => {
    const n = b.dataset.del; if (!confirm(`¿Borrar «${n}»?`)) return;
    if (serverOk) await api('/api/plans/' + encodeURIComponent(n), { method: 'DELETE' }).catch(() => {});
    else { const all = store('simdirect.saved') || {}; delete all[n]; store('simdirect.saved', all); }
    b.closest('li').remove();
  });
};

/* ------------------------------------------------------------------ .pln (MSFS) */
function dms(v, pos, neg) {
  const h = v >= 0 ? pos : neg; v = Math.abs(v);
  let d = Math.floor(v), m = Math.floor((v - d) * 60), s = ((v - d) * 60 - m) * 60;
  if (s >= 59.995) { s = 0; m++; } if (m >= 60) { m = 0; d++; }
  return `${h}${d}° ${m}' ${s.toFixed(2)}"`;
}
function lla(p) {
  const a = Number(p.alt) || 0;
  return `${dms(p.lat, 'N', 'S')},${dms(p.lon, 'E', 'W')},${a >= 0 ? '+' : '-'}${Math.abs(a).toFixed(2).padStart(9, '0')}`;
}
function buildPln() {
  const pts = routePoints();
  const first = plan.dep, last = plan.arr;
  const wps = pts.map((p) => {
    if (p.kind === 'wp') {
      return `    <ATCWaypoint id="${esc(p.name)}">\n      <ATCWaypointType>User</ATCWaypointType>\n      <WorldPosition>${lla(p)}</WorldPosition>\n    </ATCWaypoint>`;
    }
    const P = plan.proc || {}, des = { L: 'LEFT', R: 'RIGHT', C: 'CENTER' };
    const rwyTags = (r) => { if (!r) return ''; const m = /^(\d+)([LRC]?)$/.exec(r); return m ? `\n      <RunwayNumberFP>${+m[1]}</RunwayNumberFP>${m[2] ? `\n      <RunwayDesignatorFP>${des[m[2]]}</RunwayDesignatorFP>` : ''}` : ''; };
    let fp = '';
    if (p.kind === 'dep') fp = (P.sid ? `\n      <DepartureFP>${esc(P.sid)}</DepartureFP>` : '') + rwyTags(P.depRwy);
    if (p.kind === 'arr') fp = (P.star ? `\n      <ArrivalFP>${esc(P.star)}</ArrivalFP>` : '') + (P.appr ? `\n      <ApproachTypeFP>${esc(P.appr.split(' ')[0])}</ApproachTypeFP>` : '') + rwyTags(P.arrRwy);
    return `    <ATCWaypoint id="${esc(p.name)}">\n      <ATCWaypointType>Airport</ATCWaypointType>\n      <WorldPosition>${lla(p)}</WorldPosition>${fp}\n      <ICAO>\n        <ICAOIdent>${esc(p.name)}</ICAOIdent>\n      </ICAO>\n    </ATCWaypoint>`;
  }).join('\n');
  const hi = plan.cruiseAlt >= 18000;
  return `<?xml version="1.0" encoding="UTF-8"?>
<SimBase.Document Type="AceXML" version="1,0">
  <Descr>AceXML Document</Descr>
  <FlightPlan.FlightPlan>
    <Title>${esc(plan.name)}</Title>
    <FPType>${hi ? 'IFR' : 'VFR'}</FPType>
    <RouteType>${hi ? 'HighAlt' : 'LowAlt'}</RouteType>
    <CruisingAlt>${Math.round(plan.cruiseAlt)}</CruisingAlt>
${first ? `    <DepartureID>${esc(first.code)}</DepartureID>\n    <DepartureLLA>${lla({ ...first, alt: first.elev })}</DepartureLLA>\n` : ''}${last ? `    <DestinationID>${esc(last.code)}</DestinationID>\n    <DestinationLLA>${lla({ ...last, alt: last.elev })}</DestinationLLA>\n` : ''}    <Descr>${esc(plan.name)} creado con SimDirect</Descr>
${first && (plan.proc || {}).depRwy ? `    <DeparturePosition>${esc(plan.proc.depRwy)}</DeparturePosition>\n` : ''}${first ? `    <DepartureName>${esc(first.name)}</DepartureName>\n` : ''}${last ? `    <DestinationName>${esc(last.name)}</DestinationName>\n` : ''}    <AppVersion>
      <AppVersionMajor>12</AppVersionMajor>
      <AppVersionBuild>1</AppVersionBuild>
    </AppVersion>
${wps}
  </FlightPlan.FlightPlan>
</SimBase.Document>
`;
}
$('#btnExport').onclick = async () => {
  if (!plan.dep || !plan.arr) toast('Aviso: MSFS funciona mejor con aeropuerto de salida y de llegada', 3500);
  const xml = buildPln(), fname = plan.name.replace(/[^\w\- ]/g, '') || 'plan';
  if (serverOk) {
    try {
      const res = await api('/api/export-pln', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ name: fname, xml }) });
      toast('Guardado en el PC: ' + res.path, 5000);
      return;
    } catch (e) { /* si falla, se descarga en el navegador */ }
  }
  const a = document.createElement('a');
  a.href = URL.createObjectURL(new Blob([xml], { type: 'application/xml' }));
  a.download = fname + '.pln'; a.click(); URL.revokeObjectURL(a.href);
};
$('#btnImport').onclick = () => $('#plnFile').click();
$('#plnFile').onchange = async (e) => {
  const f = e.target.files[0]; if (!f) return;
  try { importPln(await f.text(), f.name.replace(/\.\w+$/, '')); fitRoute(); toast('Plan importado'); }
  catch (err) { toast('No se pudo leer el .pln'); }
  e.target.value = '';
};
function parseLla(s) {
  const m = /([NS])\s*(\d+)°\s*(\d+)'\s*([\d.]+)"\s*,\s*([EW])\s*(\d+)°\s*(\d+)'\s*([\d.]+)"\s*,\s*([+-]?[\d.]+)/.exec(s || '');
  if (!m) return null;
  const lat = (+m[2] + m[3] / 60 + m[4] / 3600) * (m[1] === 'S' ? -1 : 1);
  const lon = (+m[6] + m[7] / 60 + m[8] / 3600) * (m[5] === 'W' ? -1 : 1);
  return { lat, lon, alt: parseFloat(m[9]) };
}
function importPln(text, fallbackName) {
  const doc = new DOMParser().parseFromString(text, 'application/xml');
  const fp = doc.querySelector('FlightPlan\\.FlightPlan') || doc.getElementsByTagName('FlightPlan.FlightPlan')[0];
  if (!fp) throw new Error('formato');
  const get = (tag) => { const n = fp.getElementsByTagName(tag)[0]; return n ? n.textContent.trim() : ''; };
  const p = newPlan();
  p.name = get('Title') || fallbackName;
  p.cruiseAlt = Number(get('CruisingAlt')) || 35000;
  p.aircraftId = plan.aircraftId;
  const items = [...fp.getElementsByTagName('ATCWaypoint')].map((w) => {
    const type = (w.getElementsByTagName('ATCWaypointType')[0] || {}).textContent || '';
    const pos = parseLla((w.getElementsByTagName('WorldPosition')[0] || {}).textContent);
    return pos ? { id: w.getAttribute('id') || 'WP', type: type.trim(), ...pos } : null;
  }).filter(Boolean);
  if (items.length && items[0].type === 'Airport') {
    const a = items.shift(); p.dep = apt(a.id) || { code: a.id, name: a.id, lat: a.lat, lon: a.lon, elev: Math.round(a.alt) };
  }
  if (items.length && items[items.length - 1].type === 'Airport') {
    const a = items.pop(); p.arr = apt(a.id) || { code: a.id, name: a.id, lat: a.lat, lon: a.lon, elev: Math.round(a.alt) };
  }
  p.waypoints = items.map((w) => ({ id: uid(), name: w.id.slice(0, 8).toUpperCase(), lat: w.lat, lon: w.lon, alt: Math.round(w.alt) }));
  plan = p;
  if (plan.waypoints.every((w) => !w.alt)) autoAltitudes();
  fillForm(); render();
}

/* ------------------------------------------------------------------ perfil de altitud */
function niceStep(v) { const p = 10 ** Math.floor(Math.log10(v)); const n = v / p; return (n < 1.5 ? 1 : n < 3.5 ? 2 : n < 7.5 ? 5 : 10) * p; }
function drawProfile(r, est, prog) {
  const c = $('#profile'), ctx = c.getContext('2d'), dpr = window.devicePixelRatio || 1;
  const w = c.clientWidth, h = c.clientHeight; if (!w || !h) return;
  c.width = w * dpr; c.height = h * dpr; ctx.setTransform(dpr, 0, 0, dpr, 0, 0); ctx.clearRect(0, 0, w, h);
  ctx.font = '11px system-ui, sans-serif';
  if (r.pts.length < 2 || r.total <= 0) {
    ctx.fillStyle = '#8197ab'; ctx.fillText('Perfil de altitud: añade al menos dos puntos', 16, h / 2); return;
  }
  const padL = 52, padR = 18, padT = 18, padB = 22;
  const maxAlt = Math.max(plan.cruiseAlt, ...r.pts.map((p) => p.alt), live ? live.alt : 0) * 1.12 || 1000;
  const X = (d) => padL + (d / r.total) * (w - padL - padR);
  const Y = (a) => h - padB - (Math.max(0, a) / maxAlt) * (h - padT - padB);
  const step = niceStep(maxAlt / 4);
  ctx.strokeStyle = '#1c2a37'; ctx.fillStyle = '#8197ab'; ctx.lineWidth = 1; ctx.textAlign = 'right';
  for (let a = 0; a <= maxAlt; a += step) {
    ctx.beginPath(); ctx.moveTo(padL, Y(a)); ctx.lineTo(w - padR, Y(a)); ctx.stroke();
    ctx.fillText(a >= 18000 ? 'FL' + a / 100 : (a / 1000) + 'k', padL - 6, Y(a) + 4);
  }
  // perfil ideal (ascenso/descenso del avión) en gris
  ctx.setLineDash([4, 4]); ctx.strokeStyle = '#3d5163'; ctx.beginPath();
  for (let i = 0; i <= 60; i++) { const d = r.total * i / 60, a = idealAlt(d, r, est); i ? ctx.lineTo(X(d), Y(a)) : ctx.moveTo(X(d), Y(a)); }
  ctx.stroke(); ctx.setLineDash([]);
  // área de la ruta planificada
  const grad = ctx.createLinearGradient(0, padT, 0, h - padB);
  grad.addColorStop(0, 'rgba(255,79,216,.35)'); grad.addColorStop(1, 'rgba(255,79,216,0)');
  ctx.beginPath(); ctx.moveTo(X(0), Y(0));
  r.pts.forEach((p, i) => ctx.lineTo(X(r.cum[i]), Y(p.alt)));
  ctx.lineTo(X(r.total), Y(0)); ctx.closePath(); ctx.fillStyle = grad; ctx.fill();
  ctx.beginPath(); r.pts.forEach((p, i) => (i ? ctx.lineTo(X(r.cum[i]), Y(p.alt)) : ctx.moveTo(X(0), Y(p.alt))));
  ctx.strokeStyle = '#ff4fd8'; ctx.lineWidth = 2; ctx.stroke();
  // puntos y nombres
  ctx.textAlign = 'center';
  r.pts.forEach((p, i) => {
    const x = X(r.cum[i]), y = Y(p.alt);
    ctx.fillStyle = p.kind === 'wp' ? '#ff4fd8' : '#3cc8ff'; ctx.beginPath(); ctx.arc(x, y, 3.5, 0, 7); ctx.fill();
    ctx.fillStyle = '#e4ecf4'; ctx.fillText(p.name, Math.min(w - padR - 14, Math.max(padL + 14, x)), Math.max(12, y - 8));
  });
  // T/D
  if (est.descD > 0 && est.todDist > 0) {
    const x = X(est.todDist); ctx.strokeStyle = '#ffb547'; ctx.setLineDash([3, 3]);
    ctx.beginPath(); ctx.moveTo(x, padT); ctx.lineTo(x, h - padB); ctx.stroke(); ctx.setLineDash([]);
    ctx.fillStyle = '#ffb547'; ctx.fillText('T/D', x, h - 8);
  }
  ctx.fillStyle = '#8197ab'; ctx.textAlign = 'left'; ctx.fillText('0', padL, h - 6);
  ctx.textAlign = 'right'; ctx.fillText(fmtNm(r.total), w - padR, h - 6);
  // avión
  if (live && prog) {
    const x = X(prog.along), y = Y(live.alt);
    ctx.fillStyle = '#3cc8ff'; ctx.strokeStyle = '#fff'; ctx.lineWidth = 1.5;
    ctx.beginPath(); ctx.moveTo(x + 8, y); ctx.lineTo(x - 6, y - 5); ctx.lineTo(x - 3, y); ctx.lineTo(x - 6, y + 5); ctx.closePath(); ctx.fill(); ctx.stroke();
  }
}

/* ------------------------------------------------------------------ render */
let sendTimer = null;
function render() {
  const r = computeRoute(), est = estimates(r), prog = progress(r, live);
  drawMap(r, est); drawStats(r, est); drawList(r, prog); drawProfile(r, est, prog); drawLive(r, prog);
  store('simdirect.draft', plan);
  clearTimeout(sendTimer); sendTimer = setTimeout(sendPlan, 300);
}
window.addEventListener('resize', () => { const r = computeRoute(); drawProfile(r, estimates(r), progress(r, live)); });

/* ------------------------------------------------------------------ datos en vivo */
const PLANE_SVG = '<svg width="34" height="34" viewBox="0 0 24 24"><path fill="#3cc8ff" stroke="#fff" stroke-width=".8" d="M12 2c.8 0 1.3.9 1.3 2v5.2l7.7 4.6v2l-7.7-2.3v4.6l2.2 1.7v1.6L12 20.4l-3.5 1v-1.6l2.2-1.7v-4.6L3 15.8v-2l7.7-4.6V4c0-1.1.5-2 1.3-2z"/></svg>';
function setStatus(mode) {
  const s = $('#status'); s.className = 'status ' + mode;
  s.textContent = mode === 'sim' ? 'MSFS 2024 conectado' : mode === 'waiting' ? 'Esperando a MSFS 2024…' : 'Sin servidor';
}
function drawLive(r, prog) {
  const hud = $('#hud');
  if (!live) { hud.classList.add('hidden'); $('#flightInfo').innerHTML = '<p class="hint">Esperando datos del simulador…</p>'; return; }
  hud.classList.remove('hidden');
  const vs = Math.round(live.vs / 10) * 10;
  let nextTxt = '';
  if (prog && r.pts[prog.next]) {
    const eta = live.gs > 30 ? prog.distNext / live.gs : NaN;
    nextTxt = `<div class="next">▶ ${esc(r.pts[prog.next].name)} · ${fmtNm(prog.distNext)} · ${fmtTime(eta)}</div>`;
  }
  hud.innerHTML = `<div><small>ALT</small>${fmtAlt(live.alt)}</div><div><small>GS</small>${Math.round(live.gs)} kt</div>
    <div><small>V/S</small>${vs > 0 ? '+' : ''}${vs}</div><div><small>IAS</small>${Math.round(live.ias)} kt</div>
    <div><small>RUMBO</small>${fmtCrs(live.hdg)}</div><div><small>AGL</small>${Math.round(live.agl)} ft</div>${nextTxt}`;
  const remain = prog ? prog.remaining : NaN;
  $('#flightInfo').innerHTML = `
    <div class="stat"><b>${fmtAlt(live.alt)}</b><span>Altitud</span></div>
    <div class="stat"><b>${Math.round(live.ias)} kt</b><span>Velocidad indicada</span></div>
    <div class="stat"><b>${Math.round(live.gs)} kt</b><span>Velocidad suelo</span></div>
    <div class="stat"><b>${vs > 0 ? '+' : ''}${vs} fpm</b><span>Velocidad vertical</span></div>
    <div class="stat"><b>${fmtCrs(live.hdg)}</b><span>Rumbo verdadero</span></div>
    <div class="stat"><b>${live.on_ground ? 'En tierra' : 'En vuelo'}</b><span>Estado</span></div>
    <div class="stat"><b>${isFinite(remain) ? fmtNm(remain) : '—'}</b><span>Distancia restante</span></div>
    <div class="stat"><b>${isFinite(remain) && live.gs > 30 ? fmtTime(remain / live.gs) : '—'}</b><span>Tiempo restante</span></div>
    <div class="stat wide"><b>${prog ? prog.xtk.toFixed(1) + ' nm' : '—'}</b><span>Desvío lateral respecto a la ruta</span></div>`;
}
let lastProfile = 0;
function onTelemetry(m) {
  if (m.mode !== liveMode) { trail = []; trailLine.setLatLngs([]); liveMode = m.mode; setStatus(m.mode); }
  live = m.data;
  const ll = [live.lat, live.lon];
  if (!planeMarker) {
    planeMarker = L.marker(ll, { interactive: false, zIndexOffset: 1000,
      icon: L.divIcon({ className: 'plane-icon', iconSize: [34, 34], iconAnchor: [17, 17], html: PLANE_SVG }) }).addTo(map);
  } else planeMarker.setLatLng(ll);
  const svg = planeMarker.getElement() && planeMarker.getElement().querySelector('svg');
  if (svg) svg.style.transform = `rotate(${live.hdg}deg)`;
  const lastPt = trail[trail.length - 1];
  if (!lastPt || distNm({ lat: lastPt[0], lon: lastPt[1] }, live) > 0.05) {
    trail.push(ll); if (trail.length > 4000) trail.shift(); trailLine.setLatLngs(trail);
  }
  if (follow) map.panTo(ll, { animate: false });
  const r = computeRoute(), prog = progress(r, live);
  drawLive(r, prog);
  if (window.Announcer) window.Announcer.update(live, prog, r);
  if (window.Peso) window.Peso.onData(live);
  if (window.Proc) window.Proc.onData(live);
  const now = Date.now();
  if (now - lastProfile > 1000) { lastProfile = now; drawProfile(r, estimates(r), prog); drawList(r, prog); }
}

let ws = null;
function sendPlan() {
  if (ws && ws.readyState === 1) ws.send(JSON.stringify({ type: 'plan', name: plan.name, cruiseAlt: plan.cruiseAlt,
    dest: plan.arr ? String(plan.arr.name || plan.arr.code).split(/[-–(]/)[0].trim() : null,
    route: routePoints().map((p) => ({ lat: p.lat, lon: p.lon, alt: p.alt })) }));
}
function connectWs() {
  if (location.protocol === 'file:') { setStatus('offline'); return; }
  ws = new WebSocket(`${location.protocol === 'https:' ? 'wss' : 'ws'}://${location.host}/ws`);
  ws.onopen = async () => {
    serverOk = true; sendPlan();
    // si el servidor se ha actualizado mientras la ventana estaba abierta, recargar para ver lo nuevo
    try {
      const v = (await (await fetch('/api/setup/status', { cache: 'no-store' })).json()).version;
      if (window._srvVersion && v !== window._srvVersion) { location.reload(); return; }
      window._srvVersion = v;
    } catch (e) { /* */ }
  };
  ws.onmessage = (e) => {
    let m; try { m = JSON.parse(e.data); } catch (err) { return; }
    if (m.type !== 'telemetry') return;
    if (window.onPushStatus) window.onPushStatus(m.push);
    if (window.onSoundStatus) window.onSoundStatus(m.snd);
    if (m.snd) window.dispatchEvent(new CustomEvent('simsnd', { detail: m.snd }));
    if (m.data) onTelemetry(m);
    else if (liveMode !== 'waiting') {
      liveMode = 'waiting'; setStatus('waiting'); live = null;
      if (planeMarker) { map.removeLayer(planeMarker); planeMarker = null; }
      const r = computeRoute(); drawLive(r, null);
    }
  };
  ws.onclose = () => { serverOk = false; liveMode = 'offline'; setStatus('offline'); setTimeout(connectWs, 3000); };
}

/* ------------------------------------------------------------------ inicio */
if (plan.waypoints.length && plan.waypoints.every((w) => !w.alt)) autoAltitudes();
fillForm(); render(); fitRoute(); setStatus('offline'); connectWs();
