'use strict';
/* Jugadores online (VATSIM e IVAO) en el mapa, con botón para ver u ocultar */
const Traffic = (() => {
  const layer = L.layerGroup();
  let on = store('simdirect.traffic') === true, timer = null, nets = store('simdirect.trafficNets') || ['msfs', 'vatsim', 'ivao'];
  if (!nets.includes('msfs') && !store('simdirect.trafficMsfsAsked')) { nets.unshift('msfs'); store('simdirect.trafficMsfsAsked', true); }
  const COL = { msfs: '#ffb547', vatsim: '#3ddc84', ivao: '#4aa3ff' };
  const NAME = { msfs: 'MSFS', vatsim: 'VATSIM', ivao: 'IVAO' };
  const ico = (p) => L.divIcon({ className: 'tfc', iconSize: [22, 22], iconAnchor: [11, 11],
    html: `<svg viewBox="0 0 24 24" width="22" height="22" style="transform:rotate(${p.hdg || 0}deg)"><path fill="${COL[p.net]}" stroke="#04121c" stroke-width="1" d="M12 2c.8 0 1.3.9 1.3 2v5.2l7.7 4.6v2l-7.7-2.3v4.6l2.2 1.7v1.6L12 20.4l-3.5 1v-1.6l2.2-1.7v-4.6L3 15.8v-2l7.7-4.6V4c0-1.1.5-2 1.3-2z"/></svg>` });

  async function refresh() {
    if (!on || !serverOk) return;
    const b = map.getBounds().pad(0.2);
    try {
      const r = await (await fetch(`/api/traffic?nets=${nets.join(',')}&bbox=${b.getSouth()},${b.getWest()},${b.getNorth()},${b.getEast()}`)).json();
      layer.clearLayers();
      r.pilots.forEach((p) => L.marker([p.lat, p.lon], { icon: ico(p), zIndexOffset: 500 })
        .bindTooltip(`<b>${esc(p.cs || '')}</b> · ${NAME[p.net]}<br>${esc(p.ac || '')} ${p.dep ? esc(p.dep) + ' → ' + esc(p.arr || '?') : ''}<br>${Math.round(p.alt || 0).toLocaleString('es-ES')} ft · ${Math.round(p.gs || 0)} kt`, { direction: 'top' })
        .addTo(layer));
      btn.querySelector('small').textContent = r.count;
    } catch (e) { /* sin conexión */ }
  }
  function set(v) {
    on = v; store('simdirect.traffic', on);
    btn.classList.toggle('on', on);
    clearInterval(timer);
    if (on) { layer.addTo(map); refresh(); timer = setInterval(refresh, 8000); }
    else { map.removeLayer(layer); btn.querySelector('small').textContent = ''; }
  }
  const Ctl = L.Control.extend({
    options: { position: 'bottomleft' },
    onAdd() {
      const d = L.DomUtil.create('div', 'tfc-ctl');
      d.innerHTML = `<button class="map-btn" id="tfcBtn">👥 Jugadores online <small></small></button>
        <div class="tfc-nets"><label><input type="checkbox" data-net="msfs" ${nets.includes('msfs') ? 'checked' : ''}> <b style="color:#ffb547">MSFS</b></label><label><input type="checkbox" data-net="vatsim" ${nets.includes('vatsim') ? 'checked' : ''}> VATSIM</label>
        <label><input type="checkbox" data-net="ivao" ${nets.includes('ivao') ? 'checked' : ''}> IVAO</label></div>`;
      L.DomEvent.disableClickPropagation(d); L.DomEvent.disableScrollPropagation(d);
      return d;
    },
  });
  map.addControl(new Ctl());
  const btn = document.getElementById('tfcBtn');
  btn.onclick = () => set(!on);
  document.querySelectorAll('.tfc-nets input').forEach((c) => c.onchange = () => {
    nets = [...document.querySelectorAll('.tfc-nets input:checked')].map((x) => x.dataset.net);
    store('simdirect.trafficNets', nets); refresh();
  });
  map.on('moveend', () => { clearTimeout(refresh.t); refresh.t = setTimeout(refresh, 500); });
  setTimeout(() => set(on), 1500);
  return { set };
})();
