'use strict';
/* Pushback guiado: eliges en el mapa dónde te deja el remolcador y hacia dónde mira el morro */

const Pushback = (() => {
  const layer = L.layerGroup().addTo(map);
  let target = null, finalHdg = null, srv = { active: false, msg: '' };

  const PLANE = (color) => `<svg viewBox="0 0 24 24" width="40" height="40"><path fill="${color}" stroke="#fff" stroke-width=".9" d="M12 2c.8 0 1.3.9 1.3 2v5.2l7.7 4.6v2l-7.7-2.3v4.6l2.2 1.7v1.6L12 20.4l-3.5 1v-1.6l2.2-1.7v-4.6L3 15.8v-2l7.7-4.6V4c0-1.1.5-2 1.3-2z"/></svg>`;
  const isActive = () => !!document.querySelector('#tab-push.active');

  function mOffset(lat, lon, hdg, m) {
    const r = hdg * Math.PI / 180;
    return [lat + Math.cos(r) * m / 110540, lon + Math.sin(r) * m / (111320 * Math.cos(lat * Math.PI / 180))];
  }
  function mDist(a, b) {
    const k = Math.cos(a[0] * Math.PI / 180);
    return Math.hypot((b[1] - a[1]) * k * 111320, (b[0] - a[0]) * 110540);
  }
  function bezier() {           // misma curva que usa el servidor
    if (!live || !target) return [];
    const p0 = [live.lat, live.lon], d = mDist(p0, target), Lm = Math.max(8, d * 0.45);
    const p1 = mOffset(live.lat, live.lon, (live.hdg + 180) % 360, Lm);
    const p2 = mOffset(target[0], target[1], finalHdg, Lm);
    const pts = [];
    for (let i = 0; i <= 40; i++) {
      const t = i / 40, u = 1 - t;
      pts.push([0, 1].map((j) => u ** 3 * p0[j] + 3 * u * u * t * p1[j] + 3 * u * t * t * p2[j] + t ** 3 * target[j]));
    }
    return pts;
  }

  // tamaño real del avión en el mapa (envergadura ~36 m) según el zoom
  function ghostPx() {
    const mpp = 156543.03 * Math.cos(map.getCenter().lat * Math.PI / 180) / 2 ** map.getZoom();
    return Math.max(26, Math.min(220, 38 / mpp));
  }
  let ghost = null;
  function draw() {
    layer.clearLayers(); ghost = null;
    if (!target) return;
    const path = srv.active && srv.path && srv.path.length ? srv.path : bezier();
    if (path.length) L.polyline(path, { color: '#ffb547', weight: 4, dashArray: '8 8', opacity: .95, interactive: false }).addTo(layer);
    const px = ghostPx();
    ghost = L.marker(target, { draggable: !srv.active, zIndexOffset: 900, keyboard: false,
      icon: L.divIcon({ className: 'pb-target', iconSize: [px, px], iconAnchor: [px / 2, px / 2],
        html: `<div class="pb-ghost" style="width:${px}px;height:${px}px;transform:rotate(${finalHdg}deg)">${PLANE('rgba(255,181,71,.8)').replace('width="40" height="40"', `width="${px}" height="${px}"`)}</div>` }) }).addTo(layer);
    ghost.on('drag', (e) => { const ll = e.target.getLatLng(); target = [ll.lat, ll.lng]; redrawPath(); });
    ghost.on('dragstart', () => { clearInterval(autoT); autoT = null; });
    ghost.on('dragend', () => { render(); scheduleAuto(); });
  }
  let pathLine = null;
  function redrawPath() {
    layer.eachLayer((l) => { if (l instanceof L.Polyline) layer.removeLayer(l); });
    const path = bezier();
    if (path.length) L.polyline(path, { color: '#ffb547', weight: 4, dashArray: '8 8', opacity: .95, interactive: false }).addTo(layer);
  }
  function rotate(delta) {
    if (!target || srv.active) return;
    finalHdg = Math.round((finalHdg + delta + 360) % 360);
    const g = document.querySelector('.pb-ghost');
    if (g) g.style.transform = `rotate(${finalHdg}deg)`;
    redrawPath();
    const sp = document.querySelector('#tab-push .section-head h3 span'); if (sp) sp.textContent = String(finalHdg).padStart(3, '0') + '°';
    const sl = $('#pbHdg'); if (sl) sl.value = finalHdg;
    scheduleAuto();
  }
  // rueda del ratón = girar el avión (mientras estás en Pushback)
  map.getContainer().addEventListener('wheel', (e) => {
    if (!isActive() || !target) return;
    e.preventDefault(); e.stopPropagation();
    rotate((e.deltaY > 0 ? 1 : -1) * (e.shiftKey ? 1 : 5));
  }, { passive: false, capture: true });
  map.on('zoomend', () => { if (isActive() && target) draw(); });

  /* arranque automático: al colocar el avión, cuenta atrás y empieza solo */
  let autoT = null, autoLeft = 0;
  const autoOn = () => store('simdirect.pbAuto') !== false;
  function scheduleAuto() {
    clearInterval(autoT); autoT = null;
    if (!autoOn() || !target || srv.active) return;
    autoLeft = 5;
    autoT = setInterval(() => {
      const ready = liveMode === 'sim' && live && live.on_ground && live.gs < 3;
      if (!target || srv.active || !ready) { clearInterval(autoT); autoT = null; showAuto(ready ? '' : 'Esperando a que el avión esté parado en tierra con MSFS abierto'); return; }
      autoLeft -= 1; showAuto(`Empieza solo en ${autoLeft} s… (mueve o gira el avión para esperar)`);
      if (autoLeft <= 0) { clearInterval(autoT); autoT = null; startPush(); }
    }, 1000);
    showAuto(`Empieza solo en ${autoLeft} s… (mueve o gira el avión para esperar)`);
  }
  function showAuto(t) { const el = document.querySelector('#tab-push .pb-status'); if (el && !srv.active) el.textContent = t || 'Preparado'; }
  async function startPush() {
    if (!target) return;
    const r = await post('/api/pushback', { action: 'start', lat: target[0], lon: target[1], heading: finalHdg });
    toast(r.ok ? '🚜 Remolcador conectado: empujando hasta tu marca' : r.error, 4500);
  }

  function onMapClick(ll) {
    if (!isActive()) return false;
    target = [ll.lat, ll.lng];
    if (finalHdg === null) finalHdg = live ? Math.round(live.hdg) : 0;
    draw(); render(); scheduleAuto();
    return true;
  }

  function centerOnPlane() {
    if (!live) { toast('Abre MSFS 2024 y entra en un vuelo'); return; }
    const sat = baseLayers['Google satélite'] || baseLayers['Satélite + nombres'];
    Object.values(baseLayers).forEach((l) => { if (map.hasLayer(l) && l !== sat) map.removeLayer(l); });
    if (!map.hasLayer(sat)) sat.addTo(map);
    map.setView([live.lat, live.lon], 18);
  }

  function render() {
    const box = $('#tab-push'); if (!box) return;
    const conn = liveMode === 'sim' && live;
    const ground = conn && live.on_ground;
    const hdgTxt = finalHdg === null ? '—' : String(Math.round(finalHdg)).padStart(3, '0') + '°';
    box.innerHTML = `
      <h2 class="ptitle">Pushback</h2>
      <p class="psub">En el mapa del aeropuerto: <b>haz clic</b> donde quieres que te deje el remolcador (o arrastra el avión naranja) y <b>gíralo con la rueda del ratón</b> (Mayús + rueda = giro fino). Zoom con + y −.</p>
      <div class="msfs-banner ${conn ? 'on' : 'off'}">${conn ? (ground ? '🟢 Avión en tierra, listo' : '🟡 El avión está en el aire') : '🟠 Abre MSFS 2024 y ponte en un parking'}</div>
      <button class="big" id="pbCenter">✈ Centrar el mapa en mi avión</button>
      <div class="section-head"><h3>1 · Punto final</h3></div>
      <p class="hint">${target ? `Avión colocado a <b>${live ? Math.round(mDist([live.lat, live.lon], target)) : '?'} m</b>. Arrástralo o haz clic en otro sitio para moverlo.` : 'Haz clic en el mapa donde quieres acabar.'}</p>
      <div class="section-head"><h3>2 · Rumbo final del morro: <span style="color:var(--accent2)">${hdgTxt}</span></h3></div>
      <input type="range" id="pbHdg" min="0" max="359" step="1" value="${finalHdg ?? 0}" style="width:100%;accent-color:var(--accent2)" ${target ? '' : 'disabled'}>
      <div class="pb-compass">
        <button data-rel="-90" ${target ? '' : 'disabled'}>↰ Morro izquierda</button>
        <button data-rel="0" ${target ? '' : 'disabled'}>↑ Recto</button>
        <button data-rel="90" ${target ? '' : 'disabled'}>↱ Morro derecha</button>
      </div>
      <div class="section-head"><h3>3 · Empujar</h3></div>
      <div class="pb-status ${srv.active ? 'active' : ''}">${esc(srv.msg || (target ? 'Preparado' : 'Elige el punto en el mapa'))}</div>
      <div class="row2">
        <button class="primary big" id="pbStart" ${conn && ground && target && !srv.active ? '' : 'disabled'}>▶ Iniciar pushback</button>
        <button class="danger big" id="pbStop" ${srv.active ? '' : 'disabled'}>■ Parar</button>
      </div>
      <label class="check big"><input type="checkbox" id="pbAuto" ${autoOn() ? 'checked' : ''}> Empezar solo al colocar el avión (quita el freno de parking y conecta el remolcador)</label>
      <p class="hint">El remolcador sigue la línea naranja y se suelta solo al llegar. Motores en ralentí o apagados.</p>
      <button id="pbClear" ${target ? '' : 'disabled'}>Borrar punto</button>`;
    $('#pbCenter').onclick = centerOnPlane;
    $('#pbHdg').oninput = (e) => { finalHdg = +e.target.value; draw(); box.querySelector('.section-head h3 span').textContent = String(finalHdg).padStart(3, '0') + '°'; };
    $('#pbHdg').onchange = render;
    box.querySelectorAll('[data-rel]').forEach((b) => b.onclick = () => {
      const base = live ? live.hdg : 0; finalHdg = Math.round((base + +b.dataset.rel + 360) % 360); draw(); render();
    });
    $('#pbStart').onclick = () => { clearInterval(autoT); autoT = null; startPush(); };
    $('#pbAuto').onchange = (e) => { store('simdirect.pbAuto', e.target.checked); if (e.target.checked) scheduleAuto(); else { clearInterval(autoT); autoT = null; showAuto(''); } };
    $('#pbStop').onclick = () => post('/api/pushback', { action: 'stop' });
    $('#pbClear').onclick = () => { clearInterval(autoT); autoT = null; target = null; finalHdg = null; draw(); render(); };
  }

  let lastRender = 0;
  window.onPushStatus = (st) => {
    if (!st) return;
    const changed = st.active !== srv.active || st.msg !== srv.msg;
    srv = st;
    if (st.active && st.target && !target) { target = st.target; finalHdg = st.final; }
    if (changed && isActive()) { draw(); if (Date.now() - lastRender > 400) { lastRender = Date.now(); render(); } }
    else if (st.active) draw();
  };

  // al entrar en Pushback: mapa del aeropuerto donde estás; al salir, la rueda vuelve a hacer zoom
  document.querySelectorAll('.tab[data-tab]').forEach((t) => t.addEventListener('click', () => {
    if (t.dataset.tab === 'push') {
      map.scrollWheelZoom.disable();
      render(); draw();
      if (live) centerOnPlane();
    } else map.scrollWheelZoom.enable();
  }));
  render();
  return { onMapClick, render };
})();
window.Pushback = Pushback;
