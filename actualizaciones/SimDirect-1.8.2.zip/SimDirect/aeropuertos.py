"""
SimDirect - base de datos libre de aeropuertos y pistas (OurAirports, dominio público).
Se descarga una vez en la carpeta «datos» y permite usar cualquier aeropuerto del mundo
y dibujar sus pistas aunque el simulador esté cerrado.
"""
import csv
import io
import math
import threading
import time
import urllib.request
from pathlib import Path

BASE = Path(__file__).resolve().parent
DATA = BASE / "datos"
SRC = "https://davidmegginson.github.io/ourairports-data/"
_lock = threading.Lock()
_airports = None
_runways = None
_names = []


def _download(name):
    DATA.mkdir(exist_ok=True)
    f = DATA / name
    if f.exists() and f.stat().st_size > 1000 and time.time() - f.stat().st_mtime < 60 * 86400:
        return f
    req = urllib.request.Request(SRC + name, headers={"User-Agent": "SimDirect/1.0"})
    with urllib.request.urlopen(req, timeout=120) as r:
        data = r.read()
    tmp = f.with_suffix(".tmp")
    tmp.write_bytes(data)
    tmp.replace(f)
    return f


def _f(x, d=None):
    try:
        return float(x)
    except (TypeError, ValueError):
        return d


def load():
    global _airports, _runways, _names
    with _lock:
        if _airports is not None:
            return True
        try:
            fa = _download("airports.csv")
            fr = _download("runways.csv")
        except Exception as exc:  # noqa: BLE001
            print(f"[!] No pude descargar la base de aeropuertos: {exc}", flush=True)
            return False
        aps = {}
        with open(fa, encoding="utf-8", errors="ignore", newline="") as fh:
            for row in csv.DictReader(fh):
                if row.get("type") in ("closed", "balloonport"):
                    continue
                code = (row.get("icao_code") or row.get("ident") or "").upper()
                ident = (row.get("ident") or "").upper()
                lat, lon = _f(row.get("latitude_deg")), _f(row.get("longitude_deg"))
                if not code or lat is None or lon is None:
                    continue
                ap = {"code": code, "name": row.get("name", ""), "lat": lat, "lon": lon,
                      "elev": int(_f(row.get("elevation_ft"), 0) or 0), "type": row.get("type", ""),
                      "city": row.get("municipality", ""), "country": row.get("iso_country", ""), "iata": row.get("iata_code", "")}
                aps[code] = ap
                if ident and ident != code:
                    aps.setdefault(ident, ap)
        rws = {}
        with open(fr, encoding="utf-8", errors="ignore", newline="") as fh:
            for row in csv.DictReader(fh):
                if row.get("closed") == "1":
                    continue
                key = (row.get("airport_ident") or "").upper()
                le = (_f(row.get("le_latitude_deg")), _f(row.get("le_longitude_deg")))
                he = (_f(row.get("he_latitude_deg")), _f(row.get("he_longitude_deg")))
                rws.setdefault(key, []).append({
                    "ends": [row.get("le_ident", ""), row.get("he_ident", "")],
                    "le": le if None not in le else None, "he": he if None not in he else None,
                    "heading": _f(row.get("le_heading_degT")),
                    "length_m": (_f(row.get("length_ft"), 0) or 0) * 0.3048,
                    "width_m": (_f(row.get("width_ft"), 0) or 0) * 0.3048,
                    "surface": row.get("surface", ""),
                })
        _airports, _runways = aps, rws
        _names = sorted({(a["code"], a["name"], a["city"], a["type"]) for a in aps.values()
                         if a["type"] in ("large_airport", "medium_airport", "small_airport")})
        print(f"[OK] Base de aeropuertos: {len(aps)} aeropuertos", flush=True)
        return True


def airport(code):
    if not load():
        return None
    a = _airports.get(code.upper().strip())
    if not a:
        return None
    out = dict(a)
    out["runways"] = []
    for r in _runways.get(a["code"], []) or _runways.get(code.upper(), []):
        rr = dict(r)
        if r["le"] and r["he"]:
            rr["lat"] = (r["le"][0] + r["he"][0]) / 2
            rr["lon"] = (r["le"][1] + r["he"][1]) / 2
            if rr["heading"] is None:
                k = math.cos(math.radians(r["le"][0]))
                rr["heading"] = (math.degrees(math.atan2((r["he"][1] - r["le"][1]) * k, r["he"][0] - r["le"][0])) + 360) % 360
        out["runways"].append(rr)
    return out


def search(q, limit=12):
    if not load():
        return []
    q = q.upper().strip()
    if not q:
        return []
    rank = {"large_airport": 0, "medium_airport": 1, "small_airport": 2}
    res = []
    for code, name, city, typ in _names:
        hay = f"{code} {name} {city}".upper()
        if code.startswith(q) or q in hay:
            res.append((0 if code.startswith(q) else 1, rank.get(typ, 3), code, name, city))
    res.sort()
    return [{"code": c, "name": n, "city": ci} for _, _, c, n, ci in res[:limit]]


# ------------------------------------------------------------------ búsquedas para SimCopilot
import unicodedata


def _norm(s):
    s = unicodedata.normalize("NFKD", str(s or "")).encode("ascii", "ignore").decode().lower()
    return " ".join(s.replace("-", " ").replace("/", " ").split())


ALIASES = {"londres": "london", "paris": "paris", "lisboa": "lisbon", "roma": "rome", "milan": "milan", "munich": "munich",
           "nueva york": "new york", "ginebra": "geneva", "bruselas": "brussels", "atenas": "athens", "estambul": "istanbul",
           "zurich": "zurich", "viena": "vienna", "amsterdam": "amsterdam", "berlin": "berlin", "fráncfort": "frankfurt",
           "francfort": "frankfurt", "oporto": "porto", "niza": "nice", "copenhague": "copenhagen", "estocolmo": "stockholm",
           "dublin": "dublin", "edimburgo": "edinburgh", "venecia": "venice", "napoles": "naples", "marsella": "marseille",
           "tenerife": "tenerife", "gran canaria": "gran canaria", "mallorca": "palma de mallorca", "ibiza": "ibiza"}
ALIASES.update({"sevilla": "seville", "la coruna": "a coruna", "coruna": "a coruna", "san sebastian": "san sebastian",
                "pamplona": "pamplona", "vigo": "vigo", "tokio": "tokyo", "pekin": "beijing", "moscu": "moscow", "varsovia": "warsaw",
                "praga": "prague", "budapest": "budapest", "lyon": "lyon", "burdeos": "bordeaux", "toulouse": "toulouse", "tolosa": "toulouse",
                "florencia": "florence", "turin": "turin", "bolonia": "bologna", "colonia": "cologne", "hamburgo": "hamburg",
                "manchester": "manchester", "el cairo": "cairo", "marrakech": "marrakesh", "argel": "algiers", "tanger": "tangier",
                "nueva delhi": "new delhi", "ciudad de mexico": "mexico city", "sao paulo": "sao paulo", "los angeles": "los angeles",
                "miami": "miami", "chicago": "chicago", "lanzarote": "lanzarote", "fuerteventura": "fuerteventura", "menorca": "menorca",
                "dubai": "dubai", "doha": "doha", "estrasburgo": "strasbourg", "basilea": "basel", "luxemburgo": "luxembourg"})
HUBS = {"london": "EGLL", "paris": "LFPG", "new york": "KJFK", "rome": "LIRF", "milan": "LIMC", "tokyo": "RJTT", "moscow": "UUEE",
        "tenerife": "GCTS", "istanbul": "LTFM", "berlin": "EDDB", "stockholm": "ESSA", "chicago": "KORD", "los angeles": "KLAX",
        "mexico city": "MMMX", "sao paulo": "SBGR", "dubai": "OMDB", "beijing": "ZBAA", "brussels": "EBBR", "venice": "LIPZ"}
RANK = {"large_airport": 0, "medium_airport": 1, "small_airport": 2}


def resolve(term, near=None, small=False):
    """Encuentra el aeropuerto principal para un nombre de ciudad, aeropuerto, OACI o IATA."""
    if not load() or not term:
        return None
    t = term.strip().upper()
    if len(t) == 4 and t in _airports:
        return airport(t)
    if len(t) == 3:
        for a in _airports.values():
            if a.get("iata") == t and a["type"] in RANK:
                return airport(a["code"])
    n = _norm(term)
    n = ALIASES.get(n, n)
    if n in HUBS and HUBS[n] in _airports:
        return airport(HUBS[n])
    best = None
    kinds = RANK if small else ("large_airport", "medium_airport")
    for a in _airports.values():
        if a["type"] not in kinds or not a["code"].isalpha() or len(a["code"]) != 4:
            continue
        city, name = _norm(a["city"]), _norm(a["name"])
        if city == n or name == n:
            score = 0
        elif city.startswith(n) or name.startswith(n):
            score = 1
        elif n in name or n in city:
            score = 2
        else:
            continue
        far = 0
        if near:
            dd = math.hypot(a["lat"] - near[0], (a["lon"] - near[1]) * math.cos(math.radians(near[0]))) * 60
            far = 0 if dd < 1600 else 1
        key = (far, score, RANK[a["type"]], 0 if a.get("iata") else 1)
        if best is None or key < best[0]:
            best = (key, a["code"])
    if best is None and not small:
        return resolve(term, near, True)
    return airport(best[1]) if best else None


def nearest_place(lat, lon, max_nm=60, avoid=()):
    """Nombre corto (5 letras) del sitio conocido más cercano, para nombrar puntos de la ruta."""
    if not load():
        return None
    cands = []
    for a in _airports.values():
        if a["type"] not in ("large_airport", "medium_airport", "small_airport") or not a["city"]:
            continue
        d = math.hypot(a["lat"] - lat, (a["lon"] - lon) * math.cos(math.radians(lat))) * 60
        if d <= max_nm:
            cands.append((d + (0 if a["type"] != "small_airport" else 8), a))
    for _, a in sorted(cands, key=lambda x: x[0]):
        nm = "".join(ch for ch in _norm(a["city"]).upper() if ch.isalpha())[:5]
        if len(nm) >= 3 and nm not in avoid:
            return nm
    return None


SPANISH = {v: k for k, v in ALIASES.items() if k != v and k not in ("fráncfort", "mallorca")}


def nice_name(a):
    """Nombre corto en español para mostrar: 'Lisboa', 'Lyon'..."""
    city = (a.get("city") or "").split(",")[0].split("(")[0].split("/")[0].strip()
    name = a.get("name") or a.get("code")
    if city and (_norm(city) in _norm(name) or a.get("type") == "large_airport"):
        base = city
    else:
        base = name.replace("International", "").replace("Airport", "").replace("Aeropuerto", "").strip().split(" ")[0] or city
    return SPANISH.get(_norm(base), base).title() if _norm(base) in SPANISH else base


def airports_around(lat, lon, dmin_nm, dmax_nm, kinds=("large_airport",)):
    if not load():
        return []
    out = []
    for a in _airports.values():
        if a["type"] not in kinds or len(a["code"]) != 4 or not a["code"].isalpha():
            continue
        d = math.degrees(math.acos(max(-1, min(1, math.sin(math.radians(lat)) * math.sin(math.radians(a["lat"])) +
                         math.cos(math.radians(lat)) * math.cos(math.radians(a["lat"])) * math.cos(math.radians(a["lon"] - lon)))))) * 60
        if dmin_nm <= d <= dmax_nm:
            out.append((d, a))
    return out
