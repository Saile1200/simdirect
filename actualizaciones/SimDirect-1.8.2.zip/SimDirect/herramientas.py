#!/usr/bin/env python3
"""
SimDirect - instalaciones automáticas (Windows):
  * ReShade + efectos + preset en MSFS 2024
  * Archivos de seguimiento de cabeza (NPClient / TrackIR) para la física de cámara
  * Arranque automático con MSFS 2024 (exe.xml)
  * Accesos directos en el menú Inicio y el escritorio
  * Actualizaciones de la app

También se ejecuta como ayudante con permisos de administrador:
  pythonw herramientas.py --copiar ORIGEN DESTINO MARCA
"""
import io
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
import time
import urllib.request
import zipfile
from pathlib import Path
from xml.sax.saxutils import escape

BASE = Path(__file__).resolve().parent
CONFIG_FILE = BASE / "config.json"
VERSION_FILE = BASE / "version.json"
UA = {"User-Agent": "SimDirect/1.0 (+MSFS2024)"}
IS_WIN = sys.platform == "win32"


# ------------------------------------------------------------------ utilidades
def load_config():
    try:
        return json.loads(CONFIG_FILE.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {}


def save_config(cfg):
    CONFIG_FILE.write_text(json.dumps(cfg, ensure_ascii=False, indent=1), encoding="utf-8")


def set_config(**kw):
    cfg = load_config()
    cfg.update(kw)
    save_config(cfg)
    return cfg


def app_version():
    try:
        return json.loads(VERSION_FILE.read_text(encoding="utf-8")).get("version", "0")
    except (OSError, ValueError):
        return "0"


def http_get(url, timeout=60):
    req = urllib.request.Request(url, headers=UA)
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return r.read()


def pythonw():
    exe = Path(sys.executable)
    w = exe.with_name("pythonw.exe")
    return w if w.exists() else exe


def copy_tree(src, dst):
    src, dst = Path(src), Path(dst)
    for p in src.rglob("*"):
        rel = p.relative_to(src)
        target = dst / rel
        if p.is_dir():
            target.mkdir(parents=True, exist_ok=True)
        else:
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(p, target)


def copy_tree_elevated(src, dst):
    """Copia una carpeta; si Windows no deja (Program Files), pide permiso de administrador una vez."""
    try:
        copy_tree(src, dst)
        return True, None
    except PermissionError:
        pass
    if not IS_WIN:
        return False, "Sin permisos para escribir en la carpeta del juego"
    import ctypes
    marker = Path(tempfile.gettempdir()) / f"simdirect_copy_{os.getpid()}_{int(time.time())}.ok"
    args = f'"{Path(__file__)}" --copiar "{src}" "{dst}" "{marker}"'
    rc = ctypes.windll.shell32.ShellExecuteW(None, "runas", str(pythonw()), args, str(BASE), 0)
    if rc <= 32:
        return False, "Hace falta permiso de administrador (has pulsado «No» en la ventana de Windows)"
    for _ in range(240):
        if marker.exists():
            txt = marker.read_text(encoding="utf-8", errors="ignore")
            marker.unlink(missing_ok=True)
            return (True, None) if txt.startswith("ok") else (False, txt)
        time.sleep(0.5)
    return False, "La copia con permisos de administrador no terminó"


def remove_files_elevated(files):
    files = [Path(f) for f in files if Path(f).exists()]
    if not files:
        return True, None
    try:
        for f in files:
            f.unlink()
        return True, None
    except PermissionError:
        pass
    if not IS_WIN:
        return False, "Sin permisos"
    import ctypes
    marker = Path(tempfile.gettempdir()) / f"simdirect_del_{int(time.time())}.ok"
    lst = Path(tempfile.gettempdir()) / f"simdirect_del_{int(time.time())}.txt"
    lst.write_text("\n".join(str(f) for f in files), encoding="utf-8")
    args = f'"{Path(__file__)}" --borrar "{lst}" "{marker}"'
    rc = ctypes.windll.shell32.ShellExecuteW(None, "runas", str(pythonw()), args, str(BASE), 0)
    if rc <= 32:
        return False, "Hace falta permiso de administrador"
    for _ in range(120):
        if marker.exists():
            marker.unlink(missing_ok=True)
            return True, None
        time.sleep(0.5)
    return False, "No se pudieron borrar los archivos"


# ------------------------------------------------------------------ MSFS
def msfs_userdata_dirs():
    """Carpetas donde MSFS 2024 lee exe.xml (Steam y Microsoft Store)."""
    out = []
    appdata = os.environ.get("APPDATA")
    local = os.environ.get("LOCALAPPDATA")
    if appdata:
        p = Path(appdata) / "Microsoft Flight Simulator 2024"
        if p.exists():
            out.append(p)
    if local:
        p = Path(local) / "Packages" / "Microsoft.Limitless_8wekyb3d8bbwe" / "LocalCache"
        if p.exists():
            out.append(p)
    return out


def is_store_install(msfs_dir):
    return bool(msfs_dir) and "windowsapps" in str(msfs_dir).lower()


# ------------------------------------------------------------------ ReShade
RESHADE_PAGE = "https://reshade.me"
SHADER_ZIPS = [
    ("https://github.com/crosire/reshade-shaders/archive/refs/heads/slim.zip", ""),
    ("https://github.com/CeeJayDK/SweetFX/archive/refs/heads/master.zip", ""),
]


def extract_reshade_dll(setup_bytes):
    """El instalador de ReShade lleva un .zip pegado al final (bloques de 512 bytes) con ReShade64.dll."""
    sig = b"PK\x03\x04"
    for off in range(0, len(setup_bytes) - 30, 512):
        if setup_bytes[off:off + 4] == sig and max(setup_bytes[off + 4:off + 30]) != 0:
            try:
                z = zipfile.ZipFile(io.BytesIO(setup_bytes[off:]))
                return z.read("ReShade64.dll")
            except (zipfile.BadZipFile, KeyError):
                continue
    raise RuntimeError("No se encontró ReShade64.dll dentro del instalador")


def reshade_ini(preset_name):
    return f"""[GENERAL]
EffectSearchPaths=.\\reshade-shaders\\Shaders\\**
TextureSearchPaths=.\\reshade-shaders\\Textures\\**
PresetPath=.\\{preset_name}
PerformanceMode=0
PreprocessorDefinitions=RESHADE_DEPTH_INPUT_IS_REVERSED=1,RESHADE_DEPTH_INPUT_IS_UPSIDE_DOWN=0,RESHADE_DEPTH_LINEARIZATION_FAR_PLANE=1000.0
SkipLoadingDisabledEffects=1

[INPUT]
KeyOverlay=36,0,0,0
KeyEffects=145,0,0,0
KeyNextPreset=0,0,0,0
KeyPreviousPreset=0,0,0,0
KeyReload=123,1,1,1

[OVERLAY]
TutorialProgress=4
ShowFPS=0
ShowClock=0
Language=es-ES

[SCREENSHOT]
SavePath=.\\
"""


def install_reshade(msfs_dir, progress=lambda m: None, preset_name="SimDirect_Personal.ini"):
    msfs_dir = Path(msfs_dir)
    if is_store_install(msfs_dir):
        return {"ok": False, "error": "Tu MSFS es de Microsoft Store/Game Pass: Windows no deja poner ReShade "
                                      "en esa carpeta automáticamente. Usa el instalador oficial de ReShade."}
    stage = Path(tempfile.mkdtemp(prefix="simdirect_rs_"))
    try:
        progress("Buscando la última versión de ReShade…")
        html = http_get(RESHADE_PAGE).decode("utf-8", "ignore")
        m = re.findall(r'(/downloads/ReShade_Setup_[\d.]+\.exe)', html)
        if not m:
            raise RuntimeError("No encontré el enlace de descarga en reshade.me")
        url = RESHADE_PAGE + m[0]
        version = re.search(r"ReShade_Setup_([\d.]+)\.exe", url).group(1)
        progress(f"Descargando ReShade {version}…")
        (stage / "dxgi.dll").write_bytes(extract_reshade_dll(http_get(url, 180)))

        shaders = stage / "reshade-shaders"
        for zurl, _ in SHADER_ZIPS:
            progress("Descargando efectos (" + zurl.split("/")[4] + ")…")
            z = zipfile.ZipFile(io.BytesIO(http_get(zurl, 180)))
            for name in z.namelist():
                parts = name.split("/", 1)
                if len(parts) < 2 or not parts[1] or name.endswith("/"):
                    continue
                rel = parts[1]
                if rel.startswith(("Shaders/", "Textures/")):
                    out = shaders / rel
                    out.parent.mkdir(parents=True, exist_ok=True)
                    out.write_bytes(z.read(name))

        # presets de SimDirect
        for p in (BASE / "reshade").glob("SimDirect_*.ini"):
            shutil.copy2(p, stage / p.name)
        if not (stage / preset_name).exists():
            shutil.copy2(BASE / "reshade" / "SimDirect_Realista.ini", stage / preset_name)
        shutil.copy2(stage / preset_name, stage / RS_ACTIVE)
        if not (msfs_dir / "ReShade.ini").exists():
            (stage / "ReShade.ini").write_text(reshade_ini(RS_ACTIVE), encoding="utf-8")

        progress("Copiando a la carpeta del juego…")
        ok, err = copy_tree_elevated(stage, msfs_dir)
        if not ok:
            return {"ok": False, "error": err}
        set_config(reshade_version=version)
        ensure_reshade_ini(msfs_dir)
        return {"ok": True, "version": version}
    except Exception as exc:  # noqa: BLE001
        return {"ok": False, "error": f"{exc}"}
    finally:
        shutil.rmtree(stage, ignore_errors=True)


RS_ACTIVE = "SimDirect_Activo.ini"        # el preset que lee siempre ReShade; la app escribe en él
RS_RELOAD_KEY = "123,1,1,1"                # Ctrl+Mayús+Alt+F12 = recargar efectos (la app lo pulsa sola)


def _write_in_msfs(msfs_dir, name, text):
    p = Path(msfs_dir) / name
    try:
        p.write_text(text, encoding="utf-8")
        return True
    except PermissionError:
        stage = Path(tempfile.mkdtemp(prefix="simdirect_ini_"))
        (stage / name).write_text(text, encoding="utf-8")
        ok, _ = copy_tree_elevated(stage, msfs_dir)
        shutil.rmtree(stage, ignore_errors=True)
        return ok
    except OSError:
        return False


def ensure_reshade_ini(msfs_dir):
    """ReShade.ini siempre apunta a SimDirect_Activo.ini y tiene la tecla de recarga."""
    ini = Path(msfs_dir) / "ReShade.ini"
    try:
        txt = ini.read_text(encoding="utf-8", errors="ignore")
    except OSError:
        return False
    new = txt
    if re.search(r"(?m)^PresetPath=", new):
        new = re.sub(r"(?m)^PresetPath=.*$", lambda m: f"PresetPath=.\\{RS_ACTIVE}", new)
    else:
        new = new.replace("[GENERAL]", f"[GENERAL]\nPresetPath=.\\{RS_ACTIVE}", 1)
    if re.search(r"(?m)^KeyReload=", new):
        new = re.sub(r"(?m)^KeyReload=.*$", "KeyReload=" + RS_RELOAD_KEY, new)
    elif "[INPUT]" in new:
        new = new.replace("[INPUT]", "[INPUT]\nKeyReload=" + RS_RELOAD_KEY, 1)
    else:
        new += "\n[INPUT]\nKeyReload=" + RS_RELOAD_KEY + "\n"
    if new == txt:
        return True
    return _write_in_msfs(msfs_dir, "ReShade.ini", new)


def set_reshade_preset(msfs_dir, preset_name, text=None):
    """Copia el preset elegido (o el texto dado) al preset activo. Devuelve True si se aplicó."""
    if text is None:
        src = Path(msfs_dir) / preset_name
        if not src.exists():
            src = BASE / "reshade" / preset_name
        try:
            text = src.read_text(encoding="utf-8", errors="ignore")
        except OSError:
            return False
    ensure_reshade_ini(msfs_dir)
    ok = _write_in_msfs(msfs_dir, RS_ACTIVE, text)
    if ok:
        set_config(reshade_preset=preset_name)
    return ok


def uninstall_reshade(msfs_dir):
    d = Path(msfs_dir)
    files = [d / "dxgi.dll", d / "ReShade.ini", d / "ReShade.log", d / RS_ACTIVE]
    ok, err = remove_files_elevated(files)
    return {"ok": ok, "error": err}


def reshade_installed(msfs_dir):
    return bool(msfs_dir) and (Path(msfs_dir) / "dxgi.dll").exists() and (Path(msfs_dir) / "ReShade.ini").exists()


# ------------------------------------------------------------------ Seguimiento de cabeza (NPClient)
TRACK_DIR = BASE / "seguimiento"
OT_API = "https://api.github.com/repos/opentrack/opentrack/releases/latest"


def find_tracking_files(root=TRACK_DIR):
    root = Path(root)
    if not root.exists():
        return None
    npc = next(root.rglob("NPClient64.dll"), None)
    if not npc:
        return None
    tir = next(root.rglob("TrackIR.exe"), None)
    csv = next(root.rglob("facetracknoir supported games.csv"), None)
    return {"dir": str(npc.parent), "trackir": str(tir) if tir else None, "csv": str(csv) if csv else None}


def install_tracking(progress=lambda m: None):
    """Descarga OpenTrack portable (sin instalar nada en Windows) y deja listos sus archivos de TrackIR."""
    try:
        progress("Buscando OpenTrack en GitHub…")
        rel = json.loads(http_get(OT_API))
        assets = rel.get("assets", [])
        pick = next((a for a in assets if a["name"].lower().endswith(".7z") and "portable" in a["name"].lower()), None)
        pick = pick or next((a for a in assets if a["name"].lower().endswith(".zip") and "portable" in a["name"].lower()), None)
        if not pick:
            raise RuntimeError("No encontré la versión portable de OpenTrack")
        progress(f"Descargando {pick['name']}…")
        data = http_get(pick["browser_download_url"], 300)
        tmp = Path(tempfile.mkdtemp(prefix="simdirect_ot_"))
        try:
            arc = tmp / pick["name"]
            arc.write_bytes(data)
            progress("Descomprimiendo…")
            out = tmp / "x"
            if arc.suffix == ".7z":
                done = False
                try:
                    import py7zr
                    with py7zr.SevenZipFile(arc, "r") as z:
                        z.extractall(out)
                    done = True
                except Exception:  # noqa: BLE001  (p. ej. filtro BCJ2 no soportado)
                    shutil.rmtree(out, ignore_errors=True)
                if not done:
                    out.mkdir(parents=True, exist_ok=True)
                    r = subprocess.run(["tar", "-xf", str(arc), "-C", str(out)],
                                       creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0), check=False)
                    done = r.returncode == 0 and find_tracking_files(out) is not None
                if not done:
                    setup = next((a for a in assets if a["name"].lower().endswith("setup.exe")), None)
                    if not setup:
                        raise RuntimeError("No pude descomprimir OpenTrack")
                    progress("Usando el instalador de OpenTrack (Windows pedirá permiso)…")
                    exe = tmp / setup["name"]
                    exe.write_bytes(http_get(setup["browser_download_url"], 300))
                    shutil.rmtree(out, ignore_errors=True)
                    ps = (f"Start-Process -FilePath '{exe}' -ArgumentList '/VERYSILENT','/SUPPRESSMSGBOXES',"
                          f"'/NORESTART','/DIR=\"{out}\"' -Verb RunAs -Wait")
                    subprocess.run(["powershell", "-NoProfile", "-Command", ps], check=False,
                                   creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
            else:
                zipfile.ZipFile(arc).extractall(out)
            if TRACK_DIR.exists():
                shutil.rmtree(TRACK_DIR, ignore_errors=True)
            shutil.copytree(out, TRACK_DIR)
        finally:
            shutil.rmtree(tmp, ignore_errors=True)
        info = find_tracking_files()
        if not info:
            raise RuntimeError("Faltan archivos de seguimiento en la descarga")
        set_config(tracking=info, tracking_version=rel.get("tag_name"))
        return {"ok": True, "version": rel.get("tag_name")}
    except Exception as exc:  # noqa: BLE001
        return {"ok": False, "error": f"{exc}"}


# ------------------------------------------------------------------ IA local (Ollama)
def find_ollama():
    cands = []
    local = os.environ.get("LOCALAPPDATA")
    if local:
        cands.append(Path(local) / "Programs" / "Ollama" / "ollama.exe")
    for env in ("ProgramFiles", "ProgramFiles(x86)"):
        if os.environ.get(env):
            cands.append(Path(os.environ[env]) / "Ollama" / "ollama.exe")
    found = next((c for c in cands if c.exists()), None)
    if found:
        return found
    w = shutil.which("ollama")
    return Path(w) if w else None


def ollama_up():
    try:
        http_get("http://127.0.0.1:11434/api/tags", 2)
        return True
    except Exception:  # noqa: BLE001
        return False


def start_ollama():
    exe = find_ollama()
    if not exe:
        return False
    if ollama_up():
        return True
    subprocess.Popen([str(exe), "serve"], creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
                     stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    for _ in range(40):
        if ollama_up():
            return True
        time.sleep(0.5)
    return False


def install_ai(model, progress=lambda m: None):
    """Instala Ollama (gratis) y descarga el modelo de IA elegido."""
    try:
        if not find_ollama():
            progress("Instalando Ollama (motor de IA gratuito)…")
            subprocess.run(["winget", "install", "-e", "--id", "Ollama.Ollama", "--silent",
                            "--accept-package-agreements", "--accept-source-agreements"],
                           creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0), check=False, timeout=1200)
            if not find_ollama():
                return {"ok": False, "error": "No se pudo instalar Ollama. Descárgalo de ollama.com y vuelve a pulsar."}
        progress("Arrancando la IA…")
        if not start_ollama():
            return {"ok": False, "error": "Ollama no arranca. Reinicia el PC y vuelve a probar."}
        progress(f"Descargando el modelo {model}…")
        req = urllib.request.Request("http://127.0.0.1:11434/api/pull", data=json.dumps({"name": model}).encode(),
                                     headers={"Content-Type": "application/json"})
        with urllib.request.urlopen(req, timeout=7200) as r:
            for line in r:
                try:
                    j = json.loads(line)
                except ValueError:
                    continue
                if j.get("error"):
                    return {"ok": False, "error": j["error"]}
                if j.get("total"):
                    pct = 100 * j.get("completed", 0) / j["total"]
                    progress(f"Descargando {model}: {pct:.0f}% de {j['total'] / 1e9:.1f} GB")
                elif j.get("status"):
                    progress(j["status"])
        set_config(ai_model=model)
        return {"ok": True}
    except Exception as exc:  # noqa: BLE001
        return {"ok": False, "error": f"{exc}"}


# ------------------------------------------------------------------ Arranque con MSFS (exe.xml)
ADDON_NAME = "SimDirect"


def _exe_xml_entry():
    return (f"  <Launch.Addon>\n    <Name>{ADDON_NAME}</Name>\n    <Disabled>False</Disabled>\n"
            f"    <Path>{escape(str(pythonw()))}</Path>\n"
            f"    <CommandLine>&quot;{escape(str(BASE / 'SimDirect.pyw'))}&quot; --msfs</CommandLine>\n"
            f"  </Launch.Addon>\n")


EXE_XML_EMPTY = """<?xml version="1.0" encoding="Windows-1252"?>
<SimBase.Document Type="SimConnect" version="1,0">
  <Descr>Auto launch external applications on MSFS start</Descr>
  <Filename>exe.xml</Filename>
  <Disabled>False</Disabled>
  <Launch.ManualLoad>False</Launch.ManualLoad>
</SimBase.Document>
"""
_ENTRY_RE = re.compile(r"\s*<Launch\.Addon>(?:(?!</Launch\.Addon>).)*?<Name>SimDirect</Name>.*?</Launch\.Addon>\s*\n?", re.S)


def msfs_autostart(enable):
    dirs = msfs_userdata_dirs()
    if not dirs:
        return {"ok": False, "error": "No encontré la carpeta de datos de MSFS 2024. Abre el simulador una vez y vuelve a probar."}
    done = []
    for d in dirs:
        f = d / "exe.xml"
        try:
            txt = f.read_text(encoding="cp1252", errors="ignore") if f.exists() else EXE_XML_EMPTY
            if f.exists() and not (d / "exe.xml.simdirect-backup").exists():
                shutil.copy2(f, d / "exe.xml.simdirect-backup")
            txt = _ENTRY_RE.sub("\n", txt)
            if enable:
                txt = txt.replace("</SimBase.Document>", _exe_xml_entry() + "</SimBase.Document>")
            f.write_text(txt, encoding="cp1252", errors="ignore")
            done.append(str(f))
        except OSError as exc:
            return {"ok": False, "error": f"No pude editar {f}: {exc}"}
    set_config(msfs_autostart=bool(enable))
    return {"ok": True, "files": done}


def msfs_autostart_enabled():
    for d in msfs_userdata_dirs():
        f = d / "exe.xml"
        try:
            if f.exists() and "<Name>SimDirect</Name>" in f.read_text(encoding="cp1252", errors="ignore"):
                return True
        except OSError:
            pass
    return False


# ------------------------------------------------------------------ Accesos directos
def desktop_dir():
    """Carpeta real del escritorio (también si Windows la tiene en OneDrive)."""
    if not IS_WIN:
        return None
    import ctypes
    from ctypes import wintypes
    buf = ctypes.create_unicode_buffer(wintypes.MAX_PATH)
    if ctypes.windll.shell32.SHGetFolderPathW(None, 0x10, None, 0, buf) == 0:
        return Path(buf.value)
    return Path.home() / "Desktop"


def startup_dir():
    appdata = os.environ.get("APPDATA")
    return Path(appdata) / "Microsoft" / "Windows" / "Start Menu" / "Programs" / "Startup" if appdata else None


def set_startup(enable):
    """Arrancar el servidor de SimDirect con Windows (en segundo plano, sin ventana)."""
    d = startup_dir()
    if not d:
        return {"ok": False, "error": "No disponible"}
    lnk = d / "SimDirect (segundo plano).lnk"
    set_config(background=bool(enable))
    if not enable:
        lnk.unlink(missing_ok=True)
        return {"ok": True}
    q = lambda x: str(x).replace("'", "''")
    ps = (f"$s=(New-Object -ComObject WScript.Shell).CreateShortcut('{q(lnk)}');$s.TargetPath='{q(pythonw())}';"
          f"$s.Arguments='\"{q(BASE / 'SimDirect.pyw')}\" --server';$s.WorkingDirectory='{q(BASE)}';"
          f"$s.IconLocation='{q(BASE / 'web' / 'logo.ico')},0';$s.WindowStyle=7;$s.Save()")
    subprocess.run(["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass", "-Command", ps],
                   creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0), timeout=30, check=False)
    return {"ok": lnk.exists(), "error": None if lnk.exists() else "Windows no dejó crear el acceso de inicio"}


def ensure_shortcuts():
    d = desktop_dir()
    if d and not (d / "SimDirect.lnk").exists():
        return create_shortcuts()
    return {"ok": True, "desktop": True}


def create_shortcuts():
    """Iconos de SimDirect en el escritorio (aunque esté en OneDrive) y en el menú Inicio."""
    if not IS_WIN:
        return {"ok": False}
    q = lambda x: str(x).replace("'", "''")
    ps = f"""
$ws = New-Object -ComObject WScript.Shell
$made = @()
$dirs = @([Environment]::GetFolderPath('Desktop'), (Join-Path ([Environment]::GetFolderPath('Programs')) ''))
foreach ($d in $dirs) {{
  try {{
    $l = Join-Path $d 'SimDirect.lnk'
    $s = $ws.CreateShortcut($l)
    $s.TargetPath = '{q(pythonw())}'
    $s.Arguments = '"{q(BASE / 'SimDirect.pyw')}"'
    $s.WorkingDirectory = '{q(BASE)}'
    $s.IconLocation = '{q(BASE / 'web' / 'logo.ico')},0'
    $s.Description = 'SimDirect para Microsoft Flight Simulator 2024'
    $s.Save()
    if (Test-Path $l) {{ $made += $l }}
  }} catch {{ }}
}}
$made -join '|'
"""
    try:
        r = subprocess.run(["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass", "-Command", ps],
                           capture_output=True, text=True, timeout=40,
                           creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
        made = [x for x in r.stdout.strip().split("|") if x]
    except (OSError, subprocess.SubprocessError):
        made = []
    desktop = any("programs" not in m.lower() and "menú inicio" not in m.lower() and "start menu" not in m.lower() for m in made)
    return {"ok": bool(made), "made": made, "desktop": desktop,
            "error": None if desktop else "Windows no dejó crear el icono del escritorio (protección contra ransomware). Está en el menú Inicio."}


# ------------------------------------------------------------------ Actualizaciones
KEEP = {"config.json", "planes", "planes_msfs", "sonidos", ".venv", "seguimiento", "datos", "actualizaciones", ".ventana",
        "camara/camara_ajustes.json", "reshade/ajustes_reshade.json", "reshade/SimDirect_Personal.ini", "grabaciones", "Cine"}


UPD_DIR = BASE / "actualizaciones"


def _vt(v):
    return tuple(int(x) for x in re.findall(r"\d+", str(v))[:4])


def check_update():
    """Busca versión nueva: primero en la carpeta «actualizaciones», luego en el servidor configurado."""
    cur = app_version()
    # canal local (las versiones que te instalo directamente en el PC)
    lv = UPD_DIR / "version.json"
    if lv.exists():
        try:
            info = json.loads(lv.read_text(encoding="utf-8"))
            z = UPD_DIR / info.get("zip", "")
            if z.is_file() and _vt(info.get("version", "0")) > _vt(cur):
                return {"ok": True, "configured": True, "current": cur, "latest": info.get("version"),
                        "notes": info.get("notes", ""), "zip": str(z), "available": True}
        except (OSError, ValueError):
            pass
    cfg = load_config()
    url = cfg.get("update_url")
    if not url and VERSION_FILE.exists():
        try:
            url = json.loads(VERSION_FILE.read_text(encoding="utf-8")).get("update_url")
        except ValueError:
            url = None
    if not url:
        return {"ok": True, "available": False, "current": cur, "configured": lv.exists()}
    try:
        info = json.loads(http_get(url.rstrip("/") + "/version.json", 20))
    except Exception as exc:  # noqa: BLE001
        return {"ok": False, "error": f"No se pudo comprobar: {exc}", "current": cur, "configured": True}
    zipurl = info.get("zip", "")
    if zipurl and not zipurl.startswith("http"):
        zipurl = url.rstrip("/") + "/" + zipurl
    return {"ok": True, "configured": True, "current": cur, "latest": info.get("version"),
            "notes": info.get("notes", ""), "zip": zipurl, "available": _vt(info.get("version", "0")) > _vt(cur)}


def apply_update(zip_url):
    try:
        data = Path(zip_url).read_bytes() if zip_url and Path(zip_url).is_file() else http_get(zip_url, 300)
        z = zipfile.ZipFile(io.BytesIO(data))
        names = z.namelist()
        prefix = names[0].split("/")[0] + "/" if all(n.startswith(names[0].split("/")[0] + "/") for n in names) else ""
        for n in names:
            rel = n[len(prefix):]
            if not rel or n.endswith("/"):
                continue
            if any(rel == k or rel.startswith(k + "/") for k in KEEP):
                continue
            out = BASE / rel
            out.parent.mkdir(parents=True, exist_ok=True)
            out.write_bytes(z.read(n))
        (BASE / ".venv" / ".instalado_v5").unlink(missing_ok=True)  # reinstala dependencias si cambian
        return {"ok": True}
    except Exception as exc:  # noqa: BLE001
        return {"ok": False, "error": f"{exc}"}


# ------------------------------------------------------------------ modo ayudante (administrador)
if __name__ == "__main__":
    if len(sys.argv) >= 5 and sys.argv[1] == "--copiar":
        mark = Path(sys.argv[4])
        try:
            copy_tree(sys.argv[2], sys.argv[3])
            mark.write_text("ok", encoding="utf-8")
        except Exception as e:  # noqa: BLE001
            mark.write_text(f"error: {e}", encoding="utf-8")
    elif len(sys.argv) >= 4 and sys.argv[1] == "--borrar":
        for line in Path(sys.argv[2]).read_text(encoding="utf-8").splitlines():
            try:
                Path(line).unlink()
            except OSError:
                pass
        Path(sys.argv[3]).write_text("ok", encoding="utf-8")
