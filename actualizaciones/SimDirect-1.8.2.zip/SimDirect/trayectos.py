#!/usr/bin/env python3
"""
SimDirect - recorrido de los jugadores online (MSFS, VATSIM e IVAO).

Las redes solo dan la posición actual, así que SimDirect va guardando los puntos de cada
jugador cada vez que se actualiza el tráfico. Con el ratón encima de un avión se dibuja
lo que ha volado (y, en línea discontinua, desde su aeropuerto de salida hasta el primer
punto guardado).
"""
import math
import threading
import time
from collections import deque

_lock = threading.Lock()
TRACKS = {}             # "red:CALLSIGN" -> {"pts": deque[(lat, lon, alt, t)], "seen", "dep", "arr", "since"}
_last_prune = 0.0
MAX_PTS = 4000
FORGET_S = 45 * 60      # si no se ve a un jugador en 45 min, se olvida su recorrido


def _km(a_lat, a_lon, b_lat, b_lon):
    k = math.cos(math.radians((a_lat + b_lat) / 2))
    return math.hypot((b_lat - a_lat) * 111.0, (b_lon - a_lon) * 111.0 * k)


def key(net, cs):
    return f"{net}:{str(cs or '').strip().upper()}"


def record(pilots):
    global _last_prune
    now = time.time()
    with _lock:
        for p in pilots:
            cs = p.get("cs")
            try:
                lat, lon = float(p["lat"]), float(p["lon"])
                alt = float(p.get("alt") or 0)
                gs = float(p.get("gs") or 0)
            except (KeyError, TypeError, ValueError):
                continue
            if not cs or (abs(lat) < 1e-6 and abs(lon) < 1e-6):
                continue
            k = key(p.get("net"), cs)
            t = TRACKS.get(k)
            dep, arr = (p.get("dep") or "").upper(), (p.get("arr") or "").upper()
            if t is None or (dep and t["dep"] and dep != t["dep"]):
                t = TRACKS[k] = {"pts": deque(maxlen=MAX_PTS), "seen": now, "dep": dep, "arr": arr, "since": now}
            t["dep"], t["arr"] = dep or t["dep"], arr or t["arr"]
            pts = t["pts"]
            if pts:
                la, lo, al, tt = pts[-1]
                d = _km(la, lo, lat, lon)
                dt = max(1.0, now - tt)
                # salto imposible (se ha recolocado o es otro vuelo): empieza de cero
                if d > max(60.0, (max(gs, 250) * 1.852 / 3600) * dt * 3):
                    pts.clear()
                    t["since"] = now
                elif d < 0.2 and abs(alt - al) < 250:
                    t["seen"] = now
                    continue
            pts.append((round(lat, 5), round(lon, 5), int(alt), int(now)))
            t["seen"] = now
        if now - _last_prune > 60:
            _last_prune = now
            for k in [k for k, t in TRACKS.items() if now - t["seen"] > FORGET_S]:
                TRACKS.pop(k, None)


def get(net, cs):
    with _lock:
        t = TRACKS.get(key(net, cs))
        if not t:
            return None
        return {"pts": [[a, b, c] for a, b, c, _ in t["pts"]], "dep": t["dep"], "arr": t["arr"],
                "since": int(t["since"])}
