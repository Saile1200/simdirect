#!/usr/bin/env python3
"""
Plan del avión: lee el plan de vuelo que metes a mano en el avión (FMS, EFB o mapa del mundo)
y lo pasa a la app de SimDirect.

  1. Le pide a MSFS que guarde el vuelo (SimConnect_FlightSave) en datos/plan_avion y lee
     el .PLN o, si no hay, la sección del plan activo del .FLT.
  2. Si eso no funciona, va montando el plan con los puntos que da el GPS del avión
     (punto anterior y siguiente) mientras vuelas.

Todo se hace desde el hilo de SimConnect (tick); la lectura del archivo va en otro hilo.
"""
import ctypes
import os
import re
import threading
import time
import xml.etree.ElementTree as ET
from pathlib import Path

BASE = Path(__file__).resolve().parent
DIR = BASE / "datos" / "plan_avion"
STEM = "simdirect_plan_avion"

# variables extra del GPS (las de texto se saltan en «modo seguro»)
GPS_VARS = {
    "gps_count": ("GPS FLIGHT PLAN WP COUNT", "number"),
    "gps_index": ("GPS FLIGHT PLAN WP INDEX", "number"),
    "gps_next_lat": ("GPS WP NEXT LAT", "degrees"),
    "gps_next_lon": ("GPS WP NEXT LON", "degrees"),
    "gps_next_alt": ("GPS WP NEXT ALT", "feet"),
    "gps_prev_lat": ("GPS WP PREV LAT", "degrees"),
    "gps_prev_lon": ("GPS WP PREV LON", "degrees"),
    "gps_next_id": ("GPS WP NEXT ID", "String"),
    "gps_prev_id": ("GPS WP PREV ID", "String"),
}
GPS_TEXT = {"gps_next_id", "gps_prev_id"}


def _txt(v):
    if isinstance(v, bytes):
        v = v.split(b"\x00")[0].decode("latin-1", "ignore")
    return str(v or "").strip().upper()[:10]


def _num(v):
    try:
        f = float(v)
        return f if f == f else 0.0
    except (TypeError, ValueError):
        return 0.0


def parse_coord(s):
    """N41° 17' 49.00" · N41° 17.83' · N41.2969 · 41.2969 -> grados con signo."""
    s = str(s or "").strip().replace("º", "°")
    m = re.match(r"^([NSEW])?\s*(-?\d+(?:\.\d+)?)\s*°?\s*(?:(\d+(?:\.\d+)?)\s*'\s*(?:(\d+(?:\.\d+)?)\s*\"?)?)?", s)
    if not m or m.group(2) is None:
        return None
    v = abs(float(m.group(2))) + float(m.group(3) or 0) / 60 + float(m.group(4) or 0) / 3600
    neg = m.group(1) in ("S", "W") or m.group(2).startswith("-")
    return -v if neg else v


def parse_lla(s):
    parts = [p.strip() for p in str(s or "").split(",")]
    if len(parts) < 2:
        return None
    lat, lon = parse_coord(parts[0]), parse_coord(parts[1])
    if lat is None or lon is None:
        return None
    alt = _num(parts[2]) if len(parts) > 2 else 0.0
    return lat, lon, alt


def parse_pln(text):
    root = ET.fromstring(text.encode("utf-8") if isinstance(text, str) else text)
    fp = root.find(".//FlightPlan.FlightPlan")
    if fp is None:
        return None
    pts = []
    for w in fp.findall("ATCWaypoint"):
        pos = parse_lla(w.findtext("WorldPosition"))
        if not pos:
            continue
        pts.append({"name": (w.get("id") or w.findtext("ICAO/ICAOIdent") or "WP").strip().upper()[:10],
                    "type": (w.findtext("ATCWaypointType") or "").strip(),
                    "lat": pos[0], "lon": pos[1], "alt": pos[2]})
    return _shape(pts, _num(fp.findtext("CruisingAlt")), (fp.findtext("DepartureID") or "").strip().upper(),
                  (fp.findtext("DestinationID") or "").strip().upper())


def parse_flt(text):
    """Sección [ATC_ActiveFlightPlan.0] del .FLT (formato antiguo de FS)."""
    m = re.search(r"(?ims)^\[ATC_ActiveFlightPlan\.0\]\s*$(.*?)(?=^\[|\Z)", text)
    if not m:
        return None
    sec = m.group(1)
    kv = dict(re.findall(r"(?m)^\s*([\w.]+)\s*=\s*(.*?)\s*$", sec))
    pts = []
    for key in sorted((k for k in kv if k.lower().startswith("waypoint.")), key=lambda k: int(re.sub(r"\D", "", k) or 0)):
        f = [x.strip() for x in kv[key].split(",")]
        ci = next((i for i, x in enumerate(f) if re.match(r"^[NS]\s*\d", x)), None)
        if ci is None or ci + 1 >= len(f):
            continue
        lat, lon = parse_coord(f[ci]), parse_coord(f[ci + 1])
        if lat is None or lon is None:
            continue
        cand = ([f[ci - 2]] if ci >= 2 else []) + [f[1] if len(f) > 1 else ""] + f[:ci]
        ident = next((x for x in cand if re.match(r"^[A-Z0-9]{2,7}$", x.upper()) and x.upper() not in ("A", "V", "N", "I", "U")), "WP").upper()
        typ = next((x for x in f[:ci] if x.upper() in ("A", "V", "N", "I", "U")), "")
        alt = _num(f[ci + 2]) if ci + 2 < len(f) else 0.0
        pts.append({"name": ident, "type": "Airport" if typ.upper() == "A" else typ, "lat": lat, "lon": lon, "alt": alt})
    dep = (kv.get("departure_id", "").split(",")[0] or "").strip().upper()
    arr = (kv.get("destination_id", "").split(",")[0] or "").strip().upper()
    return _shape(pts, _num(kv.get("cruising_altitude")), dep, arr)


def _shape(pts, cruise, dep_id="", arr_id=""):
    if len(pts) < 2:
        return None
    dep = arr = None
    if pts[0]["type"] == "Airport" or (dep_id and pts[0]["name"] == dep_id):
        dep = pts.pop(0)
    if pts and (pts[-1]["type"] == "Airport" or (arr_id and pts[-1]["name"] == arr_id)):
        arr = pts.pop()
    clean = lambda p: {"name": p["name"], "lat": round(p["lat"], 6), "lon": round(p["lon"], 6), "alt": round(p["alt"])}
    return {"dep": clean(dep) if dep else None, "arr": clean(arr) if arr else None,
            "waypoints": [clean(p) for p in pts[:180]], "cruise": int(cruise) if cruise > 500 else None}


def signature(plan):
    if not plan:
        return ""
    names = [(plan.get("dep") or {}).get("name", "")] + [w["name"] for w in plan["waypoints"]] + [(plan.get("arr") or {}).get("name", "")]
    return "|".join(names)


class PlanAvion:
    def __init__(self):
        self.data = None          # {"source", "partial", "dep", "arr", "waypoints", "cruise", "sig", "time"}
        self.ver = 0
        self.msg = "Esperando a MSFS"
        self.want = False
        self.last_save = 0.0
        self.busy = False
        self.no_save = False
        self.last_gps = None
        self.gps_pts = []
        self.t_connect = 0.0

    # -------------------------------------------------- llamado desde el hilo de SimConnect
    def on_connect(self):
        self.t_connect = time.time()
        self.gps_pts = []
        self.last_gps = None
        self.want = True

    def request(self):
        self.want = True
        self.msg = "Leyendo el plan del avión…"

    def tick(self, sm, raw):
        now = time.time()
        cnt = int(_num(raw.get("gps_count")))
        nid, pid = _txt(raw.get("gps_next_id")), _txt(raw.get("gps_prev_id"))
        gsig = (cnt, nid)
        if cnt > 0 and gsig != self.last_gps:
            known = self.data and nid and (nid in self.data["sig"].split("|"))
            if self.last_gps is None or cnt != self.last_gps[0] or not known:
                self.want = True            # plan nuevo o cambiado en el avión
            self.last_gps = gsig
            self._gps_add(pid, raw.get("gps_prev_lat"), raw.get("gps_prev_lon"), 0)
            self._gps_add(nid, raw.get("gps_next_lat"), raw.get("gps_next_lon"), raw.get("gps_next_alt"))
        if (self.want and not self.busy and not self.no_save and now - self.t_connect > 6
                and now - self.last_save > 15):
            self.want = False
            self.last_save = now
            self._save(sm)
        elif self.want and self.no_save:
            self.want = False
            self._publish_gps()

    def _gps_add(self, ident, lat, lon, alt):
        lat, lon = _num(lat), _num(lon)
        if not ident or (abs(lat) < 1e-6 and abs(lon) < 1e-6):
            return
        if any(p["name"] == ident for p in self.gps_pts[-3:]):
            return
        self.gps_pts.append({"name": ident, "lat": round(lat, 6), "lon": round(lon, 6), "alt": round(_num(alt)), "type": ""})
        if self.data is None or self.data.get("source") == "gps":
            self._publish_gps()

    def _publish_gps(self):
        if len(self.gps_pts) < 2:
            return
        pts = [dict(p) for p in self.gps_pts]
        for p in (pts[0], pts[-1]):
            if re.match(r"^[A-Z]{4}$", p["name"]):
                p["type"] = "Airport"
        plan = _shape(pts, 0)
        if plan:
            self._set(plan, "gps", partial=True)
            self.msg = "Plan del avión: se va completando con el GPS mientras vuelas"

    def _save(self, sm):
        DIR.mkdir(parents=True, exist_ok=True)
        for f in DIR.glob(STEM + ".*"):
            try:
                f.unlink()
            except OSError:
                pass
        path = DIR / (STEM + ".FLT")
        try:
            fn = getattr(sm.dll, "FlightSave", None)
            if fn is None:
                fn = sm.dll.SimConnect.SimConnect_FlightSave
                fn.argtypes = [ctypes.c_void_p, ctypes.c_char_p, ctypes.c_char_p, ctypes.c_char_p, ctypes.c_ulong]
            fn(sm.hSimConnect, str(path).encode("mbcs" if os.name == "nt" else "utf-8"), b"SimDirect", b"Plan del avion", 0)
        except Exception as exc:  # noqa: BLE001
            print(f"[!] Plan del avión: MSFS no deja guardar el vuelo ({exc}); uso el GPS", flush=True)
            self.no_save = True
            self._publish_gps()
            return
        self.busy = True
        threading.Thread(target=self._collect, args=(path,), daemon=True).start()

    def _candidates(self):
        yield DIR
        local = os.environ.get("LOCALAPPDATA")
        appdata = os.environ.get("APPDATA")
        if local:
            yield Path(local) / "Packages" / "Microsoft.Limitless_8wekyb3d8bbwe" / "LocalState"
        if appdata:
            yield Path(appdata) / "Microsoft Flight Simulator 2024"

    def _find(self, ext):
        for d in self._candidates():
            try:
                for f in list(d.glob(STEM + ext)) + list(d.glob("*/" + STEM + ext)):
                    if f.is_file() and f.stat().st_mtime > self.last_save - 2:
                        return f
            except OSError:
                continue
        return None

    def _collect(self, path):
        try:
            plan = None
            for _ in range(20):
                time.sleep(0.5)
                pln, flt = self._find(".[pP][lL][nN]"), self._find(".[fF][lL][tT]")
                if pln or flt:
                    time.sleep(0.6)       # que termine de escribirlo
                    try:
                        if pln:
                            plan = parse_pln(pln.read_text(encoding="utf-8", errors="ignore"))
                        if not plan and flt:
                            plan = parse_flt(flt.read_text(encoding="utf-8", errors="ignore"))
                    except Exception as exc:  # noqa: BLE001
                        print(f"[!] Plan del avión: no pude leer el archivo ({exc})", flush=True)
                    break
            if plan:
                self._set(plan, "msfs", partial=False)
                n = len(plan["waypoints"])
                d, a = (plan.get("dep") or {}).get("name", "?"), (plan.get("arr") or {}).get("name", "?")
                self.msg = f"Plan del avión: {d} → {a} · {n} puntos"
            elif self.gps_pts:
                self._publish_gps()
            else:
                self.msg = "El avión no tiene plan de vuelo todavía"
        finally:
            self.busy = False

    def _set(self, plan, source, partial):
        sig = signature(plan)
        if self.data and self.data["sig"] == sig and self.data["source"] == source:
            return
        if source == "gps" and self.data and self.data["source"] == "msfs":
            return                       # el plan completo manda sobre el del GPS
        self.data = {**plan, "source": source, "partial": partial, "sig": sig, "time": time.time()}
        self.ver += 1
        print(time.strftime("[%H:%M:%S]"), f"[OK] Plan del avión ({source}): {sig.replace('|', ' ')}", flush=True)

    def status(self):
        return {"ver": self.ver, "msg": self.msg, "plan": self.data}


PLAN = PlanAvion()
