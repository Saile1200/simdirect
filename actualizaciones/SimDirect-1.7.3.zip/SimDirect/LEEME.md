# SimDirect para MSFS 2024

Planificador de vuelos conectado a Microsoft Flight Simulator 2024, con mapa en vivo, perfil de altitudes, presets de ReShade y física de cámara de cabina.

## Arrancar (Windows)

- Abre **SimDirect** desde su icono del menú Inicio o del escritorio. Se abre en su propia ventana de app.
- La primera vez, o si no tienes el icono, haz doble clic en `iniciar_simdirect.bat`. Si falta Python, lo instala solo.
- En **Configurar** activa "Abrir SimDirect solo cuando inicies MSFS 2024": la app y la física de cámara arrancarán con el simulador.
- Desde el móvil o la tablet: abre `http://IP-DE-TU-PC:8765` en la misma wifi.

## Qué tiene

- **Plan**: pones salida y llegada, tocas el mapa para añadir checkpoints (se colocan solos en el sitio lógico de la ruta) y los arrastras para moverlos. Calcula distancias, rumbos, tiempo, combustible estimado y el punto de inicio de descenso (T/D). El botón "Calcular altitudes" genera un perfil de ascenso y descenso realista según el avión.
- **Exportar a MSFS (.pln)**: guarda el plan en la carpeta `planes_msfs`. En el simulador: Mapa del mundo → Cargar plan de vuelo.
- **Mapa en vivo**: el avión se mueve sobre la ruta, con estela, el siguiente punto, la distancia y la hora estimada, el desvío lateral y su posición en el perfil de altitud. Tiene mapas de satélite con nombres, oscuro, calles y relieve, y Google Maps si pones tu clave.
- **Sonidos** (suenan con el avión en MSFS, aunque la ventana esté cerrada): anuncios de cabina automáticos según la fase del vuelo (bienvenida, puertas, seguridad, despegue, cinturones, comandante en crucero con tiempo restante, turbulencias, descenso, aterrizaje y llegada), con campanas de 1, 2 y 3 tonos, voz en español o inglés, ambiente de cabina y la opción de usar tus propias grabaciones reales (carpeta `sonidos`).
- **Ajustes**: deslizadores para la física de la cámara y para los gráficos de ReShade, que generan tu preset `SimDirect_Personal.ini` directamente en el juego. Aquí también puedes poner tu clave de Google Maps.
- **Configurar**: un asistente que encuentra el simulador, copia los presets de ReShade solo y arranca la física de cámara, con deslizadores de intensidad. Lo demás te lo explica paso a paso.

## Carpetas

- `reshade/`: presets `SimDirect_Realista.ini` y `SimDirect_Cine.ini`, y su guía.
- `camara/`: física de cámara de cabina y su guía. También se puede arrancar desde la pestaña Configurar.
- `planes/`: tus planes guardados.
- `planes_msfs/`: planes exportados para el simulador.

## Si algo falla

- **"No se encuentra Python"**: reinstala Python marcando "Add Python to PATH".
- **Pone "Esperando a MSFS 2024" con el simulador abierto**: espera a estar dentro de un vuelo (no en el menú) y dale unos segundos. Se reconecta solo.
- **El mapa sale en negro**: hace falta internet para descargar el mapa.
