"""
SimDirect - lanzador (sin consola).

  SimDirect.pyw            -> abre la app en su propia ventana (y arranca el servidor si hace falta)
  SimDirect.pyw --msfs     -> lo lanza MSFS 2024 al arrancar (exe.xml): servidor + cámara + ventana opcional
  SimDirect.pyw --server   -> solo el servidor, en segundo plano (se apaga solo si nadie lo usa)
  SimDirect.pyw --restart  -> igual que --server, tras una actualización
"""
import ctypes
import json
import os
import socket
import subprocess
import sys
import threading
import time
import urllib.request
from pathlib import Path

BASE = Path(__file__).resolve().parent
os.chdir(BASE)
sys.path.insert(0, str(BASE))
PORT = 8765
URL = f"http://localhost:{PORT}"
LOG = BASE / "simdirect.log"
TITLE = "SimDirect · MSFS 2024"

if sys.stdout is None or "pythonw" in Path(sys.executable).name.lower():
    _f = open(LOG, "a", encoding="utf-8", buffering=1)
    sys.stdout = sys.stderr = _f


def log(*a):
    print(time.strftime("[%H:%M:%S]"), *a, flush=True)


def server_running():
    try:
        with socket.create_connection(("127.0.0.1", PORT), timeout=0.5):
            return True
    except OSError:
        return False


def load_config():
    try:
        return json.loads((BASE / "config.json").read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {}


def pythonw():
    exe = Path(sys.executable)
    w = exe.with_name("pythonw.exe")
    return w if w.exists() else exe


# ------------------------------------------------------------------ servidor
def ensure_server():
    """Arranca el servidor como proceso aparte (sobrevive aunque cierres la ventana)."""
    if server_running():
        return True
    flags = getattr(subprocess, "DETACHED_PROCESS", 0) | getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0)
    subprocess.Popen([str(pythonw()), str(BASE / "SimDirect.pyw"), "--server"], cwd=str(BASE), creationflags=flags)
    for _ in range(200):
        if server_running():
            return True
        time.sleep(0.1)
    return False


def run_server(wait_free=False):
    if wait_free:
        for _ in range(60):
            if not server_running():
                break
            time.sleep(0.25)
    if server_running():
        return
    import server
    t = threading.Thread(target=server.main, kwargs={"open_browser": False}, daemon=True)
    t.start()
    for _ in range(150):
        if server_running():
            break
        time.sleep(0.1)
    log("Servidor en marcha")
    try:
        import herramientas
        herramientas.ensure_shortcuts()
    except Exception as exc:  # noqa: BLE001
        log("Iconos:", exc)
    start = time.time()
    last_use = time.time()
    while t.is_alive():
        time.sleep(5)
        persistent = load_config().get("background", False)
        busy = any(j.get("running") for j in getattr(server, "JOBS", {}).values())
        if server.clients or server.SIM.live or server.PUSH.active or busy:
            last_use = time.time()
        if not persistent and time.time() - start > 90 and time.time() - last_use > 120:
            log("Sin uso: apagando el servidor")
            break
    server.shutdown()
    time.sleep(1)


# ------------------------------------------------------------------ ventana
def set_window_icon():
    """Pone el logo de SimDirect en la ventana y la barra de tareas."""
    try:
        user32 = ctypes.windll.user32
        ico = str(BASE / "web" / "logo.ico")
        big = user32.LoadImageW(None, ico, 1, 256, 256, 0x10)
        small = user32.LoadImageW(None, ico, 1, 32, 32, 0x10)
        for _ in range(150):
            hwnd = user32.FindWindowW(None, TITLE)
            if hwnd:
                user32.SendMessageW(hwnd, 0x80, 1, big)
                user32.SendMessageW(hwnd, 0x80, 0, small)
                return
            time.sleep(0.1)
    except Exception:  # noqa: BLE001
        pass


MINI = {"win": None, "shown": False}


def toggle_mini(show=None):
    w = MINI["win"]
    if w is None:
        return False
    show = (not MINI["shown"]) if show is None else bool(show)
    try:
        if show:
            w.show()
            try:
                w.on_top = True
            except Exception:  # noqa: BLE001
                pass
        else:
            w.hide()
        MINI["shown"] = show
    except Exception as exc:  # noqa: BLE001
        log("Mini mapa:", exc)
    return MINI["shown"]


def hotkey_loop():
    """Ctrl+Alt+M: mostrar u ocultar el mini mapa encima de MSFS (funciona aunque estés en el juego)."""
    try:
        from ctypes import wintypes
        user32 = ctypes.windll.user32
        if not user32.RegisterHotKey(None, 1, 0x0001 | 0x0002 | 0x4000, ord("M")):   # ALT | CONTROL | NOREPEAT
            log("No pude registrar Ctrl+Alt+M (otra app lo usa)")
            return
        msg = wintypes.MSG()
        while user32.GetMessageW(ctypes.byref(msg), None, 0, 0) != 0:
            if msg.message == 0x0312:      # WM_HOTKEY
                toggle_mini()
    except Exception as exc:  # noqa: BLE001
        log("Atajo del mini mapa:", exc)


def open_window_native():
    import webview  # pywebview: ventana de Windows con WebView2 (no es un navegador)

    class Api:
        def open_external(self, url):
            import webbrowser
            webbrowser.open(url)
            return True

        def toggle_mini(self):
            return toggle_mini()

        def hide_mini(self):
            return toggle_mini(False)

    # borrar la caché de la ventana para que siempre se vea la última versión
    import shutil
    for sub in ("EBWebView/Default/Cache", "EBWebView/Default/Code Cache", "EBWebView/Default/Service Worker"):
        shutil.rmtree(BASE / ".ventana" / sub, ignore_errors=True)
    api = Api()
    main = webview.create_window(TITLE, URL, width=1440, height=900, min_size=(960, 620),
                                 background_color="#0a0f15", text_select=True, js_api=api, maximized=True)
    # mini mapa: ventana pequeña siempre encima del juego (se abre con Ctrl+Alt+M o desde la app)
    try:
        cfg = load_config().get("mini", {})
        MINI["win"] = webview.create_window("SimDirect · mapa", URL + "/?mini=1", width=int(cfg.get("w", 460)), height=int(cfg.get("h", 460)),
                                            x=cfg.get("x"), y=cfg.get("y"), min_size=(260, 220), on_top=True, hidden=True,
                                            background_color="#0a0f15", js_api=api)
        def _mini_closing():
            if MINI.get("quit"):
                return True
            toggle_mini(False)           # la X del mini mapa solo lo esconde
            return False

        def _main_closed():
            MINI["quit"] = True
            try:
                if MINI["win"]:
                    MINI["win"].destroy()
            except Exception:  # noqa: BLE001
                pass
        MINI["win"].events.closing += _mini_closing
        main.events.closed += _main_closed
    except Exception as exc:  # noqa: BLE001
        log("Mini mapa no disponible:", exc)
    threading.Thread(target=set_window_icon, daemon=True).start()
    threading.Thread(target=hotkey_loop, daemon=True).start()
    webview.start(private_mode=False, storage_path=str(BASE / ".ventana"))


def find_browser():
    cands = []
    for env in ("ProgramFiles(x86)", "ProgramFiles", "LOCALAPPDATA"):
        b = os.environ.get(env)
        if b:
            cands += [Path(b) / "Microsoft" / "Edge" / "Application" / "msedge.exe",
                      Path(b) / "Google" / "Chrome" / "Application" / "chrome.exe"]
    return next((c for c in cands if c.exists()), None)


def open_window_fallback():
    exe = find_browser()
    if not exe:
        import webbrowser
        webbrowser.open(URL)
        return
    profile = BASE / ".ventana-edge"
    profile.mkdir(exist_ok=True)
    subprocess.Popen([str(exe), f"--app={URL}", f"--user-data-dir={profile}", "--window-size=1440,900",
                      "--no-first-run", "--no-default-browser-check", "--autoplay-policy=no-user-gesture-required"])


def open_window():
    try:
        ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID("SimDirect.MSFS2024")
    except Exception:  # noqa: BLE001
        pass
    try:
        open_window_native()
    except Exception as exc:  # noqa: BLE001
        log("Ventana nativa no disponible, uso Edge:", exc)
        open_window_fallback()


# ------------------------------------------------------------------ principal
def ensure_deps():
    """Instala en silencio los componentes nuevos si una actualización los necesita."""
    marker = BASE / ".venv" / ".instalado_v5"
    if marker.exists() or not (BASE / ".venv").exists():
        return
    py = Path(sys.executable).with_name("python.exe")
    log("Instalando componentes nuevos…")
    r = subprocess.run([str(py if py.exists() else sys.executable), "-m", "pip", "install", "-q", "-r",
                        str(BASE / "requirements.txt")], creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
    if r.returncode == 0:
        marker.write_text("ok", encoding="utf-8")


def main():
    args = sys.argv[1:]
    ensure_deps()
    if "--server" in args or "--restart" in args:
        run_server(wait_free="--restart" in args)
        return
    if not ensure_server():
        ctypes.windll.user32.MessageBoxW(None, "No se pudo arrancar el servidor de SimDirect.\nMira simdirect.log", "SimDirect", 0x10)
        return
    if "--msfs" in args:
        cfg = load_config()
        if cfg.get("camera_autostart", True):
            try:
                urllib.request.urlopen(urllib.request.Request(f"{URL}/api/camera", data=b'{"action":"start"}',
                                                              headers={"Content-Type": "application/json"}), timeout=5)
            except OSError:
                pass
        if not cfg.get("msfs_open_window", True):
            return
    open_window()


if __name__ == "__main__":
    try:
        main()
    except Exception as exc:  # noqa: BLE001
        import traceback
        traceback.print_exc()
        try:
            ctypes.windll.user32.MessageBoxW(None, f"SimDirect no pudo arrancar:\n{exc}\n\nMira simdirect.log", "SimDirect", 0x10)
        except Exception:  # noqa: BLE001
            pass
    os._exit(0)
