# Presets ReShade de SimDirect para MSFS 2024

Hay dos presets:

- **SimDirect_Realista.ini**: colores naturales con un poco más de nitidez y viveza. Corrige el aspecto "lavado" y ligeramente borroso del TAA/DLSS sin que parezca un filtro.
- **SimDirect_Cine.ini**: más contraste y color, tono cálido en las luces y frío en las sombras, y una viñeta suave. Queda muy bien para capturas y vídeos.

Solo usan efectos estándar (SweetFX + los de ReShade), así que son ligeros y no hace falta descargar packs raros.

## Instalación (una sola vez)

1. Descarga ReShade desde la web oficial: https://reshade.me (la versión normal vale).
2. Ejecuta el instalador y elige el ejecutable del simulador:
   - Steam: `...\steamapps\common\Microsoft Flight Simulator 2024\FlightSimulator2024.exe`
   - Microsoft Store / Game Pass: el instalador suele encontrarlo en la lista; si no, búscalo en la carpeta de instalación del juego.
3. Cuando pregunte la API de renderizado, elige **la misma que usas en el simulador**: DirectX 12 (lo normal en MSFS 2024) o DirectX 11.
4. En "Seleccionar preset" pulsa **Omitir**.
5. En la lista de paquetes de efectos marca **"Standard effects"** y **"SweetFX by CeeJay.dk"**. Termina la instalación.
6. Copia los dos archivos `.ini` de esta carpeta a la carpeta del juego (donde está el `.exe`).

## Uso

1. Abre MSFS 2024. Arriba aparecerá un mensaje de ReShade.
2. Pulsa **Inicio** (tecla Home) para abrir el menú de ReShade.
3. Arriba, en el desplegable de presets, elige `SimDirect_Realista.ini` o `SimDirect_Cine.ini`.
4. Para comparar con y sin efectos, activa y desactiva todos los efectos con **Bloq Despl** (tecla Scroll Lock).

## Ajustes rápidos

En la pestaña "Inicio" de ReShade puedes mover los deslizadores. Lo que más se nota:
- **ContrastAdaptiveSharpen → Sharpening**: nitidez. Súbela si usas DLSS en modo Rendimiento.
- **Vibrance**: viveza del color.
- **Curves → Contrast**: contraste.
- **Vignette** (solo en Cine): oscurecimiento de los bordes. Desactívalo si molesta en la cabina.

## Avisos

- ReShade también se aplica a los menús y a los paneles de la cabina; es normal.
- Con **Frame Generation de DLSS** a veces aparece parpadeo en los textos de los instrumentos. Si te pasa, prueba sin Frame Generation o baja la nitidez.
- Cuesta muy poco rendimiento (normalmente 1-3 FPS).

## Filtros de NVIDIA (alternativa, no los juntes con ReShade)

La app de NVIDIA tiene filtros propios (Alt+F3 dentro del juego), siempre que el simulador aparezca como compatible. Estos son los ajustes equivalentes al preset Realista:
- **Detalles**: Nitidez 25 %, Claridad 20 %, Tonificación HDR 10 %, Efecto Bloom 0 %.
- **Color**: Viveza +10 %, Temperatura 0, Tinte 0.

Usa ReShade **o** los filtros de NVIDIA, no los dos a la vez, porque se acumulan y pierdes rendimiento.
