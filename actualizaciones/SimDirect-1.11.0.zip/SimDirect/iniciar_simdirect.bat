@echo off
chcp 65001 >nul
title SimDirect - preparando
cd /d "%~dp0"
call instalar.bat || exit /b 1
if not exist "web\.iconos" (
  ".venv\Scripts\python.exe" -c "import herramientas as h; h.create_shortcuts()"
  echo ok> "web\.iconos"
)
start "" ".venv\Scripts\pythonw.exe" "%~dp0SimDirect.pyw"
exit /b 0
