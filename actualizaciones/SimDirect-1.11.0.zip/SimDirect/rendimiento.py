#!/usr/bin/env python3
"""
SimDirect - modo rendimiento: que la app le quite lo mínimo posible a MSFS 2024, sin bajar
la calidad de los gráficos ni cambiar los presets.

  * SimDirect funciona con prioridad «por debajo de lo normal»: Windows da antes la CPU al
    simulador (la física de cámara sigue en prioridad normal para que vaya fina).
  * Los datos que casi no cambian (pesos, combustible, nombre del avión, luces...) se piden a
    MSFS cada 2 s en vez de 5 veces por segundo: muchas menos peticiones a SimConnect.
  * El tráfico de MSFS para los recorridos se lee cada 15 s y el plan del avión solo se lee
    con el vuelo guardado cuando estás en tierra (guardar el vuelo en el aire da un tirón).
  * ReShade en «modo rendimiento»: compila los efectos ya fijados, mismo aspecto con más FPS.
"""
import json
import sys
from pathlib import Path

BASE = Path(__file__).resolve().parent
CONFIG = BASE / "config.json"

# lo que hace falta 5 veces por segundo (posición, velocidades, toma, pushback...)
FAST = {"lat", "lon", "alt", "agl", "ias", "gs", "vs", "hdg", "on_ground", "pushback", "parkbrake", "eng",
        "n1", "n1b", "rpm", "gear", "flaps", "spoilers", "camera", "sim_disabled", "tas",
        "g_force", "bank", "pitch", "td_vel", "trk", "door", "beacon", "seatbelt"}
SLOW_EVERY = 10          # vueltas del bucle de 0,2 s -> cada 2 s


def enabled():
    try:
        return json.loads(CONFIG.read_text(encoding="utf-8")).get("perf_mode", True)
    except (OSError, ValueError):
        return True


def set_priority(on=None):
    """Prioridad de este proceso: por debajo de lo normal con el modo rendimiento."""
    if sys.platform != "win32":
        return False
    on = enabled() if on is None else on
    try:
        import ctypes
        k = ctypes.windll.kernel32
        return bool(k.SetPriorityClass(k.GetCurrentProcess(), 0x4000 if on else 0x20))   # BELOW_NORMAL / NORMAL
    except Exception:  # noqa: BLE001
        return False


NORMAL_PRIORITY_FLAG = 0x20   # para los procesos que sí deben ir en prioridad normal (cámara)
