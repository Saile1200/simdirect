#!/usr/bin/env python3
"""
SimDirect - diario de vuelos y nota del aterrizaje.

Mira los datos del avión (5 veces por segundo) y detecta solo las fases del vuelo:
en el parking, rodando, despegue, subida, crucero, bajada, aproximación, aterrizaje y
rodaje a la llegada. En cada toma calcula la nota (de 0 a 10) con la velocidad vertical,
las G, el alabeo, la deriva, si tocas en la zona de toma y lo centrado que vas en la pista.
Cada vuelo se guarda en datos/diario con su ruta.
"""
import json
import math
import threading
import time
from collections import deque
from pathlib import Path

import aeropuertos as AP

BASE = Path(__file__).resolve().parent
DIR = BASE / "datos" / "diario"
_lock = threading.Lock()

VARS = {
    "g_force": ("G FORCE", "GForce"),
    "bank": ("PLANE BANK DEGREES", "degrees"),
    "pitch": ("PLANE PITCH DEGREES", "degrees"),
    "td_vel": ("PLANE TOUCHDOWN NORMAL VELOCITY", "feet per second"),
    "trk": ("GPS GROUND TRUE TRACK", "degrees"),
}

PHASES = {"parked": "En el parking", "taxi_out": "Rodando a la pista", "takeoff": "Despegando",
          "climb": "Subiendo", "cruise": "Crucero", "descent": "Bajando", "approach": "Aproximación",
          "landing": "Aterrizando", "taxi_in": "Rodando al parking", "unknown": "—"}


def _n(v, d=0.0):
    try:
        f = float(v)
        return f if f == f else d
    except (TypeError, ValueError):
        return d


def _nm(a_lat, a_lon, b_lat, b_lon):
    k = math.cos(math.radians((a_lat + b_lat) / 2))
    return math.hypot(b_lat - a_lat, (b_lon - a_lon) * k) * 60


def _brg(a_lat, a_lon, b_lat, b_lon):
    k = math.cos(math.radians((a_lat + b_lat) / 2))
    return (math.degrees(math.atan2((b_lon - a_lon) * k, b_lat - a_lat)) + 360) % 360


def _adiff(a, b):
    return (a - b + 540) % 360 - 180


# ------------------------------------------------------------------ nota del aterrizaje
def runway_check(lat, lon, hdg):
    """Pista en la que has tocado: distancia desde el umbral y desvío del eje (metros)."""
    ap = AP.nearest(lat, lon, 4.0)
    if not ap:
        return None
    info = AP.airport(ap["code"]) or {}
    best = None
    for r in info.get("runways", []):
        if not r.get("le") or not r.get("he"):
            continue
        for a, b, name in ((r["le"], r["he"], r["ends"][0]), (r["he"], r["le"], r["ends"][1])):
            rb = _brg(a[0], a[1], b[0], b[1])
            if abs(_adiff(hdg, rb)) > 35:
                continue
            k = math.cos(math.radians(a[0]))
            ex, ey = (b[1] - a[1]) * k * 111320, (b[0] - a[0]) * 110540
            L = math.hypot(ex, ey) or 1
            px, py = (lon - a[1]) * k * 111320, (lat - a[0]) * 110540
            along = (px * ex + py * ey) / L
            lateral = (px * ey - py * ex) / L
            if -300 < along < L + 300 and abs(lateral) < 120 and (best is None or abs(lateral) < abs(best["lateral_m"])):
                best = {"airport": ap["code"], "runway": name, "along_m": round(along), "lateral_m": round(lateral, 1),
                        "length_m": round(L), "width_m": round(r.get("width_m") or 45)}
    return best


def score_landing(m, ga=False):
    """Nota de 0 a 10 y comentario de cada parte."""
    fpm = abs(m["fpm"])
    notes = []
    steps = [(60, 10), (120, 9.6), (180, 9.1), (240, 8.3), (300, 7.4), (400, 6), (500, 4.6), (600, 3.3)] if not ga else \
            [(80, 10), (150, 9.5), (220, 8.8), (300, 7.8), (400, 6.4), (500, 5), (650, 3.5), (800, 2.5)]
    s = next((v for lim, v in steps if fpm <= lim), 1.5)
    notes.append(("fpm", f"{round(fpm)} fpm", "muy suave" if fpm <= 120 else "suave" if fpm <= 240 else "normal" if fpm <= 400 else "fuerte"))
    g = m.get("g", 1)
    if g > 1.5:
        s -= 2.5
    elif g > 1.3:
        s -= 1.2
    elif g > 1.18:
        s -= 0.4
    notes.append(("g", f"{g:.2f} G", "bien" if g <= 1.18 else "algo fuerte" if g <= 1.3 else "fuerte"))
    bank = abs(m.get("bank", 0))
    if bank > 6:
        s -= 1.5
    elif bank > 3:
        s -= 0.5
    notes.append(("bank", f"{bank:.1f}° de alabeo", "nivelado" if bank <= 3 else "algo inclinado" if bank <= 6 else "muy inclinado"))
    crab = abs(m.get("crab", 0))
    if crab > 10:
        s -= 1.5
    elif crab > 5:
        s -= 0.5
    notes.append(("crab", f"{crab:.0f}° de deriva", "alineado" if crab <= 5 else "algo cruzado" if crab <= 10 else "muy cruzado"))
    rw = m.get("rwy")
    if rw:
        a, lat = rw["along_m"], abs(rw["lateral_m"])
        zmin, zmax = (60, 450) if ga else (150, 750)
        if a < zmin * 0.5:
            s -= 1.5
            zone = "corta, antes de la zona de toma"
        elif a <= zmax:
            zone = "en la zona de toma"
        elif a <= zmax * 1.5:
            s -= 0.5
            zone = "algo larga"
        else:
            s -= 1.5
            zone = "larga"
        notes.append(("zone", f"{a} m del umbral", zone))
        half = (rw.get("width_m") or 45) / 2
        if lat > half * 0.6:
            s -= 1.5
        elif lat > half * 0.25:
            s -= 0.5
        notes.append(("center", f"{lat:.0f} m del eje", "centrado" if lat <= half * 0.25 else "algo descentrado" if lat <= half * 0.6 else "descentrado"))
    if m.get("bounces"):
        s -= 1.5 * m["bounces"]
        notes.append(("bounce", f"{m['bounces']} rebote{'s' if m['bounces'] > 1 else ''}", "rebote"))
    s = max(0.0, min(10.0, s))
    label = "Mantequilla" if s >= 9 else "Muy buena" if s >= 7.5 else "Buena" if s >= 6 else "Firme" if s >= 4 else "Dura"
    return round(s, 1), label, [{"k": k, "v": v, "t": t} for k, v, t in notes]


# ------------------------------------------------------------------ diario
class Diario:
    def __init__(self):
        self.phase = "unknown"
        self.flight = None
        self.prev_ground = None
        self.buf = deque(maxlen=40)            # últimos 8 s de datos (5 Hz)
        self.pending_td = None                 # toma en curso (se cierra 3 s después)
        self.last_landing = None
        self.landing_ver = 0
        self.stop_since = 0.0
        self.last_pt = 0.0
        self.saved_ver = 0

    # -------------------------------------------------- llamado desde el hilo de SimConnect
    def tick(self, raw, d):
        now = time.time()
        g = bool(d.get("on_ground"))
        ias, gs, vs, agl = d.get("ias", 0), d.get("gs", 0), d.get("vs", 0), d.get("agl", 0)
        if abs(d.get("lat", 0)) < 0.01 and abs(d.get("lon", 0)) < 0.01:
            return
        sample = {"t": now, "g": g, "vs": vs, "gf": _n(raw.get("g_force"), 1.0), "bank": _n(raw.get("bank")),
                  "pitch": _n(raw.get("pitch")), "hdg": d.get("hdg", 0), "trk": _n(raw.get("trk"), d.get("hdg", 0)),
                  "lat": d["lat"], "lon": d["lon"], "agl": agl, "gs": gs, "tdv": _n(raw.get("td_vel"))}
        self.buf.append(sample)
        with _lock:
            if self.prev_ground is None:
                self.prev_ground = g
                self.phase = "parked" if g and gs < 2 else ("taxi_out" if g else "cruise")
                if not g:
                    self._start(d, raw, airborne=True)
            # ------- despegue
            if self.prev_ground and not g and ias > 35:
                if self.pending_td and now - self.pending_td["t"] < 12:
                    self.pending_td["bounces"] += 1          # rebote, no despegue
                else:
                    if self.flight is None or self.flight.get("landed"):
                        if self.flight and self.flight.get("landed"):
                            self._finish(d, raw, reason="toma y despegue")
                        self._start(d, raw)
                    self.flight["takeoff"] = {"t": now, "lat": d["lat"], "lon": d["lon"], "hdg": d["hdg"]}
                    ap = AP.nearest(d["lat"], d["lon"], 4.0)
                    if ap and not self.flight.get("dep"):
                        self.flight["dep"] = ap["code"]
                    self.phase = "takeoff"
            # ------- toma
            if not self.prev_ground and g and self.flight is not None:
                if self.pending_td is None:
                    self.pending_td = self._touchdown(d, raw)
            self.prev_ground = g
            if self.pending_td and now - self.pending_td["t"] > 3 and not (self.pending_td["bounces"] and not g):
                if now - self.pending_td["t"] > 12 or g:
                    self._close_landing(d, raw)
            # ------- fases en el aire / en tierra
            f = self.flight
            if f is not None and not g:
                f["max_alt"] = max(f.get("max_alt", 0), d.get("alt", 0))
                cruise = f["max_alt"]
                if self.phase == "takeoff" and agl > 1500:
                    self.phase = "climb"
                elif self.phase in ("climb", "descent", "cruise", "approach", "takeoff", "landing", "taxi_out", "taxi_in", "parked"):
                    if agl < 2500 and vs < -200 and self.phase not in ("takeoff",):
                        self.phase = "approach"
                    elif vs > 400 and self.phase != "takeoff":
                        self.phase = "climb"
                    elif vs < -400:
                        self.phase = "descent"
                    elif abs(vs) < 300 and d.get("alt", 0) > cruise - 1500 and agl > 3000:
                        self.phase = "cruise"
                if now - self.last_pt > 15:
                    self.last_pt = now
                    pts = f["track"]
                    if pts:
                        f["dist_nm"] += _nm(pts[-1][0], pts[-1][1], d["lat"], d["lon"])
                    pts.append([round(d["lat"], 5), round(d["lon"], 5), int(d.get("alt", 0))])
            elif g:
                if f is None:
                    if gs > 3 and self.phase == "parked":
                        self.phase = "taxi_out"
                        self._start(d, raw)
                    elif gs < 1:
                        self.phase = "parked"
                elif f.get("landed"):
                    self.phase = "taxi_in" if gs > 3 else self.phase
                    stopped = gs < 1 and (d.get("parkbrake") or not d.get("eng"))
                    if stopped:
                        self.stop_since = self.stop_since or now
                        if now - self.stop_since > 8:
                            self._finish(d, raw)
                            self.phase = "parked"
                    else:
                        self.stop_since = 0.0
                    if now - f["landed"]["t"] > 1800:
                        self._finish(d, raw)
                elif not f.get("takeoff"):
                    self.phase = "taxi_out" if gs > 2 else "parked" if not d.get("eng") else self.phase
                    if gs < 1 and not d.get("eng") and now - f["start"] > 60:
                        self.flight = None          # volvió al parking sin volar
                        self.phase = "parked"

    def disconnected(self, d=None):
        with _lock:
            if self.flight and self.flight.get("takeoff"):
                self._finish(d or {}, {}, reason="MSFS se cerró")
            self.flight = None
            self.prev_ground = None
            self.pending_td = None
            self.phase = "unknown"

    # -------------------------------------------------- internos (con _lock)
    def _start(self, d, raw, airborne=False):
        title = raw.get("title")
        if isinstance(title, bytes):
            title = title.split(b"\0")[0].decode("latin-1", "ignore")
        ap = AP.nearest(d["lat"], d["lon"], 3.0) if not airborne else None
        self.flight = {"id": time.strftime("%Y%m%d-%H%M%S"), "start": time.time(), "aircraft": str(title or "")[:60],
                       "dep": ap["code"] if ap else None, "arr": None, "track": [[round(d["lat"], 5), round(d["lon"], 5), int(d.get("alt", 0))]],
                       "dist_nm": 0.0, "max_alt": d.get("alt", 0), "landings": [], "fuel_start": _n(raw.get("w_fuel")) * 0.4536,
                       "partial": airborne, "ga": isinstance(d.get("aircraft"), dict) and d["aircraft"].get("eng_type") == 0}

    def _touchdown(self, d, raw):
        now = time.time()
        air = [s for s in self.buf if not s["g"] and now - s["t"] <= 2.0]
        before = [s for s in air if now - s["t"] <= 0.8] or air[-1:] or list(self.buf)[-2:]
        vs_air = min((s["vs"] for s in before), default=d.get("vs", 0))
        tdv = abs(_n(raw.get("td_vel"))) * 60
        fpm = tdv if 5 < tdv < 3000 else abs(vs_air)
        last = before[-1] if before else self.buf[-1]
        crab = abs(_adiff(d["hdg"], _n(raw.get("trk"), d["hdg"]))) if d.get("gs", 0) > 30 else 0
        return {"t": now, "lat": d["lat"], "lon": d["lon"], "hdg": d["hdg"], "fpm": -round(fpm), "bank": round(last["bank"], 1),
                "pitch": round(last["pitch"], 1), "crab": round(crab, 1), "ias": round(d.get("ias", 0)), "g": 1.0, "bounces": 0}

    def _close_landing(self, d, raw):
        td = self.pending_td
        self.pending_td = None
        after = [s["gf"] for s in self.buf if 0 <= s["t"] - td["t"] <= 3]
        td["g"] = round(max(after + [1.0]), 2)
        td["rwy"] = runway_check(td["lat"], td["lon"], td["hdg"])
        ga = bool(self.flight and self.flight.get("ga"))
        td["score"], td["label"], td["notes"] = score_landing(td, ga)
        td["time"] = time.strftime("%H:%M")
        f = self.flight
        f["landings"].append(td)
        f["landed"] = td
        ap = (td["rwy"] or {}).get("airport") or (AP.nearest(td["lat"], td["lon"], 4.0) or {}).get("code")
        f["arr"] = ap or f.get("arr")
        self.last_landing = {**td, "airport": f["arr"]}
        self.landing_ver += 1
        self.phase = "landing"
        print(time.strftime("[%H:%M:%S]"), f"[OK] Aterrizaje: {td['fpm']} fpm · {td['g']} G · nota {td['score']} ({td['label']})", flush=True)

    def _finish(self, d, raw, reason=""):
        f = self.flight
        self.flight = None
        self.stop_since = 0.0
        if not f or not f.get("takeoff"):
            return
        now = time.time()
        if d.get("lat") is not None and f["track"]:
            f["dist_nm"] += _nm(f["track"][-1][0], f["track"][-1][1], d["lat"], d["lon"])
            f["track"].append([round(d["lat"], 5), round(d["lon"], 5), int(d.get("alt", 0))])
        fuel_now = _n(raw.get("w_fuel")) * 0.4536
        rec = {
            "id": f["id"], "date": time.strftime("%Y-%m-%d", time.localtime(f["start"])),
            "dep": f.get("dep"), "arr": f.get("arr"), "aircraft": f["aircraft"],
            "block_min": round((now - f["start"]) / 60), "air_min": round(((f["landed"]["t"] if f.get("landed") else now) - f["takeoff"]["t"]) / 60),
            "dist_nm": round(f["dist_nm"]), "max_alt": round(f["max_alt"]),
            "fuel_kg": (round(f["fuel_start"] - fuel_now) if f["fuel_start"] and fuel_now and f["fuel_start"] - fuel_now > 1 else None),
            "landings": f["landings"], "landing": f["landings"][-1] if f["landings"] else None,
            "track": f["track"], "partial": f.get("partial") or not f.get("landed"), "note": reason,
        }
        save(rec)
        self.saved_ver += 1
        print(time.strftime("[%H:%M:%S]"), f"[OK] Vuelo guardado en el diario: {rec['dep']} → {rec['arr']}", flush=True)

    def status(self):
        f = self.flight
        return {"phase": self.phase, "phase_txt": PHASES.get(self.phase, "—"), "landing_ver": self.landing_ver,
                "last_landing": self.last_landing, "saved_ver": self.saved_ver,
                "flight": {"dep": f.get("dep"), "dist_nm": round(f.get("dist_nm", 0)), "since": int(f["start"])} if f else None}


# ------------------------------------------------------------------ archivo
def save(rec):
    DIR.mkdir(parents=True, exist_ok=True)
    name = f"{rec['id']}_{rec.get('dep') or 'XXXX'}-{rec.get('arr') or 'XXXX'}.json"
    (DIR / name).write_text(json.dumps(rec, ensure_ascii=False), encoding="utf-8")


def _files():
    return sorted(DIR.glob("*.json"), reverse=True) if DIR.exists() else []


def list_flights():
    out = []
    for f in _files():
        try:
            r = json.loads(f.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            continue
        r.pop("track", None)
        lg = r.get("landing")
        r["landings_n"] = len(r.get("landings") or [])
        r.pop("landings", None)
        if lg:
            r["landing"] = {k: lg.get(k) for k in ("fpm", "g", "score", "label", "rwy")}
        out.append(r)
    scores = [r["landing"]["score"] for r in out if r.get("landing")]
    fpms = [abs(r["landing"]["fpm"]) for r in out if r.get("landing")]
    totals = {"flights": len(out), "hours": round(sum(r.get("block_min") or 0 for r in out) / 60, 1),
              "air_hours": round(sum(r.get("air_min") or 0 for r in out) / 60, 1),
              "nm": sum(r.get("dist_nm") or 0 for r in out),
              "avg_score": round(sum(scores) / len(scores), 1) if scores else None,
              "avg_fpm": round(sum(fpms) / len(fpms)) if fpms else None,
              "best": max(scores) if scores else None,
              "airports": len({x for r in out for x in (r.get("dep"), r.get("arr")) if x})}
    return {"flights": out, "totals": totals}


def get_flight(fid):
    for f in _files():
        if f.name.startswith(fid + "_"):
            try:
                return json.loads(f.read_text(encoding="utf-8"))
            except (OSError, ValueError):
                return None
    return None


def delete_flight(fid):
    for f in _files():
        if f.name.startswith(fid + "_"):
            f.unlink(missing_ok=True)
            return True
    return False


LOG = Diario()
