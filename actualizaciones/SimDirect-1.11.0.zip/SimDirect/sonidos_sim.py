"""
SimDirect - sonidos de cabina que suenan con el AVIÓN (no hace falta tener la ventana abierta).

Detecta la fase del vuelo con los datos de MSFS y reproduce en el PC:
  * anuncios con voz de Windows (SAPI), en español y/o inglés
  * campanas de 1, 2 y 3 tonos
  * efectos de tren, flaps y toque en pista
  * tus grabaciones reales de la carpeta «sonidos» (mp3/wav) si existen
Solo funciona con MSFS 2024 conectado.
"""
import json
import math
import queue
import struct
import sys
import tempfile
import threading
import time
import wave
from pathlib import Path

BASE = Path(__file__).resolve().parent
SOUNDS_DIR = BASE / "sonidos"
CACHE = Path(tempfile.gettempdir()) / "simdirect_snd"
CONFIG = BASE / "config.json"

DEFAULTS = {"enabled": True, "auto": True, "lang": "es", "natural": True, "airline": "SimDirect Airlines", "flightNo": "SKP 1024",
            "captain": "Martínez", "volume": 90, "rate": 0, "fx": True, "chimeOnBelt": True,
            "voiceEs": "", "voiceEn": ""}


def settings():
    try:
        cfg = json.loads(CONFIG.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        cfg = {}
    s = dict(DEFAULTS)
    s.update(cfg.get("sounds", {}))
    prof = cfg.get("profile", {})
    if prof.get("name") and s["captain"] == DEFAULTS["captain"]:
        s["captain"] = prof["name"].split(" ")[0]
    if prof.get("airline") and s["airline"] == DEFAULTS["airline"]:
        s["airline"] = prof["airline"]
    return s


def save_settings(new):
    try:
        cfg = json.loads(CONFIG.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        cfg = {}
    cur = cfg.get("sounds", {})
    for k, v in new.items():
        if k in DEFAULTS:
            cur[k] = v
    cfg["sounds"] = cur
    CONFIG.write_text(json.dumps(cfg, ensure_ascii=False, indent=1), encoding="utf-8")


# ------------------------------------------------------------------ síntesis de sonidos (WAV)
RATE = 44100


def _write(name, samples):
    CACHE.mkdir(exist_ok=True)
    f = CACHE / f"{name}.wav"
    if f.exists():
        return f
    with wave.open(str(f), "wb") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(RATE)
        w.writeframes(b"".join(struct.pack("<h", max(-32767, min(32767, int(x * 32767)))) for x in samples))
    return f


def _bell(freqs_starts, total):
    n = int(total * RATE)
    out = [0.0] * n
    for freq, start, dur in freqs_starts:
        s0 = int(start * RATE)
        for i in range(int(dur * RATE)):
            if s0 + i >= n:
                break
            t = i / RATE
            env = math.exp(-t * 2.2) * min(1, t * 200)
            out[s0 + i] += env * (0.30 * math.sin(2 * math.pi * freq * t) + 0.06 * math.sin(2 * math.pi * freq * 2.01 * t))
    return out


def chime_file(kind):
    if kind == "single":
        return _write("campana_1", _bell([(784, 0, 1.6)], 1.7))
    if kind == "double":
        return _write("campana_2", _bell([(659, 0, 1.6), (523, 0.55, 2.0)], 2.6))
    return _write("campana_3", _bell([(784, 0, 1.3), (659, 0.4, 1.3), (523, 0.8, 2.0)], 2.9))


def _noise_fx(name, dur, f_lo, gain, thump_at=None, motor=None):
    import random
    n = int(dur * RATE)
    out, last, ph = [], 0.0, 0.0
    a = math.exp(-2 * math.pi * f_lo / RATE)
    for i in range(n):
        t = i / RATE
        last = a * last + (1 - a) * random.uniform(-1, 1)          # ruido grave
        v = last * gain * min(1, t * 4) * min(1, (dur - t) * 3)
        if motor:
            ph += 2 * math.pi * (motor[0] + (motor[1] - motor[0]) * t / dur) / RATE
            v += 0.05 * (2 * ((ph / (2 * math.pi)) % 1) - 1) * min(1, t * 3) * min(1, (dur - t) * 3)
        if thump_at is not None and t >= thump_at:
            tt = t - thump_at
            v += 0.8 * math.exp(-tt * 14) * math.sin(2 * math.pi * 60 * tt)
        out.append(v)
    return _write(name, out)


def fx_file(kind, hard=0.0):
    if kind == "gearUp":
        return _noise_fx("fx_gearUp", 8.0, 300, 0.6, thump_at=7.4, motor=(110, 150))
    if kind == "gearDown":
        return _noise_fx("fx_gearDown", 6.0, 380, 0.5, thump_at=4.2, motor=(120, 100))
    if kind == "flaps":
        return _noise_fx("fx_flaps", 4.0, 160, 0.15, motor=(160, 175))
    lvl = 1 if hard > 0.5 else 0
    return _noise_fx(f"fx_touchdown{lvl}", 1.4, 120, 0.4 + lvl * 0.4, thump_at=0.02)


# ------------------------------------------------------------------ reproducción (MCI: wav y mp3) y voz (SAPI)
class Player(threading.Thread):
    def __init__(self):
        super().__init__(daemon=True)
        self.q = queue.Queue()
        self.voice = None
        self.n = 0

    def _mci(self, cmd):
        import ctypes
        buf = ctypes.create_unicode_buffer(256)
        ctypes.windll.winmm.mciSendStringW(cmd, buf, 255, 0)
        return buf.value

    def play_file(self, path, wait=True, volume=90):
        self.n += 1
        alias = f"sd{self.n}"
        p = str(path)
        kind = "mpegvideo" if not p.lower().endswith(".wav") else "waveaudio"
        self._mci(f'open "{p}" type {kind} alias {alias}')
        if kind == "mpegvideo":
            self._mci(f"setaudio {alias} volume to {int(volume * 10)}")
        self._mci(f"play {alias}{' wait' if wait else ''}")
        if wait:
            self._mci(f"close {alias}")
        else:
            threading.Timer(15, lambda: self._mci(f"close {alias}")).start()

    def say(self, text, lang, s):
        try:
            if self.voice is None:
                import comtypes.client
                self.voice = comtypes.client.CreateObject("SAPI.SpVoice")
            want = s.get("voiceEs" if lang == "es" else "voiceEn") or ""
            code = "40A" if lang == "es" else "809"     # es-ES / en-GB
            chosen = None
            toks = self.voice.GetVoices()
            for i in range(toks.Count):
                t = toks.Item(i)
                desc = t.GetDescription()
                if want and want.lower() in desc.lower():
                    chosen = t
                    break
                try:
                    if chosen is None and code.lower() in t.GetAttribute("Language").lower():
                        chosen = t
                except Exception:  # noqa: BLE001
                    pass
            if chosen is None and lang == "en":
                for i in range(toks.Count):
                    t = toks.Item(i)
                    if "english" in t.GetDescription().lower():
                        chosen = t
                        break
            if chosen is not None:
                self.voice.Voice = chosen
            self.voice.Volume = int(s.get("volume", 90))
            self.voice.Rate = int(s.get("rate", 0))
            self.voice.Speak(text, 0)
        except Exception as exc:  # noqa: BLE001
            print(f"[!] Voz: {exc}", flush=True)

    def run(self):
        try:
            import comtypes
            comtypes.CoInitialize()
        except Exception:  # noqa: BLE001
            pass
        while True:
            job = self.q.get()
            try:
                job()
            except Exception as exc:  # noqa: BLE001
                print(f"[!] Sonido: {exc}", flush=True)

    def stop(self):
        while not self.q.empty():
            self.q.get_nowait()
        try:
            if self.voice:
                self.voice.Speak("", 2)     # purgar
        except Exception:  # noqa: BLE001
            pass
        self._mci("close all")


NEURAL = {"es": {"crew": "es-ES-ElviraNeural", "captain": "es-ES-AlvaroNeural"},
          "en": {"crew": "en-GB-SoniaNeural", "captain": "en-GB-RyanNeural"}}
CAPTAIN_KEYS = {"cruise", "descent"}


def neural_file(text, lang, role, rate=0):
    """Voz natural de Microsoft (la misma que usa Edge para leer en voz alta). Se guarda en caché."""
    import asyncio
    import hashlib
    voice = NEURAL[lang][role]
    CACHE.mkdir(exist_ok=True)
    f = CACHE / ("tts_" + hashlib.md5(f"{voice}|{rate}|{text}".encode()).hexdigest() + ".mp3")
    if f.exists() and f.stat().st_size > 1000:
        return f
    import edge_tts
    pct = f"{int(rate) * 5:+d}%"
    # ritmo pausado y tono algo más grave: suena a megafonía de avión, no a robot
    comm = edge_tts.Communicate(text, voice, rate=pct if rate else ("-6%" if role == "crew" else "-4%"),
                                pitch="-2Hz" if role == "crew" else "-6Hz")
    asyncio.run(comm.save(str(f)))
    return f if f.exists() and f.stat().st_size > 1000 else None


PLAYER = Player()


def own_file(name):
    if not SOUNDS_DIR.exists():
        return None
    for ext in (".mp3", ".wav", ".m4a", ".wma"):
        f = SOUNDS_DIR / (name + ext)
        if f.exists():
            return f
        for g in SOUNDS_DIR.glob("*" + ext):
            if g.stem.lower() == name.lower():
                return g
    return None


# ------------------------------------------------------------------ anuncios
def _dest(ctx):
    return ctx.get("dest") or "nuestro destino"


ANN = {
    "welcome": ("double", lambda s, c: f"Señoras y señores, bienvenidos a bordo del vuelo {s['flightNo']} de {s['airline']} con destino {_dest(c)}. Por favor, coloquen su equipaje de mano en los compartimentos superiores y tomen asiento lo antes posible. Gracias.",
                lambda s, c: f"Ladies and gentlemen, welcome aboard {s['airline']} flight {s['flightNo']} to {_dest(c)}. Please stow your hand luggage in the overhead bins and take your seat as soon as possible. Thank you."),
    "doors": ("double", lambda s, c: "Tripulación de cabina, puertas en automático y comprobación cruzada.",
              lambda s, c: "Cabin crew, arm doors and cross check."),
    "safety": ("double", lambda s, c: "Señoras y señores, les rogamos su atención para la demostración de seguridad. Abróchense el cinturón. Las salidas de emergencia están a ambos lados del avión. En caso de despresurización caerán máscaras de oxígeno: colóquense la suya antes de ayudar a otras personas. El chaleco salvavidas está debajo de su asiento. Gracias por su atención.",
               lambda s, c: "Ladies and gentlemen, may we have your attention for the safety demonstration. Fasten your seatbelt. Emergency exits are located on both sides of the aircraft. In case of decompression, oxygen masks will drop; put on your own mask before helping others. Your life jacket is under your seat. Thank you."),
    "takeoff": ("double", lambda s, c: "Tripulación de cabina, asientos para el despegue.", lambda s, c: "Cabin crew, seats for take off."),
    "beltOff": ("single", lambda s, c: "Señoras y señores, el comandante ha apagado la señal de cinturones. Pueden moverse por la cabina, aunque les recomendamos mantenerlo abrochado mientras estén sentados.",
                lambda s, c: "Ladies and gentlemen, the captain has turned off the seatbelt sign. You may now move around the cabin, but please keep your seatbelt fastened while seated."),
    "cruise": ("triple", lambda s, c: f"Buenos días, les habla su comandante {s['captain']}. Volamos a {c.get('alt_es', 'nuestra altitud de crucero')}{(', y llegaremos a ' + _dest(c) + ' en unos ' + c['eta_es']) if c.get('eta_es') else ''}. Relájense y disfruten del vuelo. Gracias por volar con {s['airline']}.",
               lambda s, c: f"Good morning, this is your captain {s['captain']} speaking. We are cruising at {c.get('alt_en', 'our cruising altitude')}{(', and we expect to arrive in ' + _dest(c) + ' in about ' + c['eta_en']) if c.get('eta_en') else ''}. Sit back and enjoy the flight. Thank you for flying {s['airline']}."),
    "turbulence": ("single", lambda s, c: "Señoras y señores, atravesamos una zona de turbulencias. Por favor, vuelvan a sus asientos y abróchense el cinturón.",
                   lambda s, c: "Ladies and gentlemen, we are experiencing some turbulence. Please return to your seats and fasten your seatbelts."),
    "descent": ("triple", lambda s, c: f"Señoras y señores, les habla de nuevo el comandante. Hemos iniciado el descenso hacia {_dest(c)}. Por favor, vuelvan a sus asientos, abróchense el cinturón y pongan el respaldo en posición vertical.",
                lambda s, c: f"Ladies and gentlemen, this is the captain again. We have started our descent into {_dest(c)}. Please return to your seats, fasten your seatbelts and bring your seat backs upright."),
    "landing": ("double", lambda s, c: "Tripulación de cabina, asientos para el aterrizaje.", lambda s, c: "Cabin crew, seats for landing."),
    "arrived": ("double", lambda s, c: f"Señoras y señores, bienvenidos a {_dest(c)}. Permanezcan sentados con el cinturón abrochado hasta que el avión se detenga por completo. En nombre de {s['airline']} y de toda la tripulación, gracias por volar con nosotros.",
                lambda s, c: f"Ladies and gentlemen, welcome to {_dest(c)}. Please remain seated with your seatbelt fastened until the aircraft has come to a complete stop. On behalf of {s['airline']} and the entire crew, thank you for flying with us."),
    "disarm": ("double", lambda s, c: "Tripulación de cabina, desarmar puertas y comprobación cruzada.", lambda s, c: "Cabin crew, disarm doors and cross check."),
}
CHIME_FILE_NAMES = {"single": "campana_1", "double": "campana_2", "triple": "campana_3"}


def play_chime(kind, s):
    f = own_file(CHIME_FILE_NAMES[kind]) or chime_file(kind)
    PLAYER.play_file(f, wait=True, volume=s["volume"])


def announce(key, ctx=None):
    if sys.platform != "win32" or key not in ANN:
        return
    s, ctx = settings(), ctx or {}
    chime, es, en = ANN[key]

    def job():
        play_chime(chime, s)
        own = own_file(f"{key}_{'en' if s['lang'] == 'en' else 'es'}") or own_file(key)
        if own:
            PLAYER.play_file(own, wait=True, volume=s["volume"])
            return
        role = "captain" if key in CAPTAIN_KEYS else "crew"
        for lang, fn in (("es", es), ("en", en)):
            if s["lang"] not in (lang, "both"):
                continue
            text = fn(s, ctx)
            f = None
            if s.get("natural", True):
                try:
                    f = neural_file(text, lang, role, s.get("rate", 0))
                except Exception as exc:  # noqa: BLE001  (sin internet -> voz de Windows)
                    print(f"[i] Voz natural no disponible ({exc}); uso la de Windows", flush=True)
            if f:
                PLAYER.play_file(f, wait=True, volume=s["volume"])
            else:
                PLAYER.say(text, lang, s)
    ENGINE.now = key
    PLAYER.q.put(job)
    PLAYER.q.put(lambda: setattr(ENGINE, "now", None))


def effect(kind, hard=0.0):
    s = settings()
    if not s["fx"] or sys.platform != "win32":
        return
    f = own_file("fx_" + kind) or fx_file(kind, hard)
    threading.Thread(target=lambda: PLAYER.play_file(f, wait=False, volume=s["volume"]), daemon=True).start()


# ------------------------------------------------------------------ fases del vuelo
PHASES = {"gate": "En puerta", "taxi": "Rodaje", "takeoff": "Despegue", "climb": "Ascenso", "cruise": "Crucero",
          "descent": "Descenso", "approach": "Aproximación", "landed": "En tierra (llegada)"}


class Engine:
    def __init__(self):
        self.reset()
        self.now = None
        self.ctx_fn = lambda d: {}

    def reset(self):
        self.done = set()
        self.phase = "gate"
        self.level_since = 0
        self.max_alt = 0
        self.vs_hist = []
        self.last_turb = 0
        self.prev = None
        self.airborne = False
        self.vs_air = 0
        self.max_agl = 0
        self.mute_until = 0

    def once(self, key, d):
        if key in self.done:
            return
        self.done.add(key)
        announce(key, self.ctx_fn(d))

    def update(self, d, cruise_alt=30000):
        s = settings()
        now = time.time()
        if not s["enabled"] or not d:
            self.prev = None
            return
        # fuera de vuelo (menú, mapa del mundo, pausa): silencio total
        if d.get("paused"):
            self.prev = None
            self.mute_until = now + 15
            return
        p = self.prev
        # al aparecer el avión o al teletransportarte: empezar de cero y callar unos segundos
        jumped = p is not None and (abs(d["lat"] - p["lat"]) > 0.03 or abs(d["lon"] - p["lon"]) > 0.03)
        if p is None or jumped:
            if jumped or not self.done:
                self.reset()
            self.prev = d
            self.mute_until = now + 20
            return
        if s["chimeOnBelt"] and d.get("seatbelt") != p.get("seatbelt") and now > self.mute_until:
            threading.Thread(target=lambda: play_chime("single", s), daemon=True).start()
        self.prev = d
        if not s["auto"] or now < self.mute_until:
            return
        # fases y anuncios
        self.max_alt = max(self.max_alt, d["alt"])
        p = p or d
        self.vs_hist = (self.vs_hist + [d["vs"]])[-30:]
        if d["on_ground"]:
            if self.airborne and self.max_agl > 1000:
                self.phase = "landed"
                if d["gs"] < 60:
                    self.once("arrived", d)
                if p.get("beacon") and not d.get("beacon"):
                    self.once("disarm", d)
            elif d["gs"] < 3:
                if p.get("door", 0) > 0.5 and d.get("door", 0) < 0.1:      # cierras las puertas
                    self.once("welcome", d)
                    self.once("doors", d)
                if not p.get("beacon") and d.get("beacon"):
                    self.once("safety", d)
            else:
                if self.phase == "gate":
                    self.phase = "taxi"
                    self.once("doors", d)
                    self.once("safety", d)
                if d["gs"] > 28:
                    self.phase = "takeoff"
                    self.once("takeoff", d)
        else:
            self.airborne = True
            self.max_agl = max(self.max_agl, d.get("agl", 0))
            if self.phase in ("gate", "taxi", "takeoff"):
                self.phase = "climb"
            if self.phase == "climb" and d["alt"] > min(10000, cruise_alt * 0.8) and d["vs"] > 0:
                self.once("beltOff", d)
            level = abs(d["vs"]) < 300
            self.level_since = (self.level_since or now) if (level and d["alt"] > cruise_alt * 0.85) else 0
            if self.phase == "climb" and self.level_since and now - self.level_since > 45:
                self.phase = "cruise"
                self.once("cruise", d)
            if self.phase in ("cruise", "climb") and self.max_alt > cruise_alt * 0.8 and d["vs"] < -800 and d["alt"] < self.max_alt - 1500:
                self.phase = "descent"
                self.once("descent", d)
            if self.phase == "descent" and d["agl"] < 3000 and d["vs"] < 0:
                self.phase = "approach"
                self.once("landing", d)
            if len(self.vs_hist) >= 20:
                # turbulencia = sacudidas: la velocidad vertical sube y baja muchas veces seguidas
                diffs = [b - a for a, b in zip(self.vs_hist, self.vs_hist[1:])]
                flips = sum(1 for a, b in zip(diffs, diffs[1:]) if a * b < 0 and abs(a) > 150 and abs(b) > 150)
                jerk = sum(abs(x) for x in diffs) / len(diffs)
                if flips >= 6 and jerk > 250 and d["agl"] > 3000 and now - self.last_turb > 300:
                    self.last_turb = now
                    announce("turbulence", self.ctx_fn(d))

    def status(self):
        return {"phase": self.phase, "phase_name": PHASES.get(self.phase, ""), "done": sorted(self.done), "now": self.now}


ENGINE = Engine()


def start():
    if sys.platform == "win32" and not PLAYER.is_alive():
        PLAYER.start()
