'use strict';
/* Modo rendimiento (Ajustes) */
(() => {
  const box = document.getElementById('perfOn'); if (!box) return;
  async function load() {
    try { box.checked = !!(await (await fetch('/api/perf')).json()).on; } catch (e) { box.checked = true; }
  }
  box.onchange = async () => {
    try {
      const r = await post('/api/perf', { on: box.checked });
      toast(r.on ? '⚡ Modo rendimiento activado: MSFS va primero' : 'Modo rendimiento desactivado', 3200);
    } catch (e) { toast('Sin conexión con SimDirect'); box.checked = !box.checked; }
  };
  document.querySelectorAll('.tab[data-tab="adjust"]').forEach((t) => t.addEventListener('click', load));
  setTimeout(load, 2000);
})();
