'use strict';
/* SimCopilot 1.1: IA local gratis (Ollama) + ayuda sin conexión */

const Copilot = (() => {
  let msgs = store('simdirect.chat') || [];
  let status = null, busy = false;
  const save = () => store('simdirect.chat', msgs.slice(-40));

  const CHIPS = [
    'Hazme un plan de vuelo de Barcelona a Londres',
    'Dame ideas de vuelos VFR bonitos por España',
    'Ruta panorámica en Cessna por los Alpes',
    'Un vuelo largo en el 787 con buen paisaje',
    '¿Cómo uso el pushback?',
    '¿Cómo instalo ReShade?',
  ];

  /* ---------- ayuda sin IA (siempre disponible) */
  const FAQ = [
    [/pushback|remolc/i, 'En la pestaña **Pushback**: pulsa «Centrar el mapa en mi avión», toca en el mapa dónde quieres acabar, elige el rumbo del morro y pulsa «Iniciar pushback». Necesitas MSFS abierto, el avión parado en tierra y el freno de parking quitado.'],
    [/reshade|gráfic|grafic/i, 'Ve a **Configurar → Gráficos ReShade** y pulsa «Instalar ReShade automáticamente». Luego ajusta nitidez, color y más en **Ajustes → Gráficos**. En el juego, la tecla **Inicio** abre el menú de ReShade y **Bloq Despl** lo activa o desactiva.'],
    [/c[aá]mara|f[ií]sica|trackir|opentrack/i, 'En **Configurar → Física de cámara** pulsa «Instalar automáticamente» y después «Arrancar». En MSFS activa el modo TrackIR (Opciones → General → Cámara). La intensidad se regula en **Ajustes → Física de la cámara**.'],
    [/sonido|anuncio|campana|voz/i, 'En **Sonidos** tienes los anuncios automáticos según la fase del vuelo, campanas, ambiente de cabina con el N1 real y efectos de tren y flaps. Puedes poner grabaciones reales en la carpeta «sonidos».'],
    [/exportar|\.pln|cargar.*msfs|msfs.*plan/i, 'En **Plan → Exportar a MSFS (.pln)**. Después, en MSFS 2024: Mapa del mundo → Cargar plan de vuelo → carpeta «planes_msfs».'],
    [/altitud|checkpoint|waypoint|punto/i, 'En **Plan**, toca el mapa para añadir checkpoints (se colocan solos en el orden lógico de la ruta) y arrástralos para moverlos. «Calcular altitudes» crea un perfil de ascenso y descenso realista para tu avión.'],
    [/conect|simconnect|no detecta|esperando/i, 'Arriba a la derecha ves si SimDirect está conectado con MSFS 2024. Si pone «Esperando», entra en un vuelo (no en el menú) y espera unos segundos: se conecta solo.'],
    [/inicio|abrir sol|arranque|exe\.xml/i, 'En **Configurar → Abrir SimDirect con el simulador** marca «Abrir SimDirect solo cuando inicies MSFS 2024».'],
  ];
  const IDEAS = [
    { t: 'Barcelona → Palma (A320)', d: 'Corto y bonito sobre el Mediterráneo, unos 35 min.', p: { name: 'LEBL-LEPA', dep: 'LEBL', arr: 'LEPA', cruiseAlt: 24000, aircraft: 'a320', waypoints: [] } },
    { t: 'Costa Brava en Cessna (VFR)', d: 'Girona → Cadaqués → Cap de Creus → Girona, unos 50 min a baja altura.', p: { name: 'Costa Brava VFR', dep: 'LEGE', arr: 'LEGE', cruiseAlt: 4500, aircraft: 'c172', waypoints: [{ name: 'TOSSA', lat: 41.72, lon: 2.93 }, { name: 'CADAQ', lat: 42.29, lon: 3.28 }, { name: 'CREUS', lat: 42.32, lon: 3.32 }, { name: 'ROSES', lat: 42.26, lon: 3.18 }] } },
    { t: 'Madrid → Tenerife Norte (737)', d: 'Llegada espectacular junto al Teide, unas 2 h 30.', p: { name: 'LEMD-GCXO', dep: 'LEMD', arr: 'GCXO', cruiseAlt: 37000, aircraft: 'b738', waypoints: [] } },
    { t: 'Niza → Zúrich por los Alpes (TBM)', d: 'Montañas nevadas y lagos, 1 h aprox.', p: { name: 'LFMN-LSZH', dep: 'LFMN', arr: 'LSZH', cruiseAlt: 26000, aircraft: 'tbm9', waypoints: [{ name: 'MBLNC', lat: 45.83, lon: 6.86 }] } },
    { t: 'Lisboa → Oporto por la costa (Cessna)', d: 'Atlántico y playas, unas 2 h.', p: { name: 'LPPT-LPPR VFR', dep: 'LPPT', arr: 'LPPR', cruiseAlt: 5500, aircraft: 'c172', waypoints: [{ name: 'NAZAR', lat: 39.60, lon: -9.07 }, { name: 'AVEIR', lat: 40.64, lon: -8.75 }] } },
  ];
  function offlineAnswer(q) {
    for (const [re, a] of FAQ) if (re.test(q)) return a;
    if (/idea|destino|ruta|vuelo|planif|viaje/i.test(q)) {
      const pick = IDEAS.slice().sort(() => Math.random() - .5).slice(0, 3);
      return 'Aquí van unas ideas (sin IA instalada uso mi lista):\n\n' + pick.map((i) => `**${i.t}** — ${i.d}\n\`\`\`plan\n${JSON.stringify(i.p)}\n\`\`\``).join('\n\n') +
        '\n\nPara que te planifique cualquier ruta a tu medida, instala la IA gratis en Configurar.';
    }
    return 'Ahora mismo funciono sin IA, así que solo sé responder sobre la app y darte algunas ideas de rutas. Para preguntarme cualquier cosa, instala la **IA gratis** (botón de arriba): funciona en tu PC, sin cuentas ni pagos.';
  }

  /* ---------- contexto para la IA */
  function context() {
    const r = computeRoute(), est = estimates(r), ac = aircraft();
    const lines = [`Plan actual: ${plan.name}; salida ${plan.dep ? plan.dep.code : '—'}, llegada ${plan.arr ? plan.arr.code : '—'}, ${Math.round(r.total)} nm, crucero ${plan.cruiseAlt} ft, avión ${ac.name}, ${plan.waypoints.length} checkpoints, tiempo estimado ${fmtTime(est.time)}.`];
    if (live && liveMode === 'sim') lines.push(`En directo: ${live.on_ground ? 'en tierra' : 'en vuelo'} en ${live.lat.toFixed(3)}, ${live.lon.toFixed(3)}, ${Math.round(live.alt)} ft, ${Math.round(live.ias)} kt IAS, rumbo ${Math.round(live.hdg)}.`);
    else lines.push('MSFS 2024 no está conectado ahora mismo.');
    const prof = window.Profile && window.Profile.get();
    if (prof && prof.name) lines.push(`El piloto se llama ${prof.name}${prof.airline ? ', aerolínea ' + prof.airline : ''}${prof.home ? ', aeropuerto base ' + prof.home : ''}.`);
    return lines.join('\n');
  }

  /* ---------- planes propuestos */
  function toAirport(x) {
    if (!x) return null;
    if (typeof x === 'string') return apt(x.toUpperCase());
    const known = x.code && apt(String(x.code).toUpperCase());
    if (known) return known;
    if (isFinite(x.lat) && isFinite(x.lon)) return { code: String(x.code || 'APT').toUpperCase().slice(0, 4), name: x.name || x.code, lat: +x.lat, lon: +x.lon, elev: +x.elev || 0 };
    return null;
  }
  function loadPlan(p) {
    const np = newPlan();
    np.name = String(p.name || 'Plan del copiloto').slice(0, 60);
    np.dep = toAirport(p.dep); np.arr = toAirport(p.arr);
    np.cruiseAlt = Math.max(1000, Math.min(45000, +p.cruiseAlt || 30000));
    np.aircraftId = AIRCRAFT.some((a) => a.id === p.aircraft) ? p.aircraft : 'a320';
    np.waypoints = (p.waypoints || []).filter((w) => isFinite(w.lat) && isFinite(w.lon)).slice(0, 30)
      .map((w, i) => ({ id: uid(), name: String(w.name || 'WP' + (i + 1)).toUpperCase().slice(0, 8), lat: +w.lat, lon: +w.lon, alt: 0 }));
    if (!np.dep && !np.arr && !np.waypoints.length) { toast('El plan no tiene datos válidos'); return; }
    const pr = p.proc || {};
    np.proc = { depRwy: pr.depRwy || '', sid: pr.sid || '', sidTrans: pr.sidTrans || '', arrRwy: pr.arrRwy || '', star: pr.star || '', starTrans: pr.starTrans || '', appr: pr.appr || '' };
    plan = np; autoAltitudes(); fillForm(); render(); fitRoute();
    if (typeof Proc !== 'undefined' && Proc.renderBox) Proc.renderBox();
    document.querySelector('.tab[data-tab="plan"]').click();
    toast(`Plan «${plan.name}» cargado en el planificador`);
  }

  function planCard(p, i) {
    const dep = p.dep && (p.dep.code || p.dep), arr = p.arr && (p.arr.code || p.arr);
    const dn = p.dep && p.dep.name ? ` (${p.dep.name})` : '', an = p.arr && p.arr.name ? ` (${p.arr.name})` : '';
    const ac = p.aircraft === 'c172' ? 'Avioneta' : 'Avión de línea';
    const pr = p.proc || {}, inf = p.procInfo || {};
    const line = (ic, rwy, why, a, b) => rwy || a || b ? `<div class="pc-proc">${ic} ${rwy ? `Pista <b>${esc(rwy)}</b>` : ''}${a ? ` · ${a}` : ''}${b ? ` · ${b}` : ''}${why ? ` <small>(${esc(why)})</small>` : ''}</div>` : '';
    const procHtml = line('🛫', pr.depRwy, inf.depWhy, pr.sid ? `SID <b>${esc(pr.sid)}</b>` : '', '') +
      line('🛬', pr.arrRwy, inf.arrWhy, pr.star ? `STAR <b>${esc(pr.star)}</b>` : '', pr.appr ? `<b>${esc(pr.appr)}</b>` : '') +
      (p.aircraft !== 'c172' && pr.depRwy && !inf.msfs ? '<div class="pc-proc"><small>Abre MSFS 2024 y vuelve a pedirlo para ver las SID/STAR reales.</small></div>' : '');
    return `<div class="plan-card">🗺 <b>${esc(dep || '?')}${esc(dn)} → ${esc(arr || '?')}${esc(an)}</b><br><small>${ac} · crucero ${esc(String(p.cruiseAlt || ''))} ft · ${(p.waypoints || []).length} puntos de ruta</small>${procHtml}<div class="toolbar" style="margin:8px 0 0"><button class="primary" data-plan="${i}">✈ Poner en Plan</button><button data-dl="${i}">⬇ Descargar .pln</button><button data-fmc="${i}">FMC</button></div></div>`;
  }
  function asPlan(js) {
    try {
      const p = JSON.parse(js);
      if (p && (p.dep || p.arr || p.waypoints)) return p;
    } catch (e) { /* no es un plan */ }
    return null;
  }
  function fmt(text) {
    const plans = [];
    // cualquier bloque de código (```plan, ```json, ```...) -> tarjeta de plan o se oculta
    let t = String(text).replace(/```[a-zA-Z]*\s*([\s\S]*?)(```|$)/g, (_, js, end) => {
      if (!end) return '\u0000WAIT\u0000';
      const p = asPlan(js.trim());
      if (p) { plans.push(p); return `\u0000PLAN${plans.length - 1}\u0000`; }
      return '';
    });
    // JSON suelto sin bloque
    t = t.replace(/\{[\s\S]*"(?:dep|waypoints)"[\s\S]*\}/g, (js) => { const p = asPlan(js); if (p) { plans.push(p); return `\u0000PLAN${plans.length - 1}\u0000`; } return ''; });
    let html = esc(t)
      .replace(/^#{1,6}\s*/gm, '')
      .replace(/^\s*[-*]\s+/gm, '• ')
      .replace(/\*\*(.+?)\*\*/g, '<b>$1</b>')
      .replace(/(^|\s)\*([^*\n]+)\*/g, '$1<i>$2</i>')
      .replace(/`([^`]+)`/g, '<b>$1</b>')
      .replace(/^\s*\|.*\|\s*$/gm, '')
      .replace(/\n{3,}/g, '\n\n')
      .trim();
    html = html.replace(/\u0000WAIT\u0000/g, '<i>✈ preparando plan…</i>')
      .replace(/\u0000PLAN(\d+)\u0000/g, (_, i) => planCard(plans[+i], +i));
    return { html, plans };
  }

  /* ---------- interfaz */
  function renderMsgs() {
    const chat = $('#aiChat'); if (!chat) return;
    const all = msgs.length ? msgs : [{ role: 'assistant', content: '¡Hola! Soy **SimCopilot 1.1**. Pregúntame lo que quieras sobre la app, pídeme que te planifique un vuelo o que te dé ideas de destinos. ✈' }];
    chat.innerHTML = '';
    all.forEach((m) => {
      const div = document.createElement('div');
      div.className = 'msg ' + (m.role === 'user' ? 'user' : 'bot') + (m.typing ? ' typing' : '');
      if (m.role === 'user') div.textContent = m.content;
      else {
        const f = fmt(m.content); div.innerHTML = f.html;
        div.querySelectorAll('[data-plan]').forEach((b) => b.onclick = () => loadPlan(f.plans[+b.dataset.plan]));
        div.querySelectorAll('[data-dl]').forEach((b) => b.onclick = () => { loadPlan(f.plans[+b.dataset.dl]); setTimeout(() => $('#btnExport').click(), 300); });
        div.querySelectorAll('[data-fmc]').forEach((b) => b.onclick = () => { loadPlan(f.plans[+b.dataset.fmc]); setTimeout(() => document.querySelector('.tab[data-tab="fmc"]').click(), 300); });
      }
      chat.appendChild(div);
    });
    chat.scrollTop = chat.scrollHeight;
  }

  function renderPanel() {
    const box = $('#tab-ai'); if (!box) return;
    const st = status;
    let head;
    if (!serverOk) head = '<div class="msfs-banner off">Abre SimDirect desde su icono para usar la IA.</div>';
    else if (!st) head = '<div class="msfs-banner off">Comprobando la IA…</div>';
    else if (st.running && st.models.length) {
      head = `<div class="msfs-banner on">🧠 <b>SimCopilot 1.1</b> · listo en tu PC, gratis y sin internet</div>`;
    } else {
      const j = (typeof jobs !== 'undefined' && jobs.ai) || null;
      head = `<div class="msfs-banner off" style="flex-direction:column;align-items:stretch">
        <div><b>IA gratis en tu PC</b>: sin cuentas ni pagos y funciona sin internet. Descarga unos 2 GB una sola vez.</div>
        <select id="aiPick" class="inp">${Object.entries(st.choices).map(([k, v]) => `<option value="${k}">${esc(v)}</option>`).join('')}</select>
        <button class="primary" id="aiInstall" ${j && j.running ? 'disabled' : ''}>${st.installed ? 'Descargar el modelo de IA' : 'Instalar IA gratis'}</button>
        ${j && j.running ? `<p class="job">⏳ ${esc(j.msg)}</p>` : j && j.result && !j.result.ok ? `<p class="job err">✖ ${esc(j.result.error)}</p>` : ''}
        <small class="hint">Mientras tanto te respondo con la ayuda básica.</small></div>`;
    }
    box.innerHTML = `<h2 class="ptitle">SimCopilot 1.1</h2><p class="psub">Pregunta sobre la app, planifica rutas y descubre destinos.</p>${head}
      <div class="chat" id="aiChat"></div>
      ${msgs.length ? '' : `<div class="chips">${CHIPS.map((c) => `<button data-chip="${esc(c)}">${esc(c)}</button>`).join('')}</div>`}
      <div class="composer"><textarea id="aiInput" placeholder="Escribe tu pregunta…"></textarea><button class="primary" id="aiSend">Enviar</button></div>
      <div class="toolbar"><button id="aiClear">Nueva conversación</button></div>`;
    renderMsgs();
    const send = () => { const t = $('#aiInput').value.trim(); if (t) { $('#aiInput').value = ''; ask(t); } };
    $('#aiSend').onclick = send;
    $('#aiInput').onkeydown = (e) => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); send(); } };
    box.querySelectorAll('[data-chip]').forEach((b) => b.onclick = () => ask(b.dataset.chip));
    $('#aiClear').onclick = () => { msgs = []; save(); renderMsgs(); };
    const ins = $('#aiInstall'); if (ins) ins.onclick = async () => { await startJob('ai', { model: $('#aiPick').value }); poll(); };
  }
  function poll() { setTimeout(async () => { await loadStatus(); if (typeof jobs !== 'undefined' && jobs.ai && jobs.ai.running) poll(); }, 1500); }

  async function ask(q) {
    if (busy) return;
    const first = !msgs.length;
    msgs.push({ role: 'user', content: q });
    if (first) renderPanel();
    const useAI = status && status.running && status.models.length;
    if (!useAI) { msgs.push({ role: 'assistant', content: offlineAnswer(q) }); save(); renderMsgs(); return; }
    busy = true;
    const bot = { role: 'assistant', content: '', typing: true };
    msgs.push(bot); renderMsgs();
    try {
      const r = await fetch('/api/ai/chat', { method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ model: status.model, context: context(), messages: msgs.filter((m) => m !== bot).map((m) => ({ role: m.role, content: m.content })) }) });
      const rd = r.body.getReader(), dec = new TextDecoder();
      let last = 0;
      for (;;) {
        const { value, done } = await rd.read();
        if (done) break;
        bot.content += dec.decode(value, { stream: true });
        if (Date.now() - last > 120) { last = Date.now(); renderMsgs(); }
      }
    } catch (e) { bot.content += '\n[No pude contactar con la IA]'; }
    bot.typing = false; busy = false;
    if (!bot.content.trim()) bot.content = offlineAnswer(q);
    save(); renderMsgs();
  }

  async function loadStatus() {
    if (!serverOk) { status = null; renderPanel(); return; }
    try { status = await (await fetch('/api/ai/status')).json(); } catch (e) { status = null; }
    try { jobs = await (await fetch('/api/auto/status')).json(); } catch (e) { /* */ }
    renderPanel();
  }
  document.querySelector('.tab[data-tab="ai"]').addEventListener('click', loadStatus);
  renderPanel();
  return { ask, loadPlan };
})();
window.Copilot = Copilot;
