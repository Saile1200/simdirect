'use strict';
/* Checklists por fase: avión de línea o avioneta; se resalta sola la fase en la que estás */
const Checklists = (() => {
  const JET = [
    { id: 'prep', t: 'Preparación de cabina', ph: ['gate'], items: ['Baterías — ON', 'Energía exterior o APU — ON', 'ADIRS/IRS — NAV (alinear)', 'Luces de navegación — ON', 'Plan de vuelo cargado en el FMC', 'Combustible comprobado (pestaña Peso)', 'PERF de despegue introducida (pestaña FMC)', 'Briefing de salida hecho'] },
    { id: 'before', t: 'Antes del arranque', ph: ['gate'], items: ['Puertas — cerradas', 'Señal de cinturones — ON', 'Beacon — ON', 'Freno de parking — PUESTO', 'Autorización y pushback (pestaña Pushback)'] },
    { id: 'start', t: 'Arranque de motores', ph: ['gate'], items: ['APU bleed — ON', 'Motor 2 — ARRANQUE', 'Motor 1 — ARRANQUE', 'Generadores — ON', 'APU bleed — OFF', 'Anti-hielo según condiciones'] },
    { id: 'taxi', t: 'Rodaje', ph: ['taxi'], items: ['Flaps de despegue — PUESTOS', 'Trim de despegue — AJUSTADO', 'Mandos de vuelo — COMPROBADOS', 'Luces de rodaje — ON', 'Autobrake — RTO/MAX', 'Transpondedor — TA/RA'] },
    { id: 'lineup', t: 'Antes del despegue', ph: ['taxi', 'takeoff'], items: ['Velocidades V1 / VR / V2 — COMPROBADAS', 'Pista — CONFIRMADA', 'Luces de aterrizaje y estrobos — ON', 'Cabina — ASEGURADA', 'Empuje de despegue — FLEX/TOGA'] },
    { id: 'after', t: 'Después del despegue', ph: ['climb'], items: ['Tren — ARRIBA', 'Flaps — ARRIBA (según velocidad)', 'Piloto automático — ON', 'Luces de rodaje — OFF', 'Altímetro — STD al pasar la altitud de transición'] },
    { id: 'cruise', t: 'Crucero', ph: ['cruise'], items: ['Señal de cinturones — OFF (si no hay turbulencia)', 'Combustible — COMPROBADO', 'Briefing de llegada preparado (STAR y APPR)'] },
    { id: 'descent', t: 'Descenso', ph: ['descent'], items: ['VREF / VAPP introducidas (pestaña FMC → APPR)', 'Autobrake — PUESTO', 'Señal de cinturones — ON', 'Altímetro — QNH al pasar el nivel de transición', 'Luces de aterrizaje — ON por debajo de 10.000 ft'] },
    { id: 'landing', t: 'Aproximación y aterrizaje', ph: ['approach'], items: ['Tren — ABAJO (3 verdes)', 'Flaps de aterrizaje — PUESTOS', 'Spoilers — ARMADOS', 'Cabina — ASEGURADA', 'Estabilizado a 1.000 ft'] },
    { id: 'afterld', t: 'Después del aterrizaje', ph: ['landed'], items: ['Spoilers — RETRAÍDOS', 'Flaps — ARRIBA', 'Luces de aterrizaje y estrobos — OFF', 'Transpondedor — STBY', 'APU — ARRANCAR'] },
    { id: 'park', t: 'Parking', ph: ['landed'], items: ['Freno de parking — PUESTO', 'Motores — APAGADOS', 'Beacon — OFF', 'Señal de cinturones — OFF', 'Puertas — DESARMADAS'] },
  ];
  const GA = [
    { id: 'pre', t: 'Antes del arranque', ph: ['gate'], items: ['Inspección exterior — HECHA', 'Asientos y cinturones — AJUSTADOS', 'Freno de parking — PUESTO', 'Interruptores eléctricos y aviónica — OFF', 'Selector de combustible — BOTH'] },
    { id: 'start', t: 'Arranque', ph: ['gate'], items: ['Mezcla — RICA', 'Gases — ABIERTOS 1/4"', 'Master — ON', 'Beacon — ON', 'Hélice — ZONA DESPEJADA', 'Magnetos — START (soltar en BOTH)', 'Presión de aceite — VERDE', 'Aviónica — ON'] },
    { id: 'runup', t: 'Prueba de motor (run-up)', ph: ['taxi'], items: ['Frenos — PUESTOS', '1.800 RPM: magnetos L/R (caída máx. 125 RPM)', 'Calefacción del carburador — COMPROBADA', 'Instrumentos de motor — EN VERDE', 'Flaps — 0–10°', 'Trim — DESPEGUE', 'Puertas y ventanas — CERRADAS'] },
    { id: 'to', t: 'Despegue', ph: ['takeoff'], items: ['Luces de aterrizaje — ON', 'Transpondedor — ALT', 'Gases — A FONDO', 'Rotación a 55 kt', 'Ascenso a 74 kt'] },
    { id: 'cruise', t: 'Crucero', ph: ['climb', 'cruise'], items: ['Potencia — 2.200–2.400 RPM', 'Mezcla — EMPOBRECER', 'Trim — AJUSTADO', 'Altímetro — QNH de la zona'] },
    { id: 'appr', t: 'Descenso y aproximación', ph: ['descent', 'approach'], items: ['Mezcla — RICA', 'Calefacción del carburador — ON', 'Flaps — según velocidad (por debajo de 110 kt)', 'Aproximación final a 65 kt', 'Luces de aterrizaje — ON'] },
    { id: 'after', t: 'Después del aterrizaje', ph: ['landed'], items: ['Flaps — ARRIBA', 'Calefacción del carburador — OFF', 'Luces de aterrizaje — OFF', 'Transpondedor — STBY'] },
    { id: 'stop', t: 'Parada', ph: ['landed'], items: ['Freno de parking — PUESTO', 'Aviónica — OFF', 'Mezcla — CORTE', 'Magnetos — OFF', 'Master — OFF'] },
  ];
  let done = store('simdirect.checks') || {}, phase = null, open = null;
  const list = () => (isGA() ? GA : JET);
  const key = (sec, i) => `${isGA() ? 'ga' : 'jet'}.${sec}.${i}`;

  function render() {
    const box = $('#tab-check'); if (!box) return;
    const L2 = list();
    const cur = L2.find((s) => phase && s.ph.includes(phase) && s.items.some((_, i) => !done[key(s.id, i)])) || null;
    if (open === null && cur) open = cur.id;
    box.innerHTML = `<h2 class="ptitle">Checklists</h2>
      <p class="psub">${isGA() ? 'Avioneta (Cessna)' : 'Avión de línea'} · cambia el tipo en la pestaña Plan.${phase ? ` Fase actual: <b>${esc(PHN[phase] || phase)}</b>` : ''}</p>
      ${L2.map((s) => {
        const n = s.items.filter((_, i) => done[key(s.id, i)]).length, all = n === s.items.length;
        const isCur = cur && cur.id === s.id;
        return `<div class="cl ${all ? 'done' : ''} ${isCur ? 'cur' : ''} ${open === s.id ? 'open' : ''}">
          <button class="cl-head" data-open="${s.id}"><span>${all ? '✔' : isCur ? '▶' : '○'} ${esc(s.t)}</span><small>${n}/${s.items.length}</small></button>
          <div class="cl-body">${s.items.map((it, i) => `<label class="cl-item"><input type="checkbox" data-k="${key(s.id, i)}" ${done[key(s.id, i)] ? 'checked' : ''}><span>${esc(it)}</span></label>`).join('')}
            <div class="toolbar"><button data-all="${s.id}">Marcar todo</button></div></div></div>`;
      }).join('')}
      <div class="toolbar"><button id="clReset" class="danger">Reiniciar checklists (nuevo vuelo)</button></div>`;
    box.querySelectorAll('[data-open]').forEach((b) => b.onclick = () => { open = open === b.dataset.open ? '' : b.dataset.open; render(); });
    box.querySelectorAll('[data-k]').forEach((c) => c.onchange = () => {
      done[c.dataset.k] = c.checked; store('simdirect.checks', done);
      const s = L2.find((x) => c.dataset.k.includes('.' + x.id + '.'));
      if (s && s.items.every((_, i) => done[key(s.id, i)])) { const nx = L2[L2.indexOf(s) + 1]; open = nx ? nx.id : ''; }
      render();
    });
    box.querySelectorAll('[data-all]').forEach((b) => b.onclick = () => {
      const s = L2.find((x) => x.id === b.dataset.all); s.items.forEach((_, i) => { done[key(s.id, i)] = true; });
      store('simdirect.checks', done); const nx = L2[L2.indexOf(s) + 1]; open = nx ? nx.id : ''; render();
    });
    $('#clReset').onclick = () => { done = {}; store('simdirect.checks', done); open = null; render(); };
  }
  const PHN = { gate: 'En puerta', taxi: 'Rodaje', takeoff: 'Despegue', climb: 'Ascenso', cruise: 'Crucero', descent: 'Descenso', approach: 'Aproximación', landed: 'Llegada' };
  window.addEventListener('simsnd', (e) => {
    const p = e.detail && e.detail.phase;
    if (p && p !== phase) { phase = p; open = null; if (document.querySelector('#tab-check.active')) render(); }
  });
  document.querySelector('.tab[data-tab="check"]').addEventListener('click', render);
  return { render };
})();
