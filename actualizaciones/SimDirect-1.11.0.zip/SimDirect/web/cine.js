'use strict';
/* Cine: grabar el vuelo, reproducirlo con cámaras de película y grabar el vídeo */
const Cine = (() => {
  let st = null, timer = null, dragging = false;
  const panel = () => document.getElementById('tab-cine');
  const box = () => {
    const p = panel(); if (!p) return null;
    if (!p.querySelector('#cineMain')) p.innerHTML = '<div id="cineMain"></div><div id="cineVids"></div>';
    return p.querySelector('#cineMain');
  };
  let vids = null, vidSig = '', showAll = false;
  const fmtT = (s) => { s = Math.max(0, Math.round(s)); const m = Math.floor(s / 60); return `${m}:${String(s % 60).padStart(2, '0')}`; };
  const KIND = { despegue: '🛫', toma: '🛬', viraje: '↪', tren: '⚙', crucero: '☁' };

  async function act(body, okMsg) {
    try {
      const r = await post('/api/cine', body);
      if (!r.ok) toast(r.error || 'No se pudo hacer', 3600); else if (okMsg !== false) toast(r.msg || okMsg || 'Hecho');
      await load();
      return r.ok;
    } catch (e) { toast('Sin conexión con SimDirect'); return false; }
  }

  async function load() {
    if (!serverOk) { st = null; render(); return; }
    try { st = await (await fetch('/api/cine')).json(); } catch (e) { st = null; }
    render();
  }

  function render() {
    const b = box(); if (!b || dragging) return;
    if (!st) { b.innerHTML = '<h2 class="ptitle">Cine</h2><div class="msfs-banner off">Abre SimDirect desde su icono.</div>'; return; }
    const p = st.play;
    const head = st.sim ? '<div class="msfs-banner on">🎬 MSFS conectado: listo para rodar</div>'
      : '<div class="msfs-banner off">Abre MSFS 2024 y entra en un vuelo para grabar, reproducir y mover las cámaras.</div>';

    const recBtn = st.mode === 'rec'
      ? `<button class="danger cine-big" id="cRecStop">■ Parar grabación · ${fmtT(st.rec_seconds)}</button>`
      : `<div class="cine-row"><input class="inp" id="cRecTitle" placeholder="Nombre (opcional): p. ej. Madrid–Lisboa" maxlength="60"><button class="primary" id="cRecStart">● Grabar vuelo</button></div>`;

    const list = st.recordings.length ? st.recordings.map((r) => `
      <div class="cine-item ${p && p.name === r.name ? 'on' : ''}">
        <div><b>${esc(r.title)}</b><small>${esc(r.date)} · ${fmtT(r.duration)}</small></div>
        <button class="primary" data-play="${esc(r.name)}">▶</button>
        <button data-del="${esc(r.name)}" title="Borrar">🗑</button>
      </div>`).join('') : '<p class="hint">Aún no hay grabaciones. Pulsa «Grabar vuelo» antes de despegar y «Parar» al aterrizar.</p>';

    let player = '';
    if (p) {
      const marks = p.highlights.map((h) => `<button class="cine-mark" style="left:${(h.t / Math.max(1, p.duration)) * 100}%" data-seek="${h.t}" title="${esc(h.label)}">${KIND[h.kind] || '★'}</button>`).join('');
      player = `
      <div class="cine-player">
        <div class="cine-now"><b>${esc(p.title)}</b><span>${fmtT(p.t)} / ${fmtT(p.duration)}</span></div>
        <div class="cine-track">${marks}<input type="range" id="cSeek" min="0" max="${p.duration}" step="0.1" value="${p.t}"></div>
        <div class="toolbar">
          <button class="primary" id="cPause">${p.paused ? '▶ Seguir' : '❚❚ Pausa'}</button>
          ${[0.25, 0.5, 1, 2, 4].map((v) => `<button class="${p.speed === v ? 'on' : ''}" data-speed="${v}">${v}×</button>`).join('')}
        </div>
        ${p.highlights.length ? `<div class="cine-hl">${p.highlights.map((h) => `<button data-seek="${h.t}">${KIND[h.kind] || '★'} ${esc(h.label)} <small>${fmtT(h.t)}</small></button>`).join('')}</div>` : ''}
        <div class="toolbar"><button class="danger" id="cStop">⏏ Volver a mi vuelo</button><button id="cTakeOver" title="Te quedas en el punto actual de la grabación y sigues volando desde ahí">✈ Seguir volando desde aquí</button></div>
      </div>`;
    }

    const shots = st.shots.map((s) => `<button class="${st.auto.shot === s.key ? 'on' : ''}" data-shot="${s.key}">${esc(s.label)}</button>`).join('');
    const v = st.video;
    b.innerHTML = `<h2 class="ptitle">Cine</h2><p class="psub">Graba tu vuelo y conviértelo en una película: cámaras automáticas, momentos destacados y vídeo MP4.</p>${head}
      ${st.err ? `<p class="job err">✖ ${esc(st.err)}</p>` : ''}
      ${st.msg ? `<p class="cine-msg">${esc(st.msg)}</p>` : ''}
      <h3 class="cine-h">1 · Grabar</h3>${recBtn}
      <h3 class="cine-h">2 · Tus grabaciones</h3><div class="cine-list">${list}</div>${player}
      <h3 class="cine-h">3 · Cámaras</h3>
      <label class="cine-auto"><input type="checkbox" id="cAuto" ${st.auto.on ? 'checked' : ''}> <b>Director automático</b>
        <span>cada <select id="cInt" class="inp">${[4, 6, 8, 12, 20].map((n) => `<option ${Math.round(st.auto.interval) === n ? 'selected' : ''} value="${n}">${n} s</option>`).join('')}</select></span></label>
      <p class="hint" style="margin:0 0 8px">Cambia de plano solo según la fase del vuelo (rodaje, despegue, crucero, aterrizaje).</p>
      <div class="cine-shots">${shots}</div>
      <p class="hint">Funciona en directo mientras vuelas y durante la reproducción. Las «cámaras fijas» son las que trae cada avión (ala, cola, tren…).</p>
      <h3 class="cine-h">4 · Grabar el vídeo</h3>
      <button class="${v.recording ? 'danger' : 'primary'} cine-big" id="cVideo">${v.pending ? '⏳ Vuelve a MSFS…' : v.recording ? '■ Parar vídeo' : '⏺ Grabar vídeo MP4'}</button>
      <p class="hint">Usa la grabadora gratis de Windows (Xbox Game Bar). Pulsa el botón y vuelve a la ventana del juego: empieza sola. Al terminar, el vídeo se guarda solo en la carpeta <b>Cine\\Videos</b> de SimDirect. Consejo: oculta la interfaz del juego y activa el director automático.</p>`;
    bind();
  }

  function bind() {
    const b = box(); const q = (s) => b.querySelector(s);
    if (q('#cRecStart')) q('#cRecStart').onclick = () => act({ action: 'rec_start', title: q('#cRecTitle').value });
    if (q('#cRecStop')) q('#cRecStop').onclick = () => act({ action: 'rec_stop' });
    b.querySelectorAll('[data-play]').forEach((x) => x.onclick = () => act({ action: 'play', name: x.dataset.play }));
    b.querySelectorAll('[data-del]').forEach((x) => x.onclick = () => {
      if (x.dataset.confirm) act({ action: 'delete', name: x.dataset.del }, 'Grabación borrada');
      else { x.dataset.confirm = 1; x.textContent = '¿Borrar?'; x.classList.add('danger'); setTimeout(() => { if (x.isConnected) { delete x.dataset.confirm; x.textContent = '🗑'; x.classList.remove('danger'); } }, 3000); }
    });
    if (q('#cPause')) q('#cPause').onclick = () => act({ action: 'control', paused: !st.play.paused }, false);
    b.querySelectorAll('[data-speed]').forEach((x) => x.onclick = () => act({ action: 'control', speed: +x.dataset.speed }, false));
    b.querySelectorAll('[data-seek]').forEach((x) => x.onclick = () => act({ action: 'control', t: +x.dataset.seek, paused: false }, false));
    const seek = q('#cSeek');
    if (seek) {
      seek.oninput = () => { dragging = true; };
      seek.onchange = () => { dragging = false; act({ action: 'control', t: +seek.value }, false); };
    }
    if (q('#cStop')) q('#cStop').onclick = () => act({ action: 'stop', restore: true });
    if (q('#cTakeOver')) q('#cTakeOver').onclick = () => act({ action: 'stop', restore: false });
    b.querySelectorAll('[data-shot]').forEach((x) => x.onclick = () => act({ action: 'shot', shot: x.dataset.shot }, false));
    if (q('#cAuto')) q('#cAuto').onchange = (e) => act({ action: 'auto', on: e.target.checked, interval: +q('#cInt').value });
    if (q('#cInt')) q('#cInt').onchange = (e) => act({ action: 'auto', on: q('#cAuto').checked, interval: +e.target.value }, false);
    if (q('#cVideo')) q('#cVideo').onclick = () => act({ action: 'video' });
  }

  function poll() {
    clearTimeout(timer);
    const visible = panel() && panel().classList.contains('active');
    if (visible) load();
    timer = setTimeout(poll, visible && st && (st.mode !== 'idle' || st.video.pending) ? 700 : 2500);
  }
  /* ---------- 5 · Mis vídeos (MP4 grabados) */
  const fmtSize = (b) => b > 1e9 ? (b / 1e9).toFixed(1) + ' GB' : Math.max(1, Math.round(b / 1e6)) + ' MB';
  const vurl = (n) => '/api/cine/video/' + encodeURIComponent(n);
  async function loadVideos(force) {
    if (!serverOk) return;
    try { vids = await (await fetch('/api/cine/videos')).json(); } catch (e) { return; }
    const sig = JSON.stringify(vids.videos.map((v) => v.name + v.size)) + showAll;
    if (force || sig !== vidSig) { vidSig = sig; renderVideos(); }
  }
  function renderVideos() {
    const p = panel(); if (!p || !vids) return;
    box();
    const el = p.querySelector('#cineVids');
    const list = vids.videos;
    el.innerHTML = `<h3 class="cine-h">5 · Mis vídeos <small>(${list.length})</small></h3>
      <p class="hint" style="margin-top:0">Todo se guarda en la carpeta <b>Cine</b> de SimDirect: los vídeos en <b>Cine\\Videos</b> y las repeticiones en <b>Cine\\Repeticiones</b>. Al terminar de grabar, el vídeo se mueve ahí solo.</p>
      ${list.length ? `<div class="vid-grid">${list.map((v) => `
        <div class="vid-card">
          <button class="vid-thumb" data-watch="${esc(v.name)}" title="Ver">
            <video src="${vurl(v.name)}#t=2" preload="metadata" muted playsinline></video><span>▶</span></button>
          <div class="vid-meta"><b title="${esc(v.name)}">${esc(v.name.replace(/\.[^.]+$/, '').replace(/^Microsoft Flight Simulator( 2024)?\s*/i, 'MSFS '))}</b>
            <small>${esc(v.date)} · ${fmtSize(v.size)}</small></div>
          <div class="vid-act"><button data-vfolder="${esc(v.name)}" title="Abrir en su carpeta">📂</button><button data-vdel="${esc(v.name)}" title="Borrar">🗑</button></div>
        </div>`).join('')}</div>`
      : `<p class="hint">Aquí saldrán todos los vídeos de tus vuelos que grabes con «Grabar vídeo MP4».</p>`}
      <div class="toolbar"><button id="vOpen">📂 Abrir carpeta Cine</button><button id="vRefresh">↻ Actualizar</button></div>`;
    el.querySelectorAll('[data-watch]').forEach((x) => x.onclick = () => watch(x.dataset.watch));
    el.querySelectorAll('[data-vfolder]').forEach((x) => x.onclick = () => post('/api/cine', { action: 'video_folder', name: x.dataset.vfolder }).then((r) => toast(r.msg)));
    el.querySelectorAll('[data-vdel]').forEach((x) => x.onclick = async () => {
      if (!x.dataset.confirm) { x.dataset.confirm = 1; x.textContent = '¿Borrar?'; x.classList.add('danger'); setTimeout(() => { if (x.isConnected) { delete x.dataset.confirm; x.textContent = '🗑'; x.classList.remove('danger'); } }, 3000); return; }
      const r = await post('/api/cine', { action: 'video_delete', name: x.dataset.vdel }); toast(r.msg); loadVideos(true);
    });
    el.querySelector('#vOpen').onclick = () => post('/api/cine', { action: 'video_folder', root: true }).then((r) => toast(r.msg));
    el.querySelector('#vRefresh').onclick = () => loadVideos(true);
  }
  /* reproductor a pantalla grande */
  function watch(name) {
    const list = vids.videos.map((v) => v.name);
    let i = Math.max(0, list.indexOf(name));
    const ov = document.createElement('div');
    ov.className = 'vid-modal';
    const show = () => {
      ov.innerHTML = `<div class="vid-box"><div class="vid-top"><b>${esc(list[i])}</b><button id="vmClose" title="Cerrar (Esc)">✕</button></div>
        <video src="${vurl(list[i])}" controls autoplay playsinline></video>
        <div class="toolbar"><button id="vmPrev" ${i <= 0 ? 'disabled' : ''}>◀ Anterior</button><button id="vmFull">⛶ Pantalla completa</button><button id="vmNext" ${i >= list.length - 1 ? 'disabled' : ''}>Siguiente ▶</button></div></div>`;
      ov.querySelector('#vmClose').onclick = close;
      ov.querySelector('#vmPrev').onclick = () => { if (i > 0) { i--; show(); } };
      ov.querySelector('#vmNext').onclick = () => { if (i < list.length - 1) { i++; show(); } };
      ov.querySelector('#vmFull').onclick = () => { const v = ov.querySelector('video'); (v.requestFullscreen || v.webkitRequestFullscreen).call(v); };
    };
    const key = (e) => { if (e.key === 'Escape' && !document.fullscreenElement) close(); };
    function close() { ov.querySelector('video') && ov.querySelector('video').pause(); ov.remove(); removeEventListener('keydown', key); }
    ov.onclick = (e) => { if (e.target === ov) close(); };
    addEventListener('keydown', key);
    show(); document.body.appendChild(ov);
  }

  document.querySelector('.tab[data-tab="cine"]').addEventListener('click', () => { load(); poll(); loadVideos(true); });
  setInterval(() => { if (panel() && panel().classList.contains('active')) loadVideos(false); }, 8000);
  return { load };
})();
