'use strict';
/* Asistente de configuración: ReShade + cámara con física */

let setup = null;
const isLocalPC = ['localhost', '127.0.0.1'].includes(location.hostname);

const CAM_SLIDERS = [
  ['general', 'General', 'Todo junto'],
  ['g', 'Fuerzas G', 'Acelerar, frenar, rotar, baches'],
  ['virajes', 'Virajes', 'Inclinación y mirada al interior'],
  ['aterrizaje', 'Aterrizaje', 'Golpe según la velocidad vertical'],
  ['pista', 'Pista', 'Temblor y juntas al rodar'],
  ['buffet', 'Buffet', 'Pérdida, spoilers, sobrevelocidad'],
  ['motor', 'Motor', 'Vibración de motores'],
  ['suavidad', 'Suavidad', 'Más alto = más lento y suave'],
];
const CAM_DEFAULTS = { general: 1, g: 1, virajes: 1, aterrizaje: 1, pista: 1, buffet: 1, motor: 0.5, suavidad: 1 };

async function post(path, body) {
  const r = await fetch(path, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body || {}) });
  return r.json();
}

function step(n, title, state, body) {
  const badge = { ok: '✔ Listo', todo: 'Pendiente', auto: 'Automático', warn: 'Atención', busy: 'Trabajando…' }[state];
  return `<div class="step ${state}"><div class="step-head"><span class="step-n">${n}</span><b>${title}</b><span class="badge">${badge}</span></div><div class="step-body">${body}</div></div>`;
}
const manualCheck = (key) => `<label class="check"><input type="checkbox" data-done="${key}" ${setup.done[key] ? 'checked' : ''}> Ya lo he hecho</label>`;
let jobs = {}, jobTimer = null;
const jobLine = (k) => {
  const j = jobs[k]; if (!j) return '';
  if (j.running) return `<p class="job">⏳ ${esc(j.msg || 'Trabajando…')}</p>`;
  if (j.result && j.result.ok === false) return `<p class="job err">✖ ${esc(j.result.error || 'Error')}</p>`;
  return '';
};
async function pollJobs() {
  try { jobs = await (await fetch('/api/auto/status')).json(); } catch (e) { return; }
  const running = Object.values(jobs).some((j) => j.running);
  if (running) { renderSetup(); clearTimeout(jobTimer); jobTimer = setTimeout(pollJobs, 1000); }
  else { clearTimeout(jobTimer); loadSetup(); }
}
async function startJob(name, body) {
  const r = await post('/api/auto/' + name, body || {});
  if (r.ok === false) { toast(r.error, 5000); return; }
  setTimeout(pollJobs, 300);
}

function renderSetup() {
  const box = $('#setupSteps');
  if (!serverOk || !setup) { box.innerHTML = '<p class="hint">Abre SimDirect desde su icono para usar el asistente.</p>'; return; }
  const s = setup, busy = (k) => jobs[k] && jobs[k].running;
  let h = isLocalPC ? '' : '<p class="hint">⚠ Estás en el móvil: los cambios se hacen en el PC.</p>';

  h += step(1, 'Microsoft Flight Simulator 2024', s.msfs_dir ? 'ok' : 'warn', s.msfs_dir
    ? `<p class="hint">Encontrado en <code>${esc(s.msfs_dir)}</code>${s.sim_connected ? ' · 🟢 conectado ahora' : ''}</p>`
    : `<p class="hint">No lo encuentro solo. Pega la carpeta donde está <code>FlightSimulator2024.exe</code> (Steam → clic derecho en MSFS 2024 → Administrar → Ver archivos locales).</p>
       <div class="row2"><input id="msfsPath" class="inp" placeholder="D:\\SteamLibrary\\steamapps\\common\\Microsoft Flight Simulator 2024"><button id="msfsSave">Guardar</button></div>`);

  h += step(2, 'Abrir SimDirect con el simulador', s.autostart ? 'ok' : 'auto', `
    <label class="check big"><input type="checkbox" id="autoStart" ${s.autostart ? 'checked' : ''}> Abrir SimDirect solo cuando inicies MSFS 2024</label>
    <label class="check"><input type="checkbox" id="autoCam" ${s.camera_autostart ? 'checked' : ''}> Arrancar también la física de cámara</label>
    <label class="check"><input type="checkbox" id="autoWin" ${s.msfs_open_window ? 'checked' : ''}> Mostrar la ventana de SimDirect (si no, funciona en segundo plano)</label>
    <label class="check"><input type="checkbox" id="autoBg" ${s.background ? 'checked' : ''}> Arrancar SimDirect con Windows (en segundo plano, así siempre está listo)</label>
    <div class="toolbar"><button id="mkShortcuts">Crear iconos en Inicio y escritorio</button></div>${jobLine('shortcuts')}`);

  const rsState = busy('reshade') ? 'busy' : s.reshade ? 'ok' : s.store ? 'warn' : 'auto';
  h += step(3, 'Gráficos ReShade', rsState, s.store
    ? '<p class="hint">Tu simulador es la versión de Microsoft Store / Game Pass y Windows protege su carpeta: ReShade hay que ponerlo con su instalador oficial (reshade.me).</p>'
    : s.reshade
      ? `<p class="hint">Instalado${s.reshade_version ? ' (ReShade ' + esc(s.reshade_version) + ')' : ''}. En el juego: <b>Inicio</b> abre el menú, <b>Bloq Despl</b> activa/desactiva.</p>
         <div class="row2"><select id="rsPreset" class="inp"><option value="SimDirect_Personal.ini">Mi preset (pestaña Ajustes)</option><option value="SimDirect_Realista.ini">Realista</option><option value="SimDirect_Cine.ini">Cine</option></select><button id="rsPresetSet">Usar</button></div>
         <div class="toolbar"><button id="rsInstall">Reinstalar / actualizar</button><button id="rsUninstall">Quitar ReShade</button></div>${jobLine('reshade')}${jobLine('reshade_uninstall')}`
      : `<p class="hint">Descarga ReShade y los efectos, los instala en el juego con el preset de SimDirect y salta el tutorial. Si Windows pide permiso de administrador, pulsa <b>Sí</b>.</p>
         <button id="rsInstall" class="primary" ${s.msfs_dir && !busy('reshade') ? '' : 'disabled'}>Instalar ReShade automáticamente</button>${jobLine('reshade')}`);

  const trState = busy('tracking') ? 'busy' : s.tracking ? 'ok' : 'auto';
  h += step(4, 'Física de cámara', trState, `
    ${s.tracking
      ? '<p class="hint">Seguimiento de cabeza listo: SimDirect mueve la cámara directamente en MSFS (como un TrackIR), sin abrir OpenTrack.</p>'
      : '<p class="hint">Descarga los archivos de seguimiento de cabeza (OpenTrack portable, gratis) en la carpeta de SimDirect. No instala nada en Windows.</p>'}
    ${s.tracking ? '' : `<button id="trInstall" class="primary" ${busy('tracking') ? 'disabled' : ''}>Instalar automáticamente</button>`}${jobLine('tracking')}
    <p class="hint">${s.camera === 'start' ? '🟢 Física <b>activa</b>.' : s.camera === 'test' ? '🟡 <b>Modo prueba</b>: la cámara se mueve sola.' : 'Detenida.'}</p>
    <div class="toolbar">
      <button data-cam="test">Probar</button><button data-cam="start" class="primary">Arrancar</button><button data-cam="stop" ${s.camera ? '' : 'disabled'}>Detener</button>
    </div>
    <p class="hint">En MSFS, la primera vez: <b>Opciones → General → Cámara → modo TrackIR activado</b>, y baja el «efecto G» propio del simulador para que no se sumen.</p>${manualCheck('msfs_trackir')}`);

  h += step(5, 'Actualizaciones', 'auto', `
    <p class="hint">Versión instalada: <b>${esc(s.version)}</b>. SimDirect comprueba solo al abrirse si hay una nueva.</p>
    <div class="toolbar"><button id="updCheck">Buscar actualizaciones</button></div><div id="updBox"></div>${jobLine('update_apply')}
    <details><summary class="hint">Servidor de actualizaciones</summary>
      <div class="row2"><input id="updUrl" class="inp" value="${esc(s.update_url || '')}" placeholder="https://…/simdirect"><button id="updUrlSave">Guardar</button></div></details>`);

  h += '<div class="toolbar"><button id="setupRefresh">↻ Comprobar</button></div>';
  box.innerHTML = h;

  const on = (sel, fn) => { const el = $(sel); if (el) el.onclick = fn; };
  on('#setupRefresh', loadSetup);
  on('#msfsSave', async () => { const r = await post('/api/setup/msfs', { path: $('#msfsPath').value }); toast(r.ok ? 'Carpeta guardada' : r.error); loadSetup(); });
  const autoChange = async (body) => { const r = await post('/api/auto/autostart', body); if (r.ok === false) toast(r.error, 5000); else toast('Guardado'); loadSetup(); };
  $('#autoStart').onchange = (e) => autoChange({ enable: e.target.checked });
  $('#autoCam').onchange = (e) => autoChange({ camera_autostart: e.target.checked });
  $('#autoWin').onchange = (e) => autoChange({ msfs_open_window: e.target.checked });
  $('#autoBg').onchange = (e) => autoChange({ background: e.target.checked });
  on('#mkShortcuts', () => startJob('shortcuts'));
  on('#rsInstall', () => startJob('reshade'));
  on('#rsUninstall', () => { if (confirm('¿Quitar ReShade del simulador?')) startJob('reshade_uninstall'); });
  on('#rsPresetSet', async () => { const r = await post('/api/auto/reshade_preset', { preset: $('#rsPreset').value }); toast(r.ok ? 'Preset activado: se aplica en cuanto vuelvas a MSFS' : 'No se pudo cambiar'); });
  on('#trInstall', () => startJob('tracking'));
  on('#updCheck', async () => {
    $('#updBox').innerHTML = '<p class="job">⏳ Comprobando…</p>';
    const r = await post('/api/auto/update_check');
    $('#updBox').innerHTML = !r.ok ? `<p class="job err">✖ ${esc(r.error)}</p>`
      : !r.configured ? '<p class="hint">Todavía no hay servidor de actualizaciones configurado. Las nuevas versiones te las instalo directamente en el PC.</p>'
      : r.available ? `<p class="hint">Nueva versión <b>${esc(r.latest)}</b>. ${esc(r.notes || '')}</p><button id="updApply" class="primary">Actualizar ahora</button>`
      : '<p class="hint">✔ Tienes la última versión.</p>';
    on('#updApply', (e) => applyUpdate(r.zip, e && e.target));
  });
  on('#updUrlSave', async () => { await post('/api/auto/update_url', { url: $('#updUrl').value }); toast('Guardado'); });
  box.querySelectorAll('[data-cam]').forEach((b) => b.onclick = async () => {
    await post('/api/camera', { action: b.dataset.cam });
    toast({ test: 'Prueba de cámara en marcha', start: 'Física de cámara activa', stop: 'Cámara detenida' }[b.dataset.cam]);
    loadSetup();
  });
  box.querySelectorAll('[data-done]').forEach((c) => c.onchange = async () => { await post('/api/setup/done', { step: c.dataset.done, value: c.checked }); loadSetup(); });
}

let sliderTimer = null;
function renderSliders() {
  const vals = { ...CAM_DEFAULTS, ...((setup && setup.cam_settings) || {}) };
  $('#camSliders').innerHTML = CAM_SLIDERS.map(([k, label, tip]) => `
    <label class="slider"><span><b>${label}</b><small>${tip}</small></span>
      <input type="range" min="0" max="${k === 'suavidad' ? 2.5 : 2}" step="0.05" value="${vals[k]}" data-k="${k}">
      <output>${Number(vals[k]).toFixed(2)}</output></label>`).join('') +
    '<div class="toolbar"><button id="camReset">Valores por defecto</button></div><p class="hint">Los cambios se aplican en directo mientras la cámara está en marcha.</p>';
  const send = () => {
    const data = {};
    document.querySelectorAll('#camSliders input').forEach((i) => { data[i.dataset.k] = Number(i.value); });
    if (setup) setup.cam_settings = data;
    clearTimeout(sliderTimer); sliderTimer = setTimeout(() => serverOk && post('/api/camera/settings', data), 200);
  };
  document.querySelectorAll('#camSliders input').forEach((i) => i.oninput = () => {
    i.nextElementSibling.textContent = Number(i.value).toFixed(2); send();
  });
  $('#camReset').onclick = () => { if (setup) setup.cam_settings = { ...CAM_DEFAULTS }; renderSliders(); send(); };
}

async function loadSetup() {
  if (!serverOk) { renderSetup(); return; }
  try { setup = await (await fetch('/api/setup/status')).json(); } catch (e) { setup = null; }
  try { jobs = await (await fetch('/api/auto/status')).json(); } catch (e) { /* */ }
  renderSetup(); renderSliders();
}

document.querySelector('.tab[data-tab="setup"]').addEventListener('click', loadSetup);
renderSliders();

/* ---------------- Ajustes de ReShade */
const RS_SLIDERS = [
  ['sharpen', 'Nitidez', 'Quita el borroso de TAA/DLSS', 0, 1, 0.01],
  ['vibrance', 'Viveza', 'Colores más vivos sin quemar', -1, 1, 0.01],
  ['contrast', 'Contraste', 'Curva S', -1, 1, 0.01],
  ['saturation', 'Saturación', 'Color general', -1, 1, 0.01],
  ['exposure', 'Exposición', 'Más claro / más oscuro', -1, 1, 0.01],
  ['gamma', 'Gamma', 'Sombras y medios tonos', 0.5, 1.5, 0.01],
  ['warmth', 'Tono', 'Negativo frío · positivo cálido', -2, 2, 0.05],
  ['vignette', 'Viñeta', 'Oscurece los bordes', 0, 1, 0.01],
];
const RS_DEFAULTS = { sharpen: 0.45, vibrance: 0.12, contrast: 0.12, exposure: 0, gamma: 1, saturation: 0, warmth: 0.5, vignette: 0, deband: 1 };
const RS_PRESETS = {
  'Realista': { ...RS_DEFAULTS },
  'Cine': { sharpen: 0.6, vibrance: 0.22, contrast: 0.22, exposure: -0.03, gamma: 1.02, saturation: -0.05, warmth: 1, vignette: 0.35, deband: 1 },
  'Atardecer': { sharpen: 0.5, vibrance: 0.3, contrast: 0.18, exposure: 0, gamma: 1, saturation: 0.05, warmth: 1.8, vignette: 0.2, deband: 1 },
  'Nítido': { sharpen: 0.85, vibrance: 0.08, contrast: 0.08, exposure: 0, gamma: 1, saturation: 0, warmth: 0, vignette: 0, deband: 1 },
  'Neutro': { sharpen: 0.3, vibrance: 0, contrast: 0, exposure: 0, gamma: 1, saturation: 0, warmth: 0, vignette: 0, deband: 1 },
};
let rsVals = { ...RS_DEFAULTS }, rsTimer = null;
function sendReshade(msg) {
  clearTimeout(rsTimer);
  rsTimer = setTimeout(async () => {
    if (!serverOk) return;
    const r = await post('/api/reshade', rsVals);
    const el = $('#rsState');
    if (el) el.innerHTML = r.copied_to_msfs
      ? '✔ Guardado. <b>Se aplica solo en cuanto vuelvas a la ventana de MSFS</b> (tarda 1–2 segundos en recargar).'
      : '✔ Guardado en la carpeta reshade de SimDirect. Configura la carpeta del juego en «Configurar» para que se copie solo.';
    if (msg) toast(msg);
  }, 350);
}
function renderReshade() {
  $('#rsSliders').innerHTML = `<div class="toolbar">${Object.keys(RS_PRESETS).map((n) => `<button data-rsp="${n}">${n}</button>`).join('')}</div>` +
    RS_SLIDERS.map(([k, label, tip, mn, mx, st]) => `
    <label class="slider"><span><b>${label}</b><small>${tip}</small></span>
      <input type="range" min="${mn}" max="${mx}" step="${st}" value="${rsVals[k]}" data-rs="${k}">
      <output>${Number(rsVals[k]).toFixed(2)}</output></label>`).join('') +
    `<label class="check"><input type="checkbox" id="rsDeband" ${rsVals.deband >= 0.5 ? 'checked' : ''}> Quitar bandas en el cielo (Deband)</label>
     <p class="hint" id="rsState">Mueve los deslizadores: se genera tu preset <b>SimDirect_Personal.ini</b>.</p>`;
  document.querySelectorAll('[data-rs]').forEach((i) => i.oninput = () => {
    rsVals[i.dataset.rs] = Number(i.value); i.nextElementSibling.textContent = Number(i.value).toFixed(2); sendReshade();
  });
  $('#rsDeband').onchange = (e) => { rsVals.deband = e.target.checked ? 1 : 0; sendReshade(); };
  document.querySelectorAll('[data-rsp]').forEach((b) => b.onclick = () => {
    rsVals = { ...RS_PRESETS[b.dataset.rsp] }; renderReshade(); sendReshade('Base «' + b.dataset.rsp + '» aplicada');
  });
}
async function loadAdjust() {
  if (serverOk) {
    try { rsVals = { ...RS_DEFAULTS, ...(await (await fetch('/api/reshade')).json()) }; } catch (e) { /* */ }
    try { setup = await (await fetch('/api/setup/status')).json(); } catch (e) { /* */ }
  }
  renderSliders(); renderReshade();
  if ($('#gKey')) $('#gKey').value = store('simdirect.googleKey') || '';
}
if ($('#gKeySave')) $('#gKeySave').onclick = async () => {
  const k = $('#gKey').value.trim(); store('simdirect.googleKey', k);
  if (k && await addGoogleLayers(k)) toast('Google Maps añadido: elígelo en el botón de capas del mapa', 4000);
};
document.querySelector('.tab[data-tab="adjust"]').addEventListener('click', loadAdjust);
renderReshade();

/* ---------- aviso de actualización con botón */
async function applyUpdate(zip, btn) {
  if (btn) { btn.disabled = true; btn.textContent = 'Actualizando…'; }
  const r = await post('/api/auto/update_apply', { zip });
  if (!r.ok) { toast('No se pudo actualizar: ' + (r.error || ''), 6000); if (btn) { btn.disabled = false; btn.textContent = 'Actualizar ahora'; } return; }
  document.body.insertAdjacentHTML('beforeend', '<div class="splash"><div><img src="logo.svg" alt=""><h1>SIM<span>DIRECT</span></h1><p>Actualizando… se reinicia en unos segundos</p></div></div>');
  const t0 = Date.now();
  await new Promise((res) => setTimeout(res, 2500));
  for (;;) {
    try { const ok = await fetch('/api/setup/status', { cache: 'no-store' }); if (ok.ok) break; } catch (e) { /* aún reiniciando */ }
    if (Date.now() - t0 > 60000) break;
    await new Promise((res) => setTimeout(res, 1000));
  }
  location.reload();
}
function showUpdateBanner(r) {
  if (document.getElementById('updBanner')) return;
  const div = document.createElement('div');
  div.id = 'updBanner'; div.className = 'upd-banner';
  div.innerHTML = `<span>🚀 <b>Nueva versión ${esc(r.latest)}</b>${r.notes ? ' · ' + esc(r.notes) : ''}</span>
    <button class="primary" id="updNow">Actualizar ahora</button><button id="updLater" title="Más tarde">✕</button>`;
  document.body.appendChild(div);
  $('#updNow').onclick = (e) => applyUpdate(r.zip, e.target);
  $('#updLater').onclick = () => div.remove();
}
async function checkUpdates() {
  if (!serverOk) return;
  try { const r = await post('/api/auto/update_check'); if (r.ok && r.available) showUpdateBanner(r); } catch (e) { /* sin conexión */ }
}
setTimeout(checkUpdates, 4000);
setInterval(checkUpdates, 30 * 60 * 1000);
