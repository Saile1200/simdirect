'use strict';
/* FMC: FPLN (legs), PERF de despegue y APPR de aterrizaje. Cálculos orientativos para simulación. */
const FMC = (() => {
  let page = 'fpln';
  const P = Object.assign({ oat: 15, wind: 0, qnh: 1013, toFlaps: 'auto', ldgFlaps: 'auto', thrust: 'flex', wet: false }, store('simdirect.perf') || {});
  const save = () => store('simdirect.perf', P);
  const kg = (v) => Math.round(v).toLocaleString('es-ES');

  async function rwyInfo(code, rwy) {
    if (!code || !rwy || !window.Proc) return null;
    const info = await Proc.getAirport(code); if (!info) return null;
    const r = info.runways.find((x) => x.ends.includes(rwy)); if (!r) return null;
    const hdg = r.ends[0] === rwy ? r.heading : ((r.heading || 0) + 180) % 360;
    return { len: Math.round(r.length_m || 0), hdg: Math.round(hdg || 0), elev: info.elev || 0 };
  }

  /* ---------- FPLN */
  function fpln() {
    const r = computeRoute(), est = estimates(r), ac = aircraft(), c = Peso.compute(), pr = plan.proc || {};
    let t = 0, fuel = c.block - c.taxi;
    const rows = r.pts.map((p, i) => {
      if (i > 0) {
        const leg = r.legs[i - 1], midAlt = (r.pts[i - 1].alt + p.alt) / 2;
        const tas = ac.cruiseTas * (0.7 + 0.3 * Math.min(1, midAlt / Math.max(1, plan.cruiseAlt)));
        const h = leg.d / tas; t += h; fuel -= h * c.burn;
      }
      const leg = i > 0 ? r.legs[i - 1] : null;
      const spd = p.kind === 'wp' ? (p.alt >= 10000 ? (isGA() ? '' : (p.alt > 26000 ? '.78' : '290')) : (isGA() ? '' : '250')) : '';
      const tag = p.kind === 'dep' ? (pr.depRwy ? ' RW' + pr.depRwy : '') + (pr.sid ? ' · ' + pr.sid : '') : p.kind === 'arr' ? (pr.star ? pr.star + ' · ' : '') + (pr.appr || '') : '';
      return `<tr class="${p.kind}"><td>${esc(p.name)}<small>${esc(tag)}</small></td><td>${leg ? fmtCrs(leg.crs) : ''}</td><td>${leg ? Math.round(leg.d) : ''}</td>
        <td>${p.kind === 'wp' ? (p.alt >= 18000 ? 'FL' + Math.round(p.alt / 100) : Math.round(p.alt)) : (p.alt || 0)}</td><td>${spd}</td>
        <td>${i ? fmtTime(t) : '0h 00m'}</td><td>${(Math.max(0, fuel) / 1000).toFixed(1)}</td></tr>`;
    }).join('');
    return `<div class="fmc-head"><b>${esc(plan.dep ? plan.dep.code : '----')} → ${esc(plan.arr ? plan.arr.code : '----')}</b>
        <span>${fmtNm(r.total)} · ${fmtTime(est.time)} · ${plan.cruiseAlt >= 18000 ? 'FL' + Math.round(plan.cruiseAlt / 100) : plan.cruiseAlt + ' ft'} · T/D a ${Math.round(est.descD)} nm</span></div>
      <table class="fmc-table"><tr><th>Punto</th><th>Rumbo</th><th>Dist</th><th>Alt</th><th>Vel</th><th>ETE</th><th>Fuel t</th></tr>${rows}</table>
      <p class="hint">Fuel = combustible estimado a bordo en cada punto (toneladas). SID/STAR se eligen en la pestaña Plan.</p>`;
  }

  /* ---------- PERF de despegue */
  async function perf() {
    const c = Peso.compute(), ga = c.ga, pr = plan.proc || {}, sp = c.sp;
    const rw = await rwyInfo(plan.dep && plan.dep.code, pr.depRwy);
    const elev = rw ? rw.elev : (plan.dep ? plan.dep.elev || 0 : 0);
    const altFactor = 1 + elev / 1000 * 0.035 + Math.max(0, P.oat - 15) * 0.004;
    let out;
    if (ga) {
      const k = Math.sqrt(c.tow / 1157);
      const vr = Math.round(55 * k), vx = Math.round(62 * k), vy = Math.round(74 * k);
      const roll = Math.round(290 * (c.tow / 1157) ** 2 * altFactor * (P.wet ? 1.15 : 1) * (1 - Math.min(0.3, P.wind * 0.01)));
      out = { rows: [['VR (rotación)', vr + ' kt'], ['Vx (mejor ángulo)', vx + ' kt'], ['Vy (mejor régimen)', vy + ' kt'], ['Flaps', P.toFlaps === 'auto' ? (rw && rw.len < 700 ? '10°' : '0°') : P.toFlaps],
        ['Potencia', 'A fondo, mezcla rica'], ['Carrera estimada', roll + ' m'], ['Distancia hasta 50 ft', Math.round(roll * 1.8) + ' m']], len: roll * 1.8 };
    } else {
      const ref = c.tow / 64000;
      const flaps = P.toFlaps === 'auto' ? (rw && rw.len < 2300 ? 2 : 1) : +P.toFlaps;
      let vr = 145 * Math.sqrt(ref) - (flaps - 1) * 4;
      if (sp.title.toLowerCase().includes('787') || sp.mtow > 150000) vr = 158 * Math.sqrt(c.tow / 220000) - (flaps - 1) * 3;
      vr = Math.round(vr * Math.sqrt(altFactor) ** 0.3);
      const v1 = Math.round(vr - (P.wet ? 8 : 4)), v2 = Math.round(vr + 5);
      const margin = (sp.mtow - c.tow) / sp.mtow;
      const flexT = Math.max(P.oat + 1, Math.min(68, Math.round(P.oat + margin * 85 - elev / 1000 * 2 - (P.wet ? 6 : 0))));
      const tod = Math.round(1650 * ref ** 2 * altFactor * (P.thrust === 'flex' ? 1 + (flexT - P.oat) * 0.006 : 1) * (P.wet ? 1.15 : 1) * (1 - Math.min(0.2, P.wind * 0.008)));
      const trim = sp.cg ? (25 - sp.cg) * 0.12 : 0;
      out = { rows: [['V1', v1 + ' kt'], ['VR', vr + ' kt'], ['V2', v2 + ' kt'],
        ['Flaps', 'CONF ' + flaps + (flaps === 1 ? '+F' : '')], ['Empuje', P.thrust === 'flex' ? 'FLEX ' + flexT + ' °C' : 'TOGA'],
        ['Trim (THS)', sp.cg ? (trim >= 0 ? 'UP ' : 'DN ') + Math.abs(trim).toFixed(1) : '—'],
        ['Peso al despegue', kg(c.tow) + ' kg'], ['Distancia necesaria', tod + ' m'], ['Altitud de aceleración', Math.round(elev + 1500) + ' ft']], len: tod };
    }
    const lenOk = !rw || !rw.len || out.len < rw.len;
    return `<div class="fmc-head"><b>PERF DESPEGUE ${esc(plan.dep ? plan.dep.code : '')} ${pr.depRwy ? 'RW' + esc(pr.depRwy) : ''}</b>
        <span>${rw ? `Pista ${rw.len} m · rumbo ${rw.hdg}° · elev ${elev} ft` : 'Elige la pista en Plan → Pistas y procedimientos'}</span></div>
      ${inputs(true)}
      <table class="perf-table">${out.rows.map(([a, b]) => `<tr><td>${a}</td><td>${b}</td></tr>`).join('')}</table>
      ${rw && rw.len ? `<p class="job ${lenOk ? 'ok' : 'err'}">${lenOk ? '✔ La pista es suficiente' : '⚠ Pista corta para este peso: quita carga o combustible, o usa TOGA y más flaps'}</p>` : ''}`;
  }

  /* ---------- APPR de aterrizaje */
  async function appr() {
    const c = Peso.compute(), ga = c.ga, pr = plan.proc || {}, sp = c.sp;
    const rw = await rwyInfo(plan.arr && plan.arr.code, pr.arrRwy);
    const elev = rw ? rw.elev : (plan.arr ? plan.arr.elev || 0 : 0);
    const fuelLdg = c.block - c.taxi - c.trip;
    let rows, need;
    if (ga) {
      const k = Math.sqrt(c.lw / 1157), vref = Math.round(61 * k);
      need = Math.round(400 * (c.lw / 1157) * (1 + elev / 1000 * 0.04) * (P.wet ? 1.2 : 1));
      rows = [['Velocidad de aproximación', Math.round(65 * k) + ' kt'], ['Velocidad en el umbral', vref + ' kt'], ['Flaps', P.ldgFlaps === 'auto' ? '30°' : P.ldgFlaps],
        ['Peso al aterrizar', kg(c.lw) + ' kg'], ['Combustible al aterrizar', kg(fuelLdg) + ' kg'], ['Distancia de aterrizaje', need + ' m']];
    } else {
      const full = P.ldgFlaps === 'auto' || P.ldgFlaps === 'FULL';
      let vref = 132 * Math.sqrt(c.lw / 60000) + (full ? 0 : 5);
      if (sp.mtow > 150000) vref = 145 * Math.sqrt(c.lw / 200000) + (full ? 0 : 5);
      vref = Math.round(vref);
      const vapp = Math.round(vref + Math.min(15, Math.max(5, P.wind / 3)));
      need = Math.round(1350 * (c.lw / 60000) ** 1.3 * (1 + elev / 1000 * 0.03) * (P.wet ? 1.25 : 1) * (full ? 1 : 1.08));
      rows = [['VREF', vref + ' kt'], ['VAPP', vapp + ' kt'], ['Flaps', full ? 'CONF FULL' : 'CONF 3'], ['Autobrake', need > (rw ? rw.len * 0.6 : 2000) ? 'MED' : 'LOW'],
        ['Peso al aterrizar', kg(c.lw) + ' kg'], ['Combustible al aterrizar', kg(fuelLdg) + ' kg'], ['Distancia necesaria', need + ' m'],
        ['Mínimos (DA)', Math.round(elev + 200) + ' ft (ILS CAT I)'], ['Ida al aire', 'TOGA · subir a 3.000 ft o según carta']];
    }
    const ok = !rw || !rw.len || need < rw.len;
    return `<div class="fmc-head"><b>APPR ${esc(plan.arr ? plan.arr.code : '')} ${pr.arrRwy ? 'RW' + esc(pr.arrRwy) : ''} ${esc(pr.appr || '')}</b>
        <span>${rw ? `Pista ${rw.len} m · rumbo ${rw.hdg}° · elev ${elev} ft` : 'Elige la pista de llegada en Plan'}</span></div>
      ${inputs(false)}
      <table class="perf-table">${rows.map(([a, b]) => `<tr><td>${a}</td><td>${b}</td></tr>`).join('')}</table>
      ${rw && rw.len ? `<p class="job ${ok ? 'ok' : 'err'}">${ok ? '✔ La pista es suficiente' : '⚠ Pista justa: usa autobrake alto y reversas'}</p>` : ''}`;
  }

  function inputs(to) {
    const ga = isGA();
    const flapsOpts = to ? (ga ? ['auto', '0°', '10°'] : ['auto', '1', '2', '3']) : (ga ? ['auto', '20°', '30°'] : ['auto', 'FULL', '3']);
    return `<div class="perf-in">
      <label>OAT °C<input type="number" data-p="oat" value="${P.oat}"></label>
      <label>Viento de cara kt<input type="number" data-p="wind" value="${P.wind}"></label>
      <label>Flaps<select data-p="${to ? 'toFlaps' : 'ldgFlaps'}">${flapsOpts.map((f) => `<option ${P[to ? 'toFlaps' : 'ldgFlaps'] === f ? 'selected' : ''}>${f}</option>`).join('')}</select></label>
      ${to && !ga ? `<label>Empuje<select data-p="thrust"><option value="flex" ${P.thrust === 'flex' ? 'selected' : ''}>FLEX</option><option value="toga" ${P.thrust === 'toga' ? 'selected' : ''}>TOGA</option></select></label>` : ''}
      <label class="chk"><input type="checkbox" data-p="wet" ${P.wet ? 'checked' : ''}> Pista mojada</label></div>`;
  }

  /* ---------- exportar */
  function textReport(html) {
    const d = document.createElement('div'); d.innerHTML = html;
    return [...d.querySelectorAll('.fmc-head, tr, p')].map((n) => n.innerText.replace(/\t/g, '  ').trim()).join('\n');
  }
  async function render() {
    const box = $('#tab-fmc'); if (!box) return;
    const body = page === 'fpln' ? fpln() : page === 'perf' ? await perf() : await appr();
    box.innerHTML = `<h2 class="ptitle">FMC</h2><p class="psub">Plan, performance de despegue y de aproximación de «${esc(plan.name)}». Valores orientativos para el simulador.</p>
      <div class="seg fmc-tabs"><button data-pg="fpln" class="${page === 'fpln' ? 'on' : ''}">FPLN</button><button data-pg="perf" class="${page === 'perf' ? 'on' : ''}">PERF</button><button data-pg="appr" class="${page === 'appr' ? 'on' : ''}">APPR</button></div>
      <div class="fmc">${body}</div>
      <div class="toolbar"><button id="fmcPln" class="primary">⬇ Descargar .pln (MSFS)</button><button id="fmcTxt">⬇ Descargar resumen</button><button id="fmcPrint">🖨 Imprimir</button></div>`;
    box.querySelectorAll('[data-pg]').forEach((b) => b.onclick = () => { page = b.dataset.pg; render(); });
    box.querySelectorAll('[data-p]').forEach((i) => i.onchange = () => { P[i.dataset.p] = i.type === 'checkbox' ? i.checked : (i.type === 'number' ? +i.value : i.value); save(); render(); });
    $('#fmcPln').onclick = () => $('#btnExport').click();
    $('#fmcTxt').onclick = async () => {
      const txt = ['SIMDIRECT · ' + plan.name, '', textReport(fpln()), '', textReport(await perf()), '', textReport(await appr())].join('\n');
      const a = document.createElement('a'); a.href = URL.createObjectURL(new Blob([txt], { type: 'text/plain' }));
      a.download = (plan.name || 'plan').replace(/[^\w\- ]/g, '') + ' - FMC.txt'; a.click();
    };
    $('#fmcPrint').onclick = () => window.print();
  }
  document.querySelector('.tab[data-tab="fmc"]').addEventListener('click', render);
  return { render, fpln };
})();
