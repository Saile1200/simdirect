'use strict';
/* Skies: tiempo, atmósfera, luz y hora de MSFS 2024, con vista previa realista */
(() => {
  const P = [
    ["cover","tiempo","Nubes",0,100,1,v=>v+" %"],
    ["base","tiempo","Base de nubes",500,12000,100,v=>Math.round(v)+" ft"],
    ["cirrus","tiempo","Cirros (nubes altas)",0,100,1,v=>v+" %"],
    ["vis","tiempo","Visibilidad",0.3,50,0.1,v=>(v<10?v.toFixed(1):Math.round(v))+" km"],
    ["wind","tiempo","Viento",0,60,1,v=>v+" kt"],
    ["wdir","tiempo","Dirección del viento",0,350,10,v=>String(v).padStart(3,"0")+"°"],
    ["temp","tiempo","Temperatura",-30,45,1,v=>v+" °C"],
    ["qnh","tiempo","Presión (QNH)",960,1050,1,v=>v+" hPa"],
    ["rain","tiempo","Lluvia / nieve",0,100,1,v=>v+" %"],
    ["haze","atmos","Neblina",0,100,1,v=>v+" %"],
    ["dust","atmos","Polvo / calima",0,100,1,v=>v+" %"],
    ["blue","atmos","Azul del cielo",50,150,1,v=>v+" %"],
    ["hum","atmos","Humedad",0,100,1,v=>v+" %"],
    ["glow","atmos","Brillo del sol",0,200,1,v=>v+" %"],
    ["hour","luz","Hora del día",0,23.9,0.05,v=>{v=(v+24)%24;const h=Math.floor(v),m=Math.floor((v-h)*60);return String(h).padStart(2,"0")+":"+String(m).padStart(2,"0")}],
    ["bright","luz","Exposición",50,150,1,v=>v+" %"],
    ["sat","luz","Saturación",40,160,1,v=>v+" %"],
    ["warm","luz","Tono frío ↔ cálido",-50,50,1,v=>(v>0?"+":"")+v],
    ["contrast","luz","Contraste",60,140,1,v=>v+" %"],
    ["flare","luz","Destellos de lente",0,100,1,v=>v+" %"],
    ["grain","luz","Grano de película",0,100,1,v=>v+" %"],
    ["cine","luz","Formato cine (bandas)",0,1,1,v=>v>.5?"Sí":"No"],
  ];
  const DEF = {cover:28,base:5000,cirrus:25,vis:35,wind:8,wdir:240,temp:20,qnh:1015,rain:0,haze:15,dust:0,blue:100,hum:50,glow:100,hour:13,bright:100,sat:104,warm:0,contrast:104,flare:15,grain:6,cine:0};
  const PRESETS = [
    ["Hora dorada",{cover:35,base:6500,cirrus:45,vis:40,wind:6,wdir:250,temp:24,qnh:1016,haze:25,dust:10,hum:45,glow:150,hour:19.1,bright:104,sat:115,warm:16,contrast:106,grain:14,flare:45}],
    ["Atardecer de fuego",{cover:48,base:8000,cirrus:75,vis:45,wind:8,wdir:270,temp:26,qnh:1012,haze:20,dust:18,blue:95,hum:50,glow:170,hour:19.55,bright:106,sat:124,warm:18,contrast:110,grain:18,flare:55,cine:1}],
    ["Hora azul",{cover:12,base:7000,cirrus:40,vis:50,wind:3,wdir:200,temp:16,qnh:1020,haze:10,blue:110,hum:40,hour:19.95,bright:110,sat:112,warm:-6,contrast:104,grain:14,flare:5}],
    ["Noche estrellada",{cover:0,base:6000,cirrus:0,vis:50,wind:2,wdir:300,temp:8,qnh:1026,haze:4,hum:30,hour:23.5,bright:112,sat:108,warm:-10,contrast:108,grain:20,flare:0}],
    ["Luna entre nubes",{cover:48,base:3500,cirrus:15,vis:30,wind:12,wdir:230,temp:11,qnh:1009,haze:12,hum:60,hour:1.5,bright:118,sat:92,warm:-16,contrast:110,grain:24,flare:0,cine:1}],
    ["Amanecer con bruma",{cover:22,base:5000,cirrus:35,vis:6,wind:2,wdir:90,temp:9,qnh:1022,haze:60,hum:90,glow:165,hour:7.8,bright:106,sat:108,warm:12,contrast:98,grain:14,flare:40}],
    ["Mediodía despejado",{cover:16,base:5500,cirrus:25,vis:50,wind:8,wdir:260,temp:25,qnh:1021,haze:8,blue:112,hum:35,hour:13,sat:106,contrast:104,grain:4,flare:12}],
    ["Tormenta al anochecer",{cover:96,base:1800,cirrus:0,vis:6,wind:32,wdir:140,temp:22,qnh:994,rain:80,haze:30,blue:90,hum:95,glow:80,hour:19.25,bright:94,sat:90,warm:-6,contrast:118,grain:24,flare:0,cine:1}],
    ["Calima del Sáhara",{cover:8,base:9000,cirrus:10,vis:4,wind:18,wdir:160,temp:34,qnh:1008,haze:30,dust:85,blue:70,hum:20,glow:90,hour:17.6,bright:104,sat:96,warm:22,contrast:95,grain:12,flare:30}],
    ["Invierno nórdico",{cover:58,base:2500,cirrus:20,vis:14,wind:14,wdir:20,temp:-14,qnh:1031,rain:35,haze:28,blue:105,hum:75,glow:85,hour:15.4,bright:110,sat:82,warm:-26,contrast:98,grain:12,flare:0}],
    ["Contraluz de cine",{cover:30,base:4000,cirrus:40,vis:22,wind:5,wdir:250,temp:21,qnh:1014,haze:45,dust:14,blue:92,hum:55,glow:190,hour:18.85,bright:102,sat:112,warm:18,contrast:116,grain:28,flare:85,cine:1}],
    ["Niebla de madrugada",{cover:35,base:700,cirrus:10,vis:0.7,wind:1,wdir:60,temp:6,qnh:1027,haze:80,hum:100,glow:120,hour:8.3,bright:106,sat:90,warm:-4,contrast:90,grain:16,flare:10}],
  ];

  /* ---------- ruido */
  const perm = new Uint8Array(512);
  { const p = Array.from({length:256},(_,i)=>i); let s = 1337; for (let i = 255; i > 0; i--) { s = (s*16807)%2147483647; const j = s % (i+1); [p[i],p[j]] = [p[j],p[i]]; } for (let i = 0; i < 512; i++) perm[i] = p[i & 255]; }
  function vn(x, y){
    const xi = Math.floor(x), yi = Math.floor(y), xf = x - xi, yf = y - yi;
    const u = xf*xf*(3-2*xf), v = yf*yf*(3-2*yf), X = xi & 255, Y = yi & 255;
    const a = perm[perm[X]+Y], b = perm[perm[X+1]+Y], c = perm[perm[X]+Y+1], d = perm[perm[X+1]+Y+1];
    return (a + (b-a)*u + (c-a)*v + (a-b-c+d)*u*v) / 255;
  }
  function fbm(x, y, o){ let s = 0, a = .5, t = 0; for (let i = 0; i < o; i++){ s += a*vn(x, y); t += a; const nx = 1.6*x + 1.2*y + 17.3, ny = -1.2*x + 1.6*y + 9.1; x = nx; y = ny; a *= .5; } return s / t; }

  const cl = (x, a = 0, b = 1) => x < a ? a : x > b ? b : x;
  const sm = (a, b, x) => { const t = cl((x-a)/(b-a)); return t*t*(3-2*t); };
  const mix = (a, b, t) => [a[0]+(b[0]-a[0])*t, a[1]+(b[1]-a[1])*t, a[2]+(b[2]-a[2])*t];
  const mul = (c, k) => [c[0]*k, c[1]*k, c[2]*k];
  const rgb = (c, a = 1) => `rgba(${c[0]|0},${c[1]|0},${c[2]|0},${a})`;
  function kf(table, s){ // interpolación por elevación del sol
    if (s <= table[0][0]) return table[0].slice(1);
    for (let i = 1; i < table.length; i++) if (s <= table[i][0]) { const a = table[i-1], b = table[i], t = (s-a[0])/(b[0]-a[0]); return a.slice(1).map((v, k) => Array.isArray(v) ? mix(v, b[k+1], t) : v + (b[k+1]-v)*t); }
    return table[table.length-1].slice(1);
  }
  //        elev   cénit             horizonte          luz ambiente
  const SKY = [[-20,[2,4,11],[5,8,18],.02],[-12,[4,8,22],[12,17,36],.04],[-8,[10,18,48],[38,40,74],.08],[-5,[20,34,84],[120,92,118],.15],[-2,[34,54,118],[214,112,86],.26],[0,[42,66,134],[255,134,66],.36],[3,[50,86,160],[255,166,96],.5],[7,[48,96,178],[240,190,140],.66],[14,[40,100,192],[200,210,214],.84],[30,[34,96,200],[176,206,234],.97],[60,[28,90,204],[166,202,238],1]];
  const SUN = [[-4,[255,70,30]],[0,[255,110,45]],[3,[255,145,70]],[8,[255,195,125]],[18,[255,234,205]],[60,[255,250,240]]];

  /* ---------- motor de dibujo (sirve para la vista grande y para las miniaturas) */
  const HOR = .64;
  function makeRenderer(cv){
    const ctx = cv.getContext("2d");
    const mk = (w, h) => { const c = document.createElement("canvas"); c.width = w; c.height = h; return c; };
    const R = {W:0, H:0, dpr:1, dx:0, dz:0, cx:0, flash:0, bolt:null, t:0};
    let buf, bctx, img, mask, mctx, mimg, bw, bh, stars, tmp, tctx, grainC, ridges, lights, drops;
    function setup(W, H, dpr){
      R.W = W; R.H = H; R.dpr = dpr; R.force = true;
      cv.width = Math.max(1, Math.round(W*dpr)); cv.height = Math.max(1, Math.round(H*dpr));
      bw = Math.max(64, Math.min(230, Math.round(W/2.6))); const hz = H*HOR;
      bh = Math.ceil(bw*hz/W) + 2;
      buf = mk(bw, bh); bctx = buf.getContext("2d"); img = bctx.createImageData(bw, bh);
      mask = mk(bw, bh); mctx = mask.getContext("2d"); mimg = mctx.createImageData(bw, bh);
      tmp = mk(cv.width, cv.height); tctx = tmp.getContext("2d");
      // estrellas y vía láctea
      stars = mk(cv.width, Math.ceil(hz*dpr)); const sc = stars.getContext("2d");
      let s = 99; const r = () => (s = (s*16807)%2147483647)/2147483647;
      for (let i = 0; i < 2600; i++){ const t = r(), off = (r()+r()+r()-1.5)*.09; const x = t*stars.width, y = (.95 - t*.85 + off)*stars.height; sc.fillStyle = `rgba(210,215,255,${.05+r()*.12})`; sc.fillRect(x, y, dpr*.9, dpr*.9); }
      const n = Math.round(W*hz/900);
      for (let i = 0; i < n; i++){ const b = Math.pow(r(), 3), x = r()*stars.width, y = Math.pow(r(), 1.3)*stars.height*.97; const c = r() < .15 ? "255,214,180" : r() < .3 ? "190,210,255" : "255,255,255"; sc.fillStyle = `rgba(${c},${.35+b*.65})`; const z = (b > .6 ? 1.7 : b > .25 ? 1.2 : .8)*dpr; sc.fillRect(x, y, z, z); if (b > .8){ sc.fillStyle = `rgba(${c},.18)`; sc.fillRect(x-z, y-z, z*3, z*3); } }
      // grano
      grainC = mk(160, 160); const gc = grainC.getContext("2d"), gi = gc.createImageData(160, 160);
      for (let i = 0; i < gi.data.length; i += 4){ const g = 128 + (r()-.5)*255; gi.data[i] = gi.data[i+1] = gi.data[i+2] = g; gi.data[i+3] = 255; } gc.putImageData(gi, 0, 0);
      // montañas (4 capas, de lejos a cerca)
      ridges = [0,1,2,3].map(l => Array.from({length: 97}, (_, i) => { const x = i/96*(3+l*1.5); return fbm(x + l*31, l*7.7, 5)*1.25 - .2 + (l === 0 ? Math.pow(vn(x*.6+3, 2), 2)*.6 : 0); }));
      // luces de ciudad
      lights = Array.from({length: Math.round(W/3)}, () => ({x: Math.pow(r(), 1)*W, d: r(), b: r(), w: r() < .7, p: r()*6}));
      drops = Array.from({length: 260}, () => [r(), r(), .6 + r()*.6]);
    }
    const ridgeY = (l, x) => { const a = ridges[l], f = cl(x/R.W)*96, i = Math.min(95, f|0), t = f - i; const h = a[i]+(a[i+1]-a[i])*t; return R.H*HOR - R.H*[.07,.05,.03,.012][l] - h*R.H*[.07,.075,.055,.035][l]; };
    const groundY = () => R.H*HOR + R.H*.035;

    function draw(v, dt, still){
      const W = R.W, H = R.H, dpr = R.dpr, hz = H*HOR;
      R.t += dt;
      const hour = (v.hour + 24) % 24, ang = (hour - 1.5)/24*Math.PI*2;
      const s = -Math.cos(ang)*62;                       // elevación del sol en grados
      const ms = -Math.cos(ang + Math.PI*.92)*48;        // luna
      const cover = v.cover/100, cir = v.cirrus/100, dust = v.dust/100, haze = v.haze/100, blue = v.blue/100, glow = v.glow/100, hum = v.hum/100;
      let [Z, Hc, amb] = kf(SKY, s);
      let sunC = kf(SUN, s)[0];
      const gZ = (Z[0]+Z[1]+Z[2])/3; Z = mix([gZ,gZ,gZ], Z, blue); Z[2] *= .85 + .15*blue;
      const lowSun = Math.exp(-Math.pow((s-2)/7, 2)), night = sm(-4, -14, s), dayK = sm(-6, 8, s);
      // polvo, neblina y nubes cambian el color del cielo
      Z = mix(Z, mul([186,152,112], amb*.95), dust*.7); Hc = mix(Hc, mul([226,170,108], .2 + amb*.85), dust*.85);
      sunC = mix(sunC, [255,150,80], dust*.6);
      Hc = mix(Hc, mix(mul([210,212,216], amb), sunC, lowSun*.5*(1 - cover*.8)), haze*.55);
      const dark = 1 - Math.pow(cover, 3)*.5;
      Z = mix(Z, mul([132,140,154], (amb*.9 + .02)*dark), cover*cover*.85); Hc = mix(Hc, mul([154,160,170], (amb*.9 + .03)*dark), cover*cover*.8);
      const sunI = sm(-3, 3, s)*(1 - dust*.55)*(1 - haze*.25);
      const sunX = W*(.5 - Math.sin(ang)*.44), sunY = hz - s/36*hz;
      const moonX = W*(.5 - Math.sin(ang + Math.PI*.92)*.4), moonY = hz - ms/36*hz;
      const moonI = sm(-2, 6, ms)*night;
      const cloudAmb = mix(mix(Z, Hc, .55), [120,128,150], .25);
      const ambC = mul(cloudAmb, 1.05*(1 - Math.pow(cover, 3)*.35));
      const fogK = .01 + .3/Math.max(.3, v.vis) + haze*.02;
      const cldH = .016 + (v.base - 500)/11500*.11, cirH = .19;
      const wr = v.wdir/180*Math.PI, wk = .0045 + v.wind*.0007;
      if (!still){ R.dx += Math.sin(wr)*wk*dt*6; R.dz -= Math.cos(wr)*wk*dt*6; R.cx += wk*dt*1.5; }
      const ox = ((sunX/W) - .5)*.35, oz = .05 + lowSun*.12;
      const th = .8 - cover*.78, aspect = W/H, sc = W/bw;
      const D = img.data, M = mimg.data;
      R.odd = !R.odd; const doSky = still || R.odd || R.force; R.force = false;
      const cityGlow = night*(1 - cover*.2)*.9;
      if (doSky) for (let j = 0; j < bh; j++){
        const y = (j + .5)*sc, dyH = (hz - y)/H, pT = cl(dyH/(hz/H));
        const t = Math.pow(pT, .5);
        const bR = Hc[0]+(Z[0]-Hc[0])*t, bG = Hc[1]+(Z[1]-Hc[1])*t, bB = Hc[2]+(Z[2]-Hc[2])*t;
        const belt = sm(-7, -1, s)*sm(2, -1, s)*Math.exp(-Math.pow((pT - .2)/.09, 2));
        const shadowBand = sm(-7, -1, s)*sm(2, -1, s)*Math.exp(-Math.pow(pT/.08, 2));
        const lp = night*Math.exp(-pT*7)*(1 - cover*.4)*20;
        const dC = dyH > .0015 ? cldH/dyH : 1e9, dCi = dyH > .0015 ? cirH/dyH : 1e9;
        for (let i = 0; i < bw; i++){
          const x = (i + .5)*sc, k = (j*bw + i)*4;
          let r = bR + lp*1.2, g = bG + lp*.75, b = bB + lp*.45;
          const ax = Math.abs(x - sunX)/W;
          // lado del sol más cálido
          const warmS = Math.exp(-ax*2.6)*lowSun*Math.pow(1 - pT, 2.2)*(1 - cover*.5);
          r += (sunC[0]*.95 - r)*warmS*.75; g += (sunC[1]*.8 - g)*warmS*.75; b += (sunC[2]*.6 - b)*warmS*.75;
          // cinturón de Venus (rosa) y sombra de la Tierra en el lado contrario
          const opp = cl(ax*1.6);
          r += (205*amb*1.6 - r)*belt*opp*.45; g += (140*amb*1.6 - g)*belt*opp*.45; b += (170*amb*1.6 - b)*belt*opp*.45;
          r -= r*shadowBand*opp*.25; g -= g*shadowBand*opp*.15;
          // halo del sol (Mie) y de la luna
          const sx = (x - sunX)/H, sy = (y - sunY)/H, gs = Math.sqrt(sx*sx + sy*sy);
          const mie = sunI*glow*(1 - Math.pow(cover, 3)*.8)*(.75*Math.exp(-gs*18) + .32*Math.exp(-gs*4.5)*(1 + haze + dust*.6))*(1 - cover*.55);
          r += sunC[0]*mie; g += sunC[1]*mie*.92; b += sunC[2]*mie*.8;
          if (moonI > .01){ const mx = (x - moonX)/H, my = (y - moonY)/H, gm = Math.sqrt(mx*mx + my*my), mg = moonI*(.35*Math.exp(-gm*14) + .08*Math.exp(-gm*3))*(1 + haze*1.5); r += 190*mg; g += 205*mg; b += 235*mg; }
          const skyR = r, skyG = g, skyB = b;
          let alpha = 0;
          // cirros
          if (cir > .01 && dCi < 60){
            const wx = (x/W - .5)*aspect*dCi*2;
            const n = (fbm(wx*.13 + R.cx, dCi*2.4 + R.cx*.3, 4) - .5)*2.2 + .5;
            const cd = sm(.5, .9, n)*cir*(1 - sm(14, 50, dCi))*sm(.0015, .02, dyH);
            if (cd > .002){
              const lit = sm(-9, -1, s)*(1 - cover*.6);
              const cc = mix(mul(ambC, .9 + dayK*.25), mul(mix(sunC, [255,120,150], sm(1, -5, s)*.6), 1.15), cl(lowSun*1.4 + sm(4, -6, s)*.8)*lit);
              const nc = mix(cc, mul(cloudAmb, .5), night);
              const fa = 1 - Math.exp(-dCi*fogK*.4);
              const cr = nc[0] + (skyR - nc[0])*fa, cg = nc[1] + (skyG - nc[1])*fa, cb = nc[2] + (skyB - nc[2])*fa;
              const a2 = cd*.85; r += (cr - r)*a2; g += (cg - g)*a2; b += (cb - b)*a2; alpha = a2*.7;
            }
          }
          // cúmulos con perspectiva
          if (cover > .01 && dC < 90){
            const u = dC*5.5, wx = (x/W - .5)*aspect*u*2 + R.dx*5, wz = u + R.dz*5;
            const far = sm(18, 60, u);
            let dens = 0, n = 0;
            if (far < .999){ n = (fbm(wx, wz, 5) - .5)*2.5 + .5; dens = sm(th, th + .2, n); }
            dens = dens*(1 - far) + Math.pow(cover, 1.6)*far;
            if (dens > .003){
              let sh = .6;
              if (far < .9){ const n2 = (fbm(wx + ox*3, wz - oz*3, 4) - .5)*2.5 + .5; sh = cl(.55 + (n - n2)*1.6, .05, 1.1); }
              const thick = cl(dens*(.3 + cover*.9));
              const lit = sunI*(1 - Math.pow(cover, 2)*.88);
              let cr = sunC[0]*lit*(.18 + .95*sh)*(1 - thick*.5) + ambC[0]*(.42 + .28*(1 - thick));
              let cg = sunC[1]*lit*(.18 + .95*sh)*(1 - thick*.5) + ambC[1]*(.42 + .28*(1 - thick));
              let cb = sunC[2]*lit*(.18 + .95*sh)*(1 - thick*.5) + ambC[2]*(.46 + .3*(1 - thick));
              const under = sm(-7, -.5, s)*sm(5, 0, s)*(1 - cover*.45)*(1 - sm(.75, 1, cover)*.85)*(1 - pT*.4)*Math.exp(-ax*1.2)*1.25;
              cr += (sunC[0]*1.05 - cr)*under*(.5 + .5*(1 - sh)); cg += (sunC[1]*.85 - cg)*under*(.5 + .5*(1 - sh)); cb += (sunC[2]*.7 + 30 - cb)*under*(.5 + .5*(1 - sh));
              // borde plateado a contraluz
              const silver = sunI*glow*Math.exp(-gs*9)*(1 - dens)*2.2;
              cr += sunC[0]*silver; cg += sunC[1]*silver; cb += sunC[2]*silver;
              // de noche: luna por arriba y ciudad naranja por debajo
              if (night > .01){ const mlit = moonI*(.25 + sh*.5)*55; cr += mlit*.9; cg += mlit; cb += mlit*1.15; const cgw = cityGlow*thick*(1 - pT)*sm(.12, .01, dyH*(1 + cldH*8))*60; cr += cgw*1.3; cg += cgw*.8; cb += cgw*.4; }
              const fa = 1 - Math.exp(-dC*fogK*.9);
              cr += (skyR - cr)*fa; cg += (skyG - cg)*fa; cb += (skyB - cb)*fa;
              const a = dens*(1 - fa*.55)*sm(.0008, .006, dyH);
              r += (cr - r)*a; g += (cg - g)*a; b += (cb - b)*a; alpha = 1 - (1 - alpha)*(1 - a);
            }
          }
          if (dyH <= 0){ r = Hc[0]; g = Hc[1]; b = Hc[2]; alpha = 1; }
          D[k] = r; D[k+1] = g; D[k+2] = b; D[k+3] = 255;
          M[k] = M[k+1] = M[k+2] = 255; M[k+3] = (1 - alpha)*255;
        }
      }
      if (doSky){ bctx.putImageData(img, 0, 0); mctx.putImageData(mimg, 0, 0); }
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0); ctx.globalCompositeOperation = "source-over"; ctx.globalAlpha = 1;
      ctx.imageSmoothingEnabled = true; ctx.imageSmoothingQuality = "high";
      ctx.drawImage(buf, 0, 0, bw, bh, 0, 0, W, bh*sc);
      // estrellas, luna y disco del sol, tapados por las nubes
      tctx.setTransform(1, 0, 0, 1, 0, 0); tctx.globalCompositeOperation = "source-over"; tctx.clearRect(0, 0, tmp.width, tmp.height);
      const starA = night*(1 - haze*.7)*(1 - dust*.8);
      if (starA > .01){ tctx.globalAlpha = starA; tctx.drawImage(stars, 0, 0); tctx.globalAlpha = 1; }
      tctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      if (ms > -2 && night > .05){
        const mr = Math.max(3, W*.011); const mg = tctx.createRadialGradient(moonX - mr*.3, moonY - mr*.3, mr*.1, moonX, moonY, mr);
        mg.addColorStop(0, "rgba(250,248,240,1)"); mg.addColorStop(1, "rgba(200,204,214,1)");
        tctx.globalAlpha = night*(1 - haze*.5); tctx.fillStyle = mg; tctx.beginPath(); tctx.arc(moonX, moonY, mr, 0, 7); tctx.fill();
        tctx.fillStyle = "rgba(120,126,140,.25)"; [[.3,-.2,.28],[-.35,.25,.2],[.1,.4,.15]].forEach(([a, c, d]) => { tctx.beginPath(); tctx.arc(moonX + a*mr, moonY + c*mr, d*mr, 0, 7); tctx.fill(); });
        tctx.globalAlpha = 1;
      }
      if (s > -1.5){
        const sr = Math.max(3, W*.0095)*(1 + lowSun*.25);
        const sg = tctx.createRadialGradient(sunX, sunY, 0, sunX, sunY, sr);
        const dc = mix(sunC, [255,255,255], .55 - lowSun*.25);
        sg.addColorStop(0, rgb([255,255,250])); sg.addColorStop(.7, rgb(dc)); sg.addColorStop(1, rgb(dc, .2));
        tctx.globalAlpha = cl(sunI*1.3); tctx.fillStyle = sg; tctx.beginPath(); tctx.ellipse(sunX, sunY, sr, sr*(1 - lowSun*.12), 0, 0, 7); tctx.fill(); tctx.globalAlpha = 1;
      }
      tctx.setTransform(1, 0, 0, 1, 0, 0); tctx.globalCompositeOperation = "destination-in";
      tctx.drawImage(mask, 0, 0, bw, bh, 0, 0, tmp.width, bh*sc*dpr);
      tctx.globalCompositeOperation = "source-over";
      ctx.setTransform(1, 0, 0, 1, 0, 0); ctx.globalCompositeOperation = "lighter"; ctx.drawImage(tmp, 0, 0); ctx.globalCompositeOperation = "source-over"; ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      // cuánto se ve el sol (para el brillo y los destellos)
      let sunVis = 0;
      if (s > -1.5 && sunX > -W*.1 && sunX < W*1.1 && sunY > -H*.2 && sunY < hz){ const mi = cl(Math.round(sunX/sc), 0, bw-1), mj = cl(Math.round(sunY/sc), 0, bh-1); sunVis = (M[(mj*bw + mi)*4 + 3]/255)*sunI; }
      if (sunVis > .01){
        const br = W*.22*(.5 + glow*.6), bg = ctx.createRadialGradient(sunX, sunY, 0, sunX, sunY, br);
        bg.addColorStop(0, rgb(mix(sunC, [255,255,255], .5), .55*sunVis)); bg.addColorStop(.12, rgb(sunC, .22*sunVis)); bg.addColorStop(1, rgb(sunC, 0));
        ctx.globalCompositeOperation = "lighter"; ctx.fillStyle = bg; ctx.fillRect(0, 0, W, H); ctx.globalCompositeOperation = "source-over";
      }
      // montañas con perspectiva aérea
      const snow = sm(3, -6, v.temp), dry = cl(dust*1.2 + sm(28, 38, v.temp)*.6);
      const baseT = mix(mix([44,66,40], [128,110,78], dry), [214,222,232], snow);
      const dists = [34, 20, 10, 4];
      const fogCol = mix(Hc, sunC, lowSun*.25*(1 - cover));
      if (cover > .8) sunC = mix(sunC, [170,175,190], sm(.8, 1, cover)*.7);
      for (let l = 0; l < 4; l++){
        const f = cl(1 - Math.exp(-dists[l]*(.85/Math.max(.3, v.vis) + .006 + haze*.025 + dust*.03)));
        let col = mul(baseT, amb*(.55 + l*.12) + .015);
        col = mix(col, mul([30,40,70], .25), night*.5);
        col = mix(col, fogCol, f*(1 - night*.4));
        if (night > .5) col = mix(col, mul(Hc, .7), f*.6);
        const gradT = ctx.createLinearGradient(0, hz - H*.16, 0, groundY() + 4);
        gradT.addColorStop(0, rgb(mix(col, sunC, lowSun*sunI*.18*(1 - f)))); gradT.addColorStop(1, rgb(mix(col, fogCol, .25 + f*.2)));
        ctx.fillStyle = gradT; ctx.beginPath(); ctx.moveTo(0, H);
        for (let i = 0; i <= 96; i++){ const x = i/96*W; ctx.lineTo(x, ridgeY(l, x)); }
        ctx.lineTo(W, H); ctx.closePath(); ctx.fill();
        if (lowSun*sunI > .05){ ctx.strokeStyle = rgb(sunC, lowSun*sunI*.45*(1 - f*.7)); ctx.lineWidth = 1.2; ctx.beginPath(); for (let i = 0; i <= 96; i++){ const x = i/96*W; i ? ctx.lineTo(x, ridgeY(l, x)) : ctx.moveTo(x, ridgeY(l, x)); } ctx.stroke(); }
        if (l === 2 && night > .05){ // luces de los pueblos
          ctx.globalCompositeOperation = "lighter";
          const lf = cl(1 - Math.exp(-6*(.85/Math.max(.3, v.vis) + haze*.03)));
          lights.forEach(p => {
            const top = ridgeY(2, p.x) + 2, gy = groundY(); if (gy - top < 2) return;
            const y = top + (gy - top)*Math.pow(p.d, .7);
            const tw = still ? 1 : .75 + .25*Math.sin(R.t*3 + p.p*5);
            const a = night*(1 - lf*.8)*(.35 + p.b*.65)*tw;
            ctx.fillStyle = p.w ? `rgba(255,186,110,${a})` : `rgba(230,240,255,${a})`;
            const z = .7 + p.b*1.1; ctx.fillRect(p.x, y, z, z);
            if (p.b > .85){ ctx.fillStyle = `rgba(255,170,90,${a*.15})`; ctx.beginPath(); ctx.arc(p.x, y, 5, 0, 7); ctx.fill(); }
          });
          ctx.globalCompositeOperation = "source-over";
        }
      }
      // suelo y pista
      const gy = groundY(), cx = W*.5;
      const wet = cl(v.rain/60);
      let nearC = mix(mul(baseT, amb*.8 + .01), [8,10,14], night*.4);
      const gf = cl(1 - Math.exp(-2*(.85/Math.max(.3, v.vis) + haze*.03)));
      const gg = ctx.createLinearGradient(0, gy, 0, H);
      gg.addColorStop(0, rgb(mix(nearC, fogCol, .18 + gf*.6))); gg.addColorStop(1, rgb(mul(nearC, .7)));
      ctx.fillStyle = gg; ctx.fillRect(0, gy, W, H - gy);
      const z2y = z => gy + (H - gy)/z, hw = z => W*.34/z;
      const asph = mix(mul([46,48,54], amb*1.1 + .02), mul(fogCol, .8), .12 + wet*.25);
      const rg = ctx.createLinearGradient(0, gy, 0, H);
      rg.addColorStop(0, rgb(mix(asph, fogCol, .55 + gf*.3))); rg.addColorStop(1, rgb(asph));
      ctx.fillStyle = rg; ctx.beginPath(); ctx.moveTo(cx - hw(60), z2y(60)); ctx.lineTo(cx + hw(60), z2y(60)); ctx.lineTo(cx + hw(1), H); ctx.lineTo(cx - hw(1), H); ctx.fill();
      // reflejo del cielo en la pista mojada o a contraluz
      const sheen = Math.max(wet*.35, lowSun*sunVis*.45);
      if (sheen > .02){ const sg2 = ctx.createLinearGradient(0, gy, 0, H); sg2.addColorStop(0, rgb(mix(Hc, sunC, lowSun), sheen)); sg2.addColorStop(.6, rgb(mix(Hc, sunC, lowSun), sheen*.25)); sg2.addColorStop(1, rgb(Hc, 0)); ctx.globalCompositeOperation = "screen"; ctx.fillStyle = sg2; ctx.beginPath(); ctx.moveTo(cx - hw(60), z2y(60)); ctx.lineTo(cx + hw(60), z2y(60)); ctx.lineTo(cx + hw(1), H); ctx.lineTo(cx - hw(1), H); ctx.fill(); ctx.globalCompositeOperation = "source-over"; }
      const paint = rgb(mix(mul([225,225,220], amb*.8 + .05), fogCol, .2), .5);
      ctx.fillStyle = paint;
      for (let z0 = 1.04; z0 < 50; z0 *= 1.34){ const z1 = z0*1.13, y0 = z2y(z0), y1 = z2y(z1), w0 = W*.004/z0, w1 = W*.004/z1; ctx.beginPath(); ctx.moveTo(cx - w0, y0); ctx.lineTo(cx + w0, y0); ctx.lineTo(cx + w1, y1); ctx.lineTo(cx - w1, y1); ctx.fill(); }
      [-1, 1].forEach(sd => { ctx.strokeStyle = paint; ctx.lineWidth = 1; ctx.beginPath(); ctx.moveTo(cx + sd*hw(60)*.96, z2y(60)); ctx.lineTo(cx + sd*hw(1)*.96, H); ctx.stroke(); });
      for (let i = 0; i < 8; i++){ const z0 = 1.25, z1 = 1.6, off = (i < 4 ? -1 : 1)*(.18 + (i % 4)*.17); ctx.beginPath(); [[z0, off - .06], [z0, off + .06], [z1, off + .06], [z1, off - .06]].forEach(([z, o], k) => { const p = [cx + o*hw(z)*2, z2y(z)]; k ? ctx.lineTo(...p) : ctx.moveTo(...p); }); ctx.fill(); }
      // luces de pista y PAPI
      const lightK = cl(night*1.2 + (1 - amb)*.6 + (1 - cl(v.vis/5))*.6);
      ctx.globalCompositeOperation = "lighter";
      for (let z = 1.1; z < 55; z *= 1.16){ [-1, 1].forEach(sd => { const x = cx + sd*hw(z)*1.03, y = z2y(z), r = Math.max(.5, 1.5/z); ctx.fillStyle = `rgba(255,236,190,${.95*lightK})`; ctx.beginPath(); ctx.arc(x, y, r, 0, 7); ctx.fill(); if (z < 4){ ctx.fillStyle = `rgba(255,220,150,${.1*lightK})`; ctx.beginPath(); ctx.arc(x, y, r*3.5, 0, 7); ctx.fill(); } }); }
      [0,1,2,3].forEach(i => { const z = 7, x = cx - hw(z)*(1.5 + i*.22), y = z2y(z); ctx.fillStyle = i < 2 ? `rgba(255,255,255,${.4 + .6*lightK})` : `rgba(255,40,30,${.4 + .6*lightK})`; ctx.beginPath(); ctx.arc(x, y, 1.6, 0, 7); ctx.fill(); });
      ctx.globalCompositeOperation = "source-over";
      // niebla baja
      const mist = cl(haze*.4 + (1 - cl(v.vis/10))*.75 + hum*.12*sm(9, 6, Math.abs(hour - 7)) + dust*.25);
      if (mist > .01){ const mg = ctx.createLinearGradient(0, hz - H*.12, 0, H); mg.addColorStop(0, rgb(fogCol, 0)); mg.addColorStop(.35, rgb(fogCol, mist*.75)); mg.addColorStop(1, rgb(fogCol, mist*.55)); ctx.fillStyle = mg; ctx.fillRect(0, hz - H*.12, W, H); }
      if (v.vis < 2){ ctx.fillStyle = rgb(fogCol, (1 - v.vis/2)*.55); ctx.fillRect(0, 0, W, H); }
      // rayos
      const storm = v.rain > 55 && cover > .8;
      if (storm && !still && Math.random() < dt*.35){ R.flash = 1; let x = W*(.15 + Math.random()*.7), y = 0; R.bolt = [[x, y]]; while (y < hz - H*.04){ y += H*(.03 + Math.random()*.05); x += (Math.random() - .5)*W*.04; R.bolt.push([x, y]); } }
      if (R.flash > 0){
        ctx.globalCompositeOperation = "screen"; ctx.fillStyle = `rgba(200,210,255,${R.flash*R.flash*.55})`; ctx.fillRect(0, 0, W, H);
        if (R.flash > .55 && R.bolt){ ctx.strokeStyle = "rgba(235,240,255,.95)"; ctx.lineWidth = 2; ctx.shadowColor = "#bcd0ff"; ctx.shadowBlur = 14; ctx.beginPath(); R.bolt.forEach((p, i) => i ? ctx.lineTo(...p) : ctx.moveTo(...p)); ctx.stroke(); ctx.shadowBlur = 0; }
        ctx.globalCompositeOperation = "source-over"; R.flash -= dt*2.6;
      }
      // lluvia o nieve
      const rain = v.rain/100;
      if (rain > .02){
        const isSnow = v.temp <= 1, cnt = Math.round(drops.length*rain), sl = Math.sin(wr)*v.wind/60, T = still ? 0 : R.t;
        ctx.strokeStyle = rgb(mix([170,180,200], [255,255,255], amb*.4), .38); ctx.fillStyle = "rgba(255,255,255,.85)"; ctx.lineWidth = 1;
        for (let i = 0; i < cnt; i++){
          const [x0, y0, sp] = drops[i];
          if (isSnow){ const y = ((y0 + T*.07*sp) % 1)*H, x = ((x0 + Math.sin(T + i)*.01 + T*sl*.05) % 1 + 1) % 1*W; ctx.beginPath(); ctx.arc(x, y, 1.3*sp, 0, 7); ctx.fill(); }
          else { const y = ((y0 + T*1.1*sp) % 1)*H, x = ((x0 + T*sl*.4) % 1 + 1) % 1*W; ctx.beginPath(); ctx.moveTo(x, y); ctx.lineTo(x - sl*16, y - 16*sp); ctx.stroke(); }
        }
      }
      // destellos de lente
      const fl = v.flare/100*sunVis;
      if (fl > .01){
        ctx.globalCompositeOperation = "lighter";
        ctx.save(); ctx.translate(sunX, sunY); ctx.scale(1, .018); const an = ctx.createRadialGradient(0, 0, 0, 0, 0, W*.7); an.addColorStop(0, `rgba(190,215,255,${.55*fl})`); an.addColorStop(1, "rgba(190,215,255,0)"); ctx.fillStyle = an; ctx.fillRect(-W, -W, W*2, W*2); ctx.restore();
        [[.35, .03, [255,180,120]], [.62, .014, [140,200,255]], [.9, .045, [150,255,190]], [1.25, .022, [255,140,200]], [1.6, .065, [120,170,255]]].forEach(([t, r, c]) => {
          const x = sunX + (cx - sunX)*t, y = sunY + (H*.5 - sunY)*t; const rr = W*r;
          const gh = ctx.createRadialGradient(x, y, rr*.6, x, y, rr); gh.addColorStop(0, rgb(c, .05*fl)); gh.addColorStop(.85, rgb(c, .14*fl)); gh.addColorStop(1, rgb(c, 0));
          ctx.fillStyle = gh; ctx.beginPath(); ctx.arc(x, y, rr, 0, 7); ctx.fill();
        });
        ctx.globalCompositeOperation = "source-over";
      }
      // tono cálido / frío
      if (Math.abs(v.warm) > .5){ ctx.globalCompositeOperation = "soft-light"; ctx.fillStyle = v.warm > 0 ? `rgba(255,145,40,${v.warm/85})` : `rgba(50,130,255,${-v.warm/85})`; ctx.fillRect(0, 0, W, H); ctx.globalCompositeOperation = "source-over"; }
      // viñeta
      const vg = ctx.createRadialGradient(W/2, H*.48, Math.min(W, H)*.35, W/2, H*.5, Math.max(W, H)*.78);
      vg.addColorStop(0, "rgba(0,0,0,0)"); vg.addColorStop(1, `rgba(0,0,0,${.22 + v.cine*.18 + v.grain/600})`); ctx.fillStyle = vg; ctx.fillRect(0, 0, W, H);
      // grano de película
      if (v.grain > 1){ ctx.save(); ctx.globalCompositeOperation = "overlay"; ctx.globalAlpha = v.grain/100*.32; const pat = ctx.createPattern(grainC, "repeat"); const ox2 = still ? 0 : Math.random()*160, oy2 = still ? 0 : Math.random()*160; ctx.translate(-ox2, -oy2); ctx.fillStyle = pat; ctx.fillRect(0, 0, W + 160, H + 160); ctx.restore(); }
      // bandas de cine
      if (v.cine > .01){ const bar = v.cine*H*.1; ctx.fillStyle = "#000"; ctx.fillRect(0, 0, W, bar); ctx.fillRect(0, H - bar, W, bar); }
      cv.style.filter = `brightness(${v.bright/100}) saturate(${v.sat/100}) contrast(${v.contrast/100})`;
      return {s};
    }
    return {setup, draw, get W(){ return R.W; }};
  }


  /* ---------- interfaz de la app */
  const panel = document.getElementById("tab-skies");
  panel.innerHTML = `
    <h2 class="ptitle">Skies</h2><p class="psub">Tiempo, atmósfera, luz y hora de MSFS 2024. Elige un cielo, ajústalo y pulsa «Aplicar en MSFS».</p>
    <div id="skBanner" class="msfs-banner off">Comprobando el simulador…</div>
    <div class="sk-presets" id="skPresets" role="group" aria-label="Presets"></div>
    <div class="sk-tabs" role="tablist">
      <button type="button" role="tab" aria-selected="true" data-sktab="tiempo">Tiempo</button>
      <button type="button" role="tab" aria-selected="false" data-sktab="atmos">Atmósfera</button>
      <button type="button" role="tab" aria-selected="false" data-sktab="luz">Luz</button>
    </div>
    <div class="sk-body" id="skBody"></div>
    <div class="section-head"><h3>Aplicar</h3></div>
    <div class="sk-parts">
      <label class="check"><input type="checkbox" id="skPW" checked> Tiempo (nubes, viento, lluvia)</label>
      <label class="check"><input type="checkbox" id="skPL" checked> Imagen (color, neblina, grano)</label>
      <label class="check"><input type="checkbox" id="skPT" checked> Hora del día</label>
    </div>
    <button class="primary sk-apply" id="skApply">☁ Aplicar en MSFS</button>
    <div class="toolbar">
      <input id="skName" class="inp" maxlength="32" placeholder="Nombre del preset">
      <button id="skSave">Guardar preset</button>
    </div>
    <div class="toolbar">
      <button id="skReset" class="danger">Restaurar cielo de MSFS</button>
      <label class="check" style="margin-left:auto"><input type="checkbox" id="skAuto"> Cargar al volar</label>
    </div>
    <div id="skMsgs"></div>
    <p class="hint">El tiempo se guarda como preset de MSFS: en el simulador abre el menú de tiempo y elige «SimDirect Skies» al final de la lista. La imagen va por ReShade (instálalo en Configurar). «Restaurar» lo quita todo y deja tu ReShade de antes.</p>`;

  const mainEl = document.querySelector("main");
  const view = document.createElement("div"); view.id = "skiesView";
  view.innerHTML = `<canvas id="skyCanvas" aria-label="Vista previa del cielo"></canvas>
    <div class="sk-hud"><span class="metar" id="skMetar"></span><span></span><div class="bot"><span id="skSun"></span><span class="live">● vista previa</span></div></div>`;
  mainEl.appendChild(view);
  const isOn = () => panel.classList.contains("active");
  document.querySelectorAll(".tab[data-tab]").forEach(t => t.addEventListener("click", () => setTimeout(() => { document.body.classList.toggle("skies-on", isOn()); if (isOn()) { resize(); load(); } }, 0)));

  const body = panel.querySelector("#skBody"), tabs = panel.querySelectorAll("[data-sktab]");
  const inputs = {};
  let tab = "tiempo", mine = [], st = null, activePreset = null;
  const target = Object.assign({}, DEF), cur = Object.assign({}, DEF);
  function buildRows(){
    body.innerHTML = "";
    for (const k in inputs) delete inputs[k];
    P.filter(p => p[1] === tab).forEach(([id,,name,min,max,step,fmt]) => {
      const row = document.createElement("div"); row.className = "sk-row";
      const isBool = min === 0 && max === 1 && step === 1;
      row.innerHTML = isBool
        ? `<label style="cursor:pointer"><span>${name}</span><input type="checkbox" style="accent-color:var(--accent);width:18px;height:18px"></label>`
        : `<label><span>${name}</span><output></output></label><input type="range" min="${min}" max="${max}" step="${step}">`;
      body.appendChild(row);
      const inp = row.querySelector("input"), out = row.querySelector("output");
      const set = () => { if (isBool) inp.checked = target[id] > .5; else { inp.value = target[id]; out.textContent = fmt(+target[id]); } };
      set();
      inp.addEventListener("input", () => { target[id] = isBool ? (inp.checked ? 1 : 0) : +inp.value; if (out) out.textContent = fmt(target[id]); activePreset = null; markPresets(); });
      inputs[id] = set;
    });
  }
  const syncRows = () => Object.values(inputs).forEach(f => f());
  tabs.forEach(b => b.addEventListener("click", () => { tab = b.dataset.sktab; tabs.forEach(t => t.setAttribute("aria-selected", t === b)); buildRows(); }));
  buildRows();

  const thumbCv = document.createElement("canvas"), thumbR = makeRenderer(thumbCv);
  thumbR.setup(200, 125, 1);
  function thumb(v, c){ thumbR.draw(Object.assign({}, DEF, v), 0, true); const x = c.getContext("2d"); c.width = 200; c.height = 125; x.filter = thumbCv.style.filter || "none"; x.drawImage(thumbCv, 0, 0); x.filter = "none"; }
  const presetBox = panel.querySelector("#skPresets"), thumbQ = [];
  let pumping = false;
  function pump(){ if (pumping) return; pumping = true; const step = () => { const j = thumbQ.shift(); if (!j){ pumping = false; return; } thumb(j[0], j[1]); setTimeout(step, 16); }; setTimeout(step, 30); }
  function renderPresets(){
    presetBox.innerHTML = ""; thumbQ.length = 0;
    const all = PRESETS.map(p => ({name: p[0], v: p[1]})).concat(mine.map(p => ({name: p.name, v: p.v, mine: true})));
    all.forEach(p => {
      const b = document.createElement("button"); b.type = "button"; b.className = "sk-card" + (p.mine ? " mine" : ""); b.dataset.name = p.name;
      b.setAttribute("aria-pressed", p.name === activePreset);
      const c = document.createElement("canvas"); c.width = 200; c.height = 125;
      const lab = document.createElement("span"); lab.textContent = p.name;
      b.append(c, lab);
      if (p.mine){ const x = document.createElement("span"); x.className = "x"; x.textContent = "✕"; x.title = "Borrar"; x.addEventListener("click", e => { e.stopPropagation(); mine = mine.filter(m => m.name !== p.name); savePresets(); }); b.appendChild(x); }
      b.addEventListener("click", () => { Object.assign(target, DEF, p.v); activePreset = p.name; panel.querySelector("#skName").value = p.name; syncRows(); markPresets(); });
      presetBox.appendChild(b); thumbQ.push([p.v, c]);
    });
    pump();
  }
  function markPresets(){ presetBox.querySelectorAll(".sk-card").forEach(b => b.setAttribute("aria-pressed", b.dataset.name === activePreset)); }

  async function savePresets(){
    try { const r = await post("/api/skies/presets", {presets: mine}); mine = r.presets || mine; } catch (e) { toast("Sin conexión con SimDirect"); }
    renderPresets();
  }
  function banner(){
    const b = panel.querySelector("#skBanner");
    if (!st){ b.className = "msfs-banner off"; b.textContent = "Abre SimDirect desde su icono para aplicar el cielo en MSFS."; return; }
    const bits = [];
    bits.push(st.sim ? "MSFS conectado" : "MSFS no está en un vuelo (la hora se cambia dentro de un vuelo)");
    if (!st.weather_dirs.length) bits.push("no encuentro la carpeta de MSFS 2024");
    if (!st.reshade) bits.push("sin ReShade: la imagen no se aplica");
    b.className = "msfs-banner " + (st.sim && st.reshade ? "on" : "off");
    b.textContent = (st.sim ? "☁ " : "") + bits.join(" · ");
  }
  let loaded = false;
  async function load(){
    try { st = await (await fetch("/api/skies")).json(); } catch (e) { st = null; }
    if (st && !loaded){
      loaded = true;
      mine = st.presets || [];
      if (st.state && st.state.values){ Object.assign(target, DEF, st.state.values); Object.assign(cur, target); activePreset = st.state.name; if (st.state.name) panel.querySelector("#skName").value = st.state.name; }
      panel.querySelector("#skAuto").checked = !!(st.state && st.state.auto);
      syncRows(); renderPresets();
    }
    banner();
  }
  if (!presetBox.children.length) renderPresets();

  panel.querySelector("#skApply").onclick = async () => {
    const btn = panel.querySelector("#skApply"); btn.disabled = true; btn.textContent = "Aplicando…";
    const name = panel.querySelector("#skName").value.trim() || activePreset || "Mi cielo";
    try {
      const r = await post("/api/skies/apply", {values: target, name, parts: {weather: panel.querySelector("#skPW").checked, look: panel.querySelector("#skPL").checked, time: panel.querySelector("#skPT").checked}});
      panel.querySelector("#skMsgs").innerHTML = (r.msgs || []).map(m => `<div class="cine-msg">${m.replace(/</g, "&lt;")}</div>`).join("");
      toast(r.ok ? "Cielo aplicado" : "No se pudo aplicar", 3000);
    } catch (e) { toast("Sin conexión con SimDirect"); }
    btn.disabled = false; btn.textContent = "☁ Aplicar en MSFS"; load();
  };
  panel.querySelector("#skReset").onclick = async () => {
    try { const r = await post("/api/skies/reset", {}); panel.querySelector("#skMsgs").innerHTML = `<div class="cine-msg">${r.msg}</div>`; toast("Cielo de MSFS restaurado"); } catch (e) { toast("Sin conexión con SimDirect"); }
    Object.assign(target, DEF); activePreset = null; syncRows(); markPresets();
  };
  panel.querySelector("#skSave").onclick = () => {
    const name = panel.querySelector("#skName").value.trim().slice(0, 32);
    if (!name){ toast("Ponle un nombre al preset"); panel.querySelector("#skName").focus(); return; }
    if (PRESETS.some(p => p[0] === name)){ toast("Ese nombre ya lo usa un preset de SimDirect"); return; }
    mine = mine.filter(m => m.name !== name).concat([{name, v: Object.assign({}, target)}]);
    activePreset = name; savePresets(); toast("Preset guardado");
  };
  panel.querySelector("#skAuto").onchange = async (e) => {
    try { await post("/api/skies/auto", {auto: e.target.checked}); toast(e.target.checked ? "Se aplicará solo al entrar en cada vuelo" : "Ya no se aplica solo"); } catch (er) { toast("Sin conexión con SimDirect"); }
  };

  /* ---------- vista grande */
  const cv = view.querySelector("#skyCanvas"), main = makeRenderer(cv);
  const metar = view.querySelector("#skMetar"), sunTxt = view.querySelector("#skSun");
  const reduce = matchMedia("(prefers-reduced-motion: reduce)").matches;
  function resize(){ const r = cv.getBoundingClientRect(); if (r.width < 10) return; main.setup(r.width, r.height, Math.min(2, devicePixelRatio || 1)); }
  new ResizeObserver(resize).observe(cv);
  let t0 = performance.now(), lastHud = "";
  function frame(now){
    const dt = Math.min(.06, (now - t0)/1000); t0 = now;
    if (document.body.classList.contains("skies-on") && main.W > 10){
      const k = reduce ? 1 : 1 - Math.exp(-dt*2.4);
      P.forEach(([id]) => {
        if (id === "hour"){ const d = ((target.hour - cur.hour + 36) % 24) - 12; cur.hour = (cur.hour + d*k + 24) % 24; }
        else cur[id] += (target[id] - cur[id])*k;
      });
      hud(main.draw(cur, reduce ? 0 : dt, reduce));
    }
    requestAnimationFrame(frame);
  }

  function hud(info){
    const t = target;
    const wind = t.wind < 3 ? "00000KT" : String(Math.round(t.wdir/10)*10).padStart(3, "0") + String(Math.round(t.wind)).padStart(2, "0") + (t.wind > 25 ? "G" + Math.round(t.wind*1.35) : "") + "KT";
    const vis = t.vis >= 10 ? "9999" : String(Math.round(t.vis*1000/50)*50).padStart(4, "0");
    const oct = t.cover/100*8, base = String(Math.round(t.base/100)).padStart(3, "0");
    const cld = oct < .5 ? "" : (oct < 2.5 ? "FEW" : oct < 4.5 ? "SCT" : oct < 7.5 ? "BKN" : "OVC") + base + (t.rain > 55 && t.temp > 5 && t.cover > 80 ? "CB" : "");
    const wx = t.rain > 2 ? (t.rain > 70 ? "+" : t.rain < 40 ? "-" : "") + (t.temp <= 1 ? "SN" : t.rain > 55 && t.cover > 80 ? "TSRA" : "RA") : (t.vis < 1 ? "FG" : t.dust > 50 ? "DU" : t.vis < 5 ? (t.hum > 80 ? "BR" : "HZ") : "");
    const dew = Math.round(t.temp - (100 - t.hum)/5);
    const f = n => (n < 0 ? "M" : "") + String(Math.abs(Math.round(n))).padStart(2, "0");
    const hh = Math.floor(t.hour), mm = Math.floor((t.hour - hh)*60);
    const body2 = vis === "9999" && oct < .5 && !wx ? "CAVOK" : [vis, wx, cld || (t.vis >= 10 ? "NSC" : "")].filter(Boolean).join(" ");
    const txt = `METAR LEBL 21${String(hh).padStart(2, "0")}${String(mm).padStart(2, "0")}Z ${wind} ${body2} ${f(t.temp)}/${f(dew)} Q${Math.round(t.qnh)}`;
    if (txt !== lastHud){ metar.textContent = txt; lastHud = txt; }
    const sTxt = "SOL " + Math.round(info.s) + "°";
    if (sunTxt.textContent !== sTxt) sunTxt.textContent = sTxt;
  }
  requestAnimationFrame(frame);
  setInterval(() => { if (document.body.classList.contains('skies-on')) load(); }, 8000);
})();
