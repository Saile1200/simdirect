'use strict';
/* Plan del avión: la ruta que metes a mano en el avión (FMS, EFB o mapa de MSFS) aparece sola en la app */
(() => {
  const KEY = 'simdirect.syncPlan';
  let sync = store(KEY);
  if (sync === null || sync === undefined) sync = true;
  let last = null;

  const tb = document.getElementById('btnExport').closest('.toolbar');
  const box = document.createElement('div');
  box.className = 'simplan-box';
  box.innerHTML = `
    <label class="check"><input type="checkbox" id="spSync"> Usar el plan que metas en el avión (FMS, EFB o mapa de MSFS)</label>
    <div class="toolbar"><button id="spRead">✈ Leer plan del avión</button><button id="spUndo" hidden>↩ Volver a mi plan</button></div>
    <div id="spInfo" class="hint">Cuando metas la ruta en el avión, aparece aquí sola y se conecta con el mapa, el FMC y los anuncios.</div>`;
  tb.after(box);
  const $s = (s) => box.querySelector(s);
  $s('#spSync').checked = !!sync;
  $s('#spSync').onchange = (e) => {
    sync = e.target.checked; store(KEY, sync);
    if (sync && last && last.plan) apply(last.plan, false);
  };

  const sigOf = (p) => [(p.dep && p.dep.code) || '', ...p.waypoints.map((w) => w.name), (p.arr && p.arr.code) || ''].join('|');
  function toApp(sp) {
    const p = newPlan();
    p.aircraftId = plan.aircraftId;
    p.fromSim = true;
    const ap = (a) => (a ? (apt(a.name) || { code: a.name, name: a.name, lat: a.lat, lon: a.lon, elev: Math.round(a.alt || 0) }) : null);
    p.dep = ap(sp.dep); p.arr = ap(sp.arr);
    p.cruiseAlt = sp.cruise || plan.cruiseAlt || 35000;
    p.name = `Avión: ${p.dep ? p.dep.code : '?'} → ${p.arr ? p.arr.code : '…'}`;
    p.waypoints = (sp.waypoints || []).map((w) => ({ id: uid(), name: String(w.name).slice(0, 8), lat: w.lat, lon: w.lon, alt: w.alt > 500 ? Math.round(w.alt) : 0 }));
    return p;
  }

  function apply(sp, manual) {
    const p = toApp(sp);
    if (sigOf(p) === sigOf(plan)) { if (manual) toast('La app ya tiene el plan del avión'); return; }
    // un plan a medias del GPS no pisa un plan tuyo, salvo que lo pidas con el botón
    if (sp.partial && plan.waypoints.length && !plan.fromSim && !manual) return;
    if (!plan.fromSim) store('simdirect.prevPlan', plan);
    plan = p;
    if (plan.waypoints.filter((w) => !w.alt).length > plan.waypoints.length / 2) autoAltitudes();
    fillForm(); render(); fitRoute();
    $s('#spUndo').hidden = !store('simdirect.prevPlan');
    toast(`✈ Plan del avión en SimDirect: ${p.dep ? p.dep.code : '?'} → ${p.arr ? p.arr.code : '…'} · ${p.waypoints.length} puntos`, 3800);
  }

  function info() {
    const el = $s('#spInfo');
    if (!last) return;
    const sp = last.plan;
    el.textContent = sp
      ? `${last.msg}${sp.partial ? ' (incompleto: solo los puntos por los que pasa el GPS)' : ''}`
      : last.msg;
  }

  window.onSimPlan = (m) => {
    last = m; info();
    if (sync && m.plan) apply(m.plan, false);
  };

  $s('#spRead').onclick = async () => {
    if (!serverOk) { toast('Abre SimDirect desde su icono'); return; }
    try {
      const r = await post('/api/simplan/read');
      toast(r.msg, 3000);
      if (!r.ok) return;
      const v0 = last ? last.ver : -1;
      for (let i = 0; i < 12; i++) {
        await new Promise((res) => setTimeout(res, 1000));
        const st = await (await fetch('/api/simplan')).json();
        if (st.ver !== v0 || i === 11) { last = st; info(); if (st.plan) apply(st.plan, true); else toast(st.msg, 3500); break; }
      }
    } catch (e) { toast('Sin conexión con SimDirect'); }
  };

  $s('#spUndo').hidden = !store('simdirect.prevPlan') || !plan.fromSim;
  $s('#spUndo').onclick = () => {
    const prev = store('simdirect.prevPlan');
    if (!prev) return;
    plan = prev; fillForm(); render(); fitRoute();
    $s('#spUndo').hidden = true;
    toast('Has vuelto a tu plan');
  };
})();
