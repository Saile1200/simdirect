'use strict';
/* Anuncios de cabina: campanas (WebAudio) + voz (síntesis de Windows) disparados por fase de vuelo */

const Announcer = (() => {
  const S = Object.assign({
    auto: true, lang: 'es', airline: 'SimDirect Airlines', flightNo: 'SKP 1024', captain: 'Martínez',
    volume: 0.9, rate: 0.95, voiceEs: '', voiceEn: '', chimeOnBelt: true, ambient: false, ambVolume: 0.5, fx: true, fxVolume: 0.7,
  }, store('simdirect.ann') || {});
  let syncT = null;
  const save = () => {
    store('simdirect.ann', S);
    clearTimeout(syncT);
    syncT = setTimeout(() => serverOk && post('/api/sound/settings', { enabled: true, auto: S.auto, lang: S.lang, airline: S.airline,
      flightNo: S.flightNo, captain: S.captain, volume: Math.round(S.volume * 100), rate: Math.round((S.rate - 1) * 20),
      fx: false, natural: S.natural !== false, chimeOnBelt: S.chimeOnBelt, voiceEs: S.voiceEs, voiceEn: S.voiceEn }), 300);
  };
  let srvVoices = [];
  async function loadServer() {
    if (!serverOk) return;
    try {
      const r = await (await fetch('/api/sound/settings')).json();
      Object.assign(S, { auto: r.auto, lang: r.lang, airline: r.airline, flightNo: r.flightNo, captain: r.captain,
        volume: (r.volume ?? 90) / 100, rate: 1 + (r.rate || 0) / 20, natural: r.natural !== false, chimeOnBelt: r.chimeOnBelt, voiceEs: r.voiceEs, voiceEn: r.voiceEn });
      srvVoices = await (await fetch('/api/sound/voices')).json();
    } catch (e) { /* */ }
  }

  /* ---------------- campanas */
  let ctx = null;
  const ac = () => (ctx = ctx || new (window.AudioContext || window.webkitAudioContext)());
  function tone(freq, start, dur, gain) {
    const c = ac(), o = c.createOscillator(), o2 = c.createOscillator(), g = c.createGain();
    o.type = 'sine'; o.frequency.value = freq;
    o2.type = 'sine'; o2.frequency.value = freq * 2.01;           // armónico tipo campana
    const g2 = c.createGain(); g2.gain.value = 0.18;
    o2.connect(g2).connect(g); o.connect(g); g.connect(c.destination);
    const t = c.currentTime + start;
    g.gain.setValueAtTime(0, t);
    g.gain.linearRampToValueAtTime(gain * S.volume, t + 0.01);
    g.gain.exponentialRampToValueAtTime(0.0008, t + dur);
    o.start(t); o2.start(t); o.stop(t + dur); o2.stop(t + dur);
  }
  const CHIMES = {
    single: () => tone(784, 0, 1.6, 0.35),                         // cinturones
    double: () => { tone(659, 0, 1.6, 0.35); tone(523, 0.55, 2.0, 0.35); },   // tripulación / PA
    triple: () => { tone(784, 0, 1.3, 0.3); tone(659, 0.4, 1.3, 0.3); tone(523, 0.8, 2.0, 0.3); }, // llamada capitán
  };
  /* ---------------- sonidos propios (carpeta "sonidos" del PC) */
  let files = [];
  const fileFor = (name) => files.find((f) => f.replace(/\.\w+$/, '').toLowerCase() === name.toLowerCase());
  function playFile(f, vol = 1) {
    return new Promise((res) => {
      const a = new Audio('/sonidos/' + encodeURIComponent(f)); a.volume = Math.min(1, S.volume * vol);
      a.onended = a.onerror = () => res(); a.play().catch(() => res());
      playFile.current = a;
    });
  }
  async function loadFiles() {
    try { files = serverOk ? await (await fetch('/api/sounds')).json() : []; } catch (e) { files = []; }
  }

  const chime = (k) => {
    const f = fileFor('campana_' + ({ single: '1', double: '2', triple: '3' }[k]));
    if (f) return playFile(f);
    return new Promise((res) => { try { CHIMES[k](); } catch (e) { /* sin audio */ } setTimeout(res, k === 'triple' ? 2200 : k === 'double' ? 1900 : 1200); });
  };

  /* ---------------- ambiente de cabina (motores, aire, APU) */
  const amb = { on: false, nodes: null, file: null };
  function noiseBuffer(c) {
    const len = c.sampleRate * 4, b = c.createBuffer(2, len, c.sampleRate);
    for (let ch = 0; ch < 2; ch++) {           // ruido marrón: grave y "de cabina"
      const d = b.getChannelData(ch); let last = 0;
      for (let i = 0; i < len; i++) { last = (last + 0.02 * (Math.random() * 2 - 1)) / 1.02; d[i] = last * 3.5; }
    }
    return b;
  }
  function startAmbient() {
    if (amb.nodes || amb.file) return;
    const f = fileFor('cabina');
    if (f) { const a = new Audio('/sonidos/' + encodeURIComponent(f)); a.loop = true; a.volume = 0; a.play().catch(() => {}); amb.file = a; return; }
    const c = ac(), src = c.createBufferSource(); src.buffer = noiseBuffer(c); src.loop = true;
    const lp = c.createBiquadFilter(); lp.type = 'lowpass'; lp.frequency.value = 400; lp.Q.value = 0.5;
    const roar = c.createGain(); roar.gain.value = 0;
    // zumbido de los motores (N1) y silbido de turbina (N2)
    const fan = c.createOscillator(); fan.type = 'sawtooth'; fan.frequency.value = 90;
    const fanLp = c.createBiquadFilter(); fanLp.type = 'lowpass'; fanLp.frequency.value = 300;
    const fanG = c.createGain(); fanG.gain.value = 0;
    const whine = c.createOscillator(); whine.type = 'sine'; whine.frequency.value = 2400;
    const whineG = c.createGain(); whineG.gain.value = 0;
    // APU / aire acondicionado en puerta
    const apu = c.createOscillator(); apu.type = 'triangle'; apu.frequency.value = 410;
    const apuG = c.createGain(); apuG.gain.value = 0;
    const master = c.createGain(); master.gain.value = 0;
    src.connect(lp).connect(roar).connect(master);
    fan.connect(fanLp).connect(fanG).connect(master);
    whine.connect(whineG).connect(master); apu.connect(apuG).connect(master);
    // vibración de spoilers (aire turbulento sobre el ala)
    const sp = c.createBufferSource(); sp.buffer = src.buffer; sp.loop = true;
    const spF = c.createBiquadFilter(); spF.type = 'bandpass'; spF.frequency.value = 140; spF.Q.value = 0.8;
    const spoilerG = c.createGain(); spoilerG.gain.value = 0;
    sp.connect(spF).connect(spoilerG).connect(master);
    master.connect(c.destination);
    [src, fan, whine, apu, sp].forEach((n) => n.start());
    amb.nodes = { lp, roar, fan, fanG, whine, whineG, apuG, spoilerG, master };
  }
  function stopAmbient() {
    if (amb.nodes) { const t = ac().currentTime; amb.nodes.master.gain.setTargetAtTime(0, t, 0.3); const n = amb.nodes; amb.nodes = null; setTimeout(() => { try { n.master.disconnect(); } catch (e) { /* */ } }, 1500); }
    if (amb.file) { amb.file.pause(); amb.file = null; }
  }
  function ambientUpdate(d) {
    if (!S.ambient || !d) { if (amb.nodes || amb.file) stopAmbient(); return; }
    startAmbient();
    const spd = Math.min(1, (d.ias || 0) / 320);
    // empuje aproximado: alto en despegue y ascenso, medio en crucero, bajo en descenso/ralentí
    let thrust;
    if (typeof d.n1 === 'number' && d.n1 > 0) thrust = Math.max(0, Math.min(1, (d.n1 - 18) / 80));   // N1 real del avión
    else {
      thrust = d.eng ? 0.18 : 0;
      if (d.eng && !d.on_ground) thrust = d.vs > 500 ? 0.9 : d.vs < -500 ? 0.3 : 0.65;
      if (d.eng && d.on_ground && d.gs > 30) thrust = 1;
    }
    if (!d.eng) thrust = 0;
    const loud = S.ambVolume * (0.08 + 0.5 * spd + 0.35 * thrust);
    if (amb.file) { amb.file.volume = Math.min(1, loud * S.volume); return; }
    const n = amb.nodes, t = ac().currentTime, k = 0.6;
    n.master.gain.setTargetAtTime(S.volume * S.ambVolume * 0.9, t, k);
    n.roar.gain.setTargetAtTime(0.12 + 0.6 * spd + 0.25 * thrust, t, k);
    n.lp.frequency.setTargetAtTime(250 + 700 * spd + 300 * thrust, t, k);
    n.fan.frequency.setTargetAtTime(55 + 85 * thrust, t, k);
    n.fanG.gain.setTargetAtTime(d.eng ? 0.015 + 0.04 * thrust : 0, t, k);
    n.whine.frequency.setTargetAtTime(1800 + 1500 * thrust, t, k);
    n.whineG.gain.setTargetAtTime(d.eng ? 0.0025 + 0.004 * (d.on_ground ? 1 : 0.3) : 0, t, k);
    n.apuG.gain.setTargetAtTime((d.apu > 0.5 || (d.apu === undefined && d.on_ground && d.gs < 5)) ? 0.006 : 0, t, k);
    if (n.spoilerG) n.spoilerG.gain.setTargetAtTime(!d.on_ground && d.spoilers > 0.05 ? 0.25 * d.spoilers * spd : 0, t, 0.3);
  }

  /* ---------------- efectos del avión (tren, flaps, toque, spoilers) */
  function burst(dur, freq, q, gain, decay = true) {
    const c = ac(), src = c.createBufferSource();
    src.buffer = noiseBuffer(c);
    const f = c.createBiquadFilter(); f.type = 'bandpass'; f.frequency.value = freq; f.Q.value = q;
    const g = c.createGain(), t = c.currentTime;
    g.gain.setValueAtTime(0, t); g.gain.linearRampToValueAtTime(gain * S.volume * S.fxVolume, t + 0.02);
    if (decay) g.gain.exponentialRampToValueAtTime(0.0005, t + dur);
    else { g.gain.setValueAtTime(gain * S.volume * S.fxVolume, t + dur - 0.3); g.gain.linearRampToValueAtTime(0, t + dur); }
    src.connect(f).connect(g).connect(c.destination); src.start(t); src.stop(t + dur + 0.1);
  }
  function motor(dur, f0, f1, gain) {               // zumbido de motor hidráulico/eléctrico
    const c = ac(), o = c.createOscillator(), lp = c.createBiquadFilter(), g = c.createGain(), t = c.currentTime;
    o.type = 'sawtooth'; o.frequency.setValueAtTime(f0, t); o.frequency.linearRampToValueAtTime(f1, t + dur);
    lp.type = 'lowpass'; lp.frequency.value = 500;
    g.gain.setValueAtTime(0, t); g.gain.linearRampToValueAtTime(gain * S.volume * S.fxVolume, t + 0.4);
    g.gain.setValueAtTime(gain * S.volume * S.fxVolume, t + dur - 0.5); g.gain.linearRampToValueAtTime(0, t + dur);
    o.connect(lp).connect(g).connect(c.destination); o.start(t); o.stop(t + dur + 0.1);
  }
  const FX = {
    gearUp: () => { motor(7, 110, 150, 0.05); burst(9, 300, 0.6, 0.12, false); setTimeout(() => burst(0.35, 90, 1.2, 0.9), 7500); },
    gearDown: () => { motor(5, 120, 100, 0.05); setTimeout(() => burst(0.4, 80, 1.2, 1.0), 4200); setTimeout(() => burst(18, 380, 0.5, 0.08, false), 4500); },
    flaps: () => motor(4, 160, 175, 0.035),
    touchdown: (hard) => { burst(0.5, 70, 1.0, 0.6 + hard); burst(1.2, 900, 0.8, 0.12 + hard * 0.2); },
  };
  const playFx = (k, ...a) => { if (!S.fx) return; const f = fileFor('fx_' + k); if (f) playFile(f, S.fxVolume); else { try { FX[k](...a); } catch (e) { /* */ } } };
  let ac0 = null, vsAir = 0;
  function aircraftEvents(d) {
    if (!ac0) { ac0 = { ...d }; return; }
    if (d.gear !== undefined && d.gear !== ac0.gear && !d.on_ground) playFx(d.gear ? 'gearDown' : 'gearUp');
    if (d.flaps !== undefined && d.flaps !== ac0.flaps) playFx('flaps');
    if (!d.on_ground) vsAir = d.vs;
    if (d.on_ground && !ac0.on_ground) playFx('touchdown', Math.min(1, Math.abs(Math.min(0, vsAir)) / 600));
    // anuncios ligados a lo que haces en cabina
    if (S.auto && d.on_ground) {
      if (ac0.door > 0.5 && d.door < 0.1) once('doors');                  // cierras las puertas
      if (!ac0.beacon && d.beacon) setTimeout(() => once('safety'), 2500); // enciendes la beacon (pushback)
      if (st.airborneOnce && ac0.beacon && !d.beacon) once('disarm');      // apagas la beacon en destino
    }
    ac0 = { ...d };
  }

  /* ---------------- voz */
  const voices = () => (window.speechSynthesis ? speechSynthesis.getVoices() : []);
  function pickVoice(lang) {
    const want = lang === 'es' ? S.voiceEs : S.voiceEn;
    const vs = voices();
    return vs.find((v) => v.name === want) || vs.find((v) => v.lang.toLowerCase().startsWith(lang === 'es' ? 'es-es' : 'en-gb'))
      || vs.find((v) => v.lang.toLowerCase().startsWith(lang));
  }
  function say(text, lang) {
    return new Promise((res) => {
      if (!window.speechSynthesis) return res();
      const u = new SpeechSynthesisUtterance(text);
      const v = pickVoice(lang); if (v) u.voice = v;
      u.lang = lang === 'es' ? 'es-ES' : 'en-GB';
      u.rate = S.rate; u.volume = S.volume; u.pitch = 1;
      u.onend = u.onerror = () => res();
      speechSynthesis.speak(u);
    });
  }

  /* ---------------- textos */
  const destName = () => (plan.arr ? (plan.arr.name || plan.arr.code).split('-')[0].trim() : 'nuestro destino');
  const depName = () => (plan.dep ? (plan.dep.name || plan.dep.code).split('-')[0].trim() : '');
  const mins = (h) => Math.max(1, Math.round(h * 60));
  function timeLeftEs() {
    const r = computeRoute(), p = progress(r, live);
    if (!p || !live || live.gs < 60) return '';
    const m = mins(p.remaining / live.gs);
    return m >= 60 ? `${Math.floor(m / 60)} hora${m >= 120 ? 's' : ''} y ${m % 60} minutos` : `${m} minutos`;
  }
  function timeLeftEn() {
    const r = computeRoute(), p = progress(r, live);
    if (!p || !live || live.gs < 60) return '';
    const m = mins(p.remaining / live.gs);
    return m >= 60 ? `${Math.floor(m / 60)} hour${m >= 120 ? 's' : ''} and ${m % 60} minutes` : `${m} minutes`;
  }
  const altEs = () => (live ? `${Math.round(live.alt / 1000) * 1000} pies` : '');
  const altEn = () => (live ? `${Math.round(live.alt / 1000) * 1000} feet` : '');

  const ANN = {
    welcome: { label: 'Bienvenida a bordo', chime: 'double',
      es: () => `Señoras y señores, buenos días y bienvenidos a bordo del vuelo ${S.flightNo} de ${S.airline} con destino ${destName()}. Por favor, coloquen su equipaje de mano en los compartimentos superiores o debajo del asiento delantero, y tomen asiento lo antes posible. Gracias.`,
      en: () => `Ladies and gentlemen, good morning and welcome aboard ${S.airline} flight ${S.flightNo} to ${destName()}. Please stow your hand luggage in the overhead bins or under the seat in front of you, and take your seat as soon as possible. Thank you.` },
    doors: { label: 'Puertas en automático', chime: 'double',
      es: () => 'Tripulación de cabina, puertas en automático y comprobación cruzada.',
      en: () => 'Cabin crew, arm doors and cross check.' },
    safety: { label: 'Demostración de seguridad', chime: 'double',
      es: () => 'Señoras y señores, les rogamos su atención para la demostración de seguridad. Abróchense el cinturón introduciendo la parte metálica en la hebilla. Este avión dispone de salidas de emergencia a ambos lados, iluminadas en el suelo. En caso de despresurización caerán máscaras de oxígeno; colóquense la suya antes de ayudar a otras personas. El chaleco salvavidas está debajo de su asiento. Les recordamos que está prohibido fumar durante todo el vuelo. Gracias por su atención.',
      en: () => 'Ladies and gentlemen, may we have your attention for the safety demonstration. Fasten your seatbelt by inserting the metal tip into the buckle. There are emergency exits on both sides of the aircraft, with floor lighting to guide you. In case of decompression, oxygen masks will drop; put on your own mask before helping others. Your life jacket is under your seat. Smoking is not permitted at any time. Thank you for your attention.' },
    takeoff: { label: 'Asientos para el despegue', chime: 'double',
      es: () => 'Tripulación de cabina, asientos para el despegue.',
      en: () => 'Cabin crew, seats for take off.' },
    beltOff: { label: 'Cinturones: pueden desabrocharse', chime: 'single',
      es: () => `Señoras y señores, el comandante ha apagado la señal de cinturones. Pueden moverse por la cabina, aunque les recomendamos mantenerlo abrochado mientras estén sentados. En breve comenzará nuestro servicio a bordo.`,
      en: () => `Ladies and gentlemen, the captain has turned off the seatbelt sign. You may now move around the cabin, but we recommend keeping your seatbelt fastened while seated. Our onboard service will begin shortly.` },
    cruise: { label: 'Comandante en crucero', chime: 'triple',
      es: () => `Buenos días, les habla su comandante ${S.captain}. Hemos alcanzado nuestra altitud de crucero de ${altEs()}${timeLeftEs() ? `, y nos quedan aproximadamente ${timeLeftEs()} hasta ${destName()}` : ''}. Relájense y disfruten del vuelo. Muchas gracias por volar con ${S.airline}.`,
      en: () => `Good morning, this is your captain ${S.captain} speaking. We have reached our cruising altitude of ${altEn()}${timeLeftEn() ? `, and we have about ${timeLeftEn()} to go to ${destName()}` : ''}. Sit back, relax and enjoy the flight. Thank you for flying ${S.airline}.` },
    turbulence: { label: 'Turbulencias', chime: 'single',
      es: () => 'Señoras y señores, estamos atravesando una zona de turbulencias. Por favor, regresen a sus asientos y abróchense el cinturón. Tripulación, sentarse.',
      en: () => 'Ladies and gentlemen, we are experiencing some turbulence. Please return to your seats and fasten your seatbelts. Cabin crew, please be seated.' },
    descent: { label: 'Inicio del descenso', chime: 'triple',
      es: () => `Señoras y señores, les habla de nuevo el comandante. Hemos iniciado el descenso hacia ${destName()}${timeLeftEs() ? `, donde aterrizaremos en unos ${timeLeftEs()}` : ''}. Por favor, vuelvan a sus asientos, abróchense el cinturón, pongan el respaldo en posición vertical y recojan la mesita.`,
      en: () => `Ladies and gentlemen, this is the captain again. We have started our descent into ${destName()}${timeLeftEn() ? `, where we expect to land in about ${timeLeftEn()}` : ''}. Please return to your seats, fasten your seatbelts, bring your seat backs upright and stow your tray tables.` },
    landing: { label: 'Asientos para el aterrizaje', chime: 'double',
      es: () => 'Tripulación de cabina, asientos para el aterrizaje.',
      en: () => 'Cabin crew, seats for landing.' },
    arrived: { label: 'Bienvenidos a destino', chime: 'double',
      es: () => `Señoras y señores, bienvenidos a ${destName()}. Por favor, permanezcan sentados con el cinturón abrochado hasta que el avión se detenga por completo y se apague la señal de cinturones. Tengan cuidado al abrir los compartimentos superiores. En nombre de ${S.airline} y de toda la tripulación, gracias por volar con nosotros.`,
      en: () => `Ladies and gentlemen, welcome to ${destName()}. Please remain seated with your seatbelt fastened until the aircraft has come to a complete stop and the seatbelt sign has been switched off. Take care when opening the overhead bins. On behalf of ${S.airline} and the entire crew, thank you for flying with us.` },
    disarm: { label: 'Desarmar puertas', chime: 'double',
      es: () => 'Tripulación de cabina, desarmar puertas y comprobación cruzada.',
      en: () => 'Cabin crew, disarm doors and cross check.' },
  };

  /* ---------------- cola de reproducción */
  const queue = []; let playing = false;
  async function pump() {
    if (playing || !queue.length) return;
    playing = true;
    const { key, chimeOnly } = queue.shift();
    const a = ANN[key];
    if (a) {
      setNow(a.label);
      const own = !chimeOnly && (fileFor(key + '_' + (S.lang === 'en' ? 'en' : 'es')) || fileFor(key));
      if (a.chime) await chime(a.chime);
      if (own) await playFile(own);
      else if (!chimeOnly) {
        if (S.lang === 'es' || S.lang === 'both') await say(a.es(), 'es');
        if (S.lang === 'en' || S.lang === 'both') await say(a.en(), 'en');
      }
      setNow(null);
    }
    playing = false; pump();
  }
  function play(key) { post('/api/sound/play', { key }); }
  function stop() { post('/api/sound/stop'); }

  /* ---------------- detección de fases */
  let st = null;
  const fresh = () => ({ done: {}, phase: 'gate', taxiSince: 0, levelSince: 0, maxAlt: 0, vsHist: [], lastTurb: 0, belt: null, airborneOnce: false });
  function reset() { st = fresh(); renderPhase(); if (serverOk) post('/api/sound/reset'); }
  reset();
  const once = (k) => { if (st.done[k]) return; st.done[k] = true; play(k); };

  // Las fases, anuncios, campanas y efectos los hace el SERVIDOR con el avión (suenan aunque cierres la ventana).
  // Aquí solo queda el ambiente de cabina opcional y mostrar el estado.
  function update() { /* los sonidos los hace el servidor con el avión */ }
  window.onSoundStatus = (snd) => {
    if (!snd) return;
    const changed = snd.phase !== st.phase || (snd.done || []).length !== Object.keys(st.done).length;
    st.phase = snd.phase; st.done = Object.fromEntries((snd.done || []).map((k) => [k, true]));
    const lab = snd.now && ANN[snd.now] ? ANN[snd.now].label : null; setNow(lab);
    if (changed) renderPhase();
  };

  /* ---------------- interfaz */
  const PHASES = { gate: 'En puerta', taxi: 'Rodaje', takeoff: 'Despegue', climb: 'Ascenso', cruise: 'Crucero', descent: 'Descenso', approach: 'Aproximación', landed: 'En tierra (llegada)' };
  function setNow(t) { const el = $('#annNow'); if (el) el.textContent = t ? '🔊 ' + t : ''; }
  function renderPhase() {
    const el = $('#annPhase'); if (!el) return;
    el.innerHTML = `Fase detectada: <b>${PHASES[st.phase]}</b>`;
    document.querySelectorAll('[data-ann]').forEach((b) => b.classList.toggle('played', !!st.done[b.dataset.ann]));
  }
  function voiceOptions(lang, cur) {
    const vs = (srvVoices.length ? srvVoices : voices().map((v) => v.name)).map((n) => ({ name: n }));
    return '<option value="">Automática</option>' + vs.map((v) => `<option ${v.name === cur ? 'selected' : ''}>${esc(v.name)}</option>`).join('');
  }
  function renderPanel() {
    const box = $('#tab-ann'); if (!box) return;
    box.innerHTML = `<h2 class="ptitle">Sonidos</h2><p class="psub">Suenan con tu avión en MSFS, aunque cierres esta ventana. Sin el simulador abierto no suena nada.</p>
      <div class="msfs-banner ${liveMode === 'sim' ? 'on' : 'off'}">${liveMode === 'sim' ? '🟢 Conectado: los sonidos siguen a tu avión' : '🟠 Abre MSFS 2024 para que suenen los anuncios'}</div>
      <label class="check big"><input type="checkbox" id="annAuto" ${S.auto ? 'checked' : ''}> Anuncios automáticos según la fase del vuelo</label>
      <p class="hint" id="annPhase"></p><p class="ann-now" id="annNow"></p>
      <div class="row2">
        <label class="field">Aerolínea<input id="annAirline" value="${esc(S.airline)}"></label>
        <label class="field">Vuelo<input id="annFlight" value="${esc(S.flightNo)}"></label>
      </div>
      <div class="row2">
        <label class="field">Comandante<input id="annCaptain" value="${esc(S.captain)}"></label>
        <label class="field">Idioma<select id="annLang">
          <option value="es" ${S.lang === 'es' ? 'selected' : ''}>Español</option>
          <option value="en" ${S.lang === 'en' ? 'selected' : ''}>Inglés</option>
          <option value="both" ${S.lang === 'both' ? 'selected' : ''}>Español + inglés</option></select></label>
      </div>
      <label class="check big"><input type="checkbox" id="annNatural" ${S.natural !== false ? 'checked' : ''}> Voces naturales (azafata y comandante, suenan como personas reales)</label>
      <div class="row2" ${S.natural !== false ? 'style="display:none"' : ''}>
        <label class="field">Voz de Windows (español)<select id="annVoiceEs">${voiceOptions('es', S.voiceEs)}</select></label>
        <label class="field">Voz de Windows (inglés)<select id="annVoiceEn">${voiceOptions('en', S.voiceEn)}</select></label>
      </div>
      <label class="slider"><span><b>Volumen</b></span><input type="range" id="annVol" min="0" max="1" step="0.05" value="${S.volume}"><output>${Math.round(S.volume * 100)}%</output></label>
      <label class="slider"><span><b>Velocidad de voz</b></span><input type="range" id="annRate" min="0.7" max="1.3" step="0.05" value="${S.rate}"><output>${S.rate.toFixed(2)}</output></label>
      <label class="check"><input type="checkbox" id="annBelt" ${S.chimeOnBelt ? 'checked' : ''}> Campana real al cambiar la señal de cinturones del avión</label>

      <div class="section-head"><h3>Tus grabaciones reales</h3></div>
      <p class="hint">Pon archivos .mp3 o .wav en la carpeta <code>SimDirect\\sonidos</code> con estos nombres y sonarán en lugar de la voz o la campana generada: ${Object.keys(ANN).map((k) => `<code>${k}.mp3</code>`).join(' ')} · también <code>${'{nombre}'}_en.mp3</code> para inglés · campanas: <code>campana_1.mp3</code> <code>campana_2.mp3</code> <code>campana_3.mp3</code>.</p>
      <p class="hint">Encontrados: ${files.length ? files.map((f) => `<code>${esc(f)}</code>`).join(' ') : 'ninguno todavía'}. <button id="annRescan">↻ Buscar</button></p>

      <div class="section-head"><h3>Reproducir ahora</h3><button id="annStop">■ Parar</button></div>
      <div class="ann-grid">${Object.entries(ANN).map(([k, a]) => `<button data-ann="${k}">${a.label}</button>`).join('')}</div>
      <div class="section-head"><h3>Campanas</h3></div>
      <div class="toolbar"><button data-chime="single">Cinturones (1 tono)</button><button data-chime="double">Tripulación (2 tonos)</button><button data-chime="triple">Comandante (3 tonos)</button></div>
      <div class="toolbar"><button id="annReset">Reiniciar fases (nuevo vuelo)</button></div>
      <p class="hint">La voz usa las voces instaladas en Windows. Para más voces: Configuración de Windows → Hora e idioma → Voz → Agregar voces. En el móvil suena desde el móvil.</p>`;
    const bind = (id, key, conv = (v) => v) => { $(id).onchange = (e) => { S[key] = conv(e.target.type === 'checkbox' ? e.target.checked : e.target.value); save(); }; };
    bind('#annAuto', 'auto'); bind('#annAirline', 'airline'); bind('#annFlight', 'flightNo'); bind('#annCaptain', 'captain');
    bind('#annLang', 'lang'); bind('#annVoiceEs', 'voiceEs'); bind('#annVoiceEn', 'voiceEn'); bind('#annBelt', 'chimeOnBelt');
    $('#annVol').oninput = (e) => { S.volume = +e.target.value; e.target.nextElementSibling.textContent = Math.round(S.volume * 100) + '%'; save(); };
    $('#annRate').oninput = (e) => { S.rate = +e.target.value; e.target.nextElementSibling.textContent = S.rate.toFixed(2); save(); };
    box.querySelectorAll('[data-ann]').forEach((b) => b.onclick = () => play(b.dataset.ann));
    box.querySelectorAll('[data-chime]').forEach((b) => b.onclick = () => post('/api/sound/play', { chime: b.dataset.chime }));
    $('#annStop').onclick = stop;
    $('#annNatural').onchange = (e) => { S.natural = e.target.checked; save(); renderPanel(); };
    $('#annRescan').onclick = async () => { await loadFiles(); stopAmbient(); renderPanel(); };
    $('#annReset').onclick = () => { reset(); toast('Fases reiniciadas'); };
    renderPhase();
  }
  if (window.speechSynthesis) speechSynthesis.onvoiceschanged = () => { if ($('#tab-ann.active')) renderPanel(); };
  // el navegador solo deja sonar audio después de un toque/clic del usuario
  document.addEventListener('pointerdown', () => { try { ac().resume(); } catch (e) { /* */ } }, { once: true });

  return { update, play, stop, reset, renderPanel, loadFiles, loadServer };
})();
window.Announcer = Announcer;
Announcer.renderPanel();
document.querySelector('.tab[data-tab="ann"]').addEventListener('click', async () => { await Announcer.loadFiles(); await Announcer.loadServer(); Announcer.renderPanel(); });
setTimeout(() => Announcer.loadFiles(), 1500);
