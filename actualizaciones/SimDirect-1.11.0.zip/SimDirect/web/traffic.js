'use strict';
/* Jugadores online (VATSIM e IVAO) en el mapa, con botón para ver u ocultar */
const Traffic = (() => {
  const layer = L.layerGroup();
  let on = store('simdirect.traffic') === true, timer = null, nets = store('simdirect.trafficNets') || ['msfs', 'vatsim', 'ivao'];
  if (!nets.includes('msfs') && !store('simdirect.trafficMsfsAsked')) { nets.unshift('msfs'); store('simdirect.trafficMsfsAsked', true); }
  const COL = { msfs: '#ffb547', vatsim: '#3ddc84', ivao: '#4aa3ff' };
  const NAME = { msfs: 'MSFS', vatsim: 'VATSIM', ivao: 'IVAO' };
  const ico = (p) => L.divIcon({ className: 'tfc', iconSize: [22, 22], iconAnchor: [11, 11],
    html: `<svg viewBox="0 0 24 24" width="22" height="22" style="transform:rotate(${p.hdg || 0}deg)"><path fill="${COL[p.net]}" stroke="#04121c" stroke-width="1" d="M12 2c.8 0 1.3.9 1.3 2v5.2l7.7 4.6v2l-7.7-2.3v4.6l2.2 1.7v1.6L12 20.4l-3.5 1v-1.6l2.2-1.7v-4.6L3 15.8v-2l7.7-4.6V4c0-1.1.5-2 1.3-2z"/></svg>` });

  /* ---------- recorrido hecho al pasar el ratón (clic = dejarlo fijo) */
  const trackLayer = L.layerGroup();
  let hoverKey = null, pinned = null, trackReq = 0;
  const keyOf = (p) => p.net + ':' + (p.cs || '');
  /* curva entre dos puntos usando el rumbo de cada uno (Hermite): así se ven los giros */
  function curve(a, b) {
    const lat0 = (a[0] + b[0]) / 2, k = Math.cos(lat0 * Math.PI / 180);
    const ax = a[1] * k, ay = a[0], bx = b[1] * k, by = b[0];
    const dx = bx - ax, dy = by - ay, d = Math.hypot(dx, dy);
    if (d < 1e-7) return [[b[0], b[1]]];
    const dir = (h, fx, fy) => (h === null || h === undefined || !isFinite(h)) ? [fx, fy] : [Math.sin(h * Math.PI / 180), Math.cos(h * Math.PI / 180)];
    const chord = [dx / d, dy / d];
    let t0 = dir(a[4], ...chord), t1 = dir(b[4], ...chord);
    // si el rumbo apunta hacia atrás respecto al tramo (datos raros), no forzar un lazo
    if (t0[0] * chord[0] + t0[1] * chord[1] < -0.2) t0 = chord;
    if (t1[0] * chord[0] + t1[1] * chord[1] < -0.2) t1 = chord;
    const m = d * 1.0;
    const km = d * 111;
    const n = Math.max(2, Math.min(28, Math.round(km / 1.2)));
    const out = [];
    for (let i = 1; i <= n; i++) {
      const t = i / n, t2 = t * t, t3 = t2 * t;
      const h00 = 2 * t3 - 3 * t2 + 1, h10 = t3 - 2 * t2 + t, h01 = -2 * t3 + 3 * t2, h11 = t3 - t2;
      const x = h00 * ax + h10 * m * t0[0] + h01 * bx + h11 * m * t1[0];
      const y = h00 * ay + h10 * m * t0[1] + h01 * by + h11 * m * t1[1];
      out.push([y, x / k]);
    }
    return out;
  }
  async function showTrack(p) {
    const k = keyOf(p), req = ++trackReq;
    let t;
    try { t = await (await fetch(`/api/traffic/track?net=${encodeURIComponent(p.net)}&cs=${encodeURIComponent(p.cs || '')}`)).json(); } catch (e) { return; }
    if (req !== trackReq || (hoverKey !== k && (!pinned || keyOf(pinned) !== k))) return;
    trackLayer.clearLayers();
    const raw = (t.pts || []).slice();
    const nowPt = [p.lat, p.lon, p.alt || 0, t.now || Date.now() / 1000, p.hdg, p.gs];
    const lastR = raw[raw.length - 1];
    if (!lastR || Math.abs(lastR[0] - nowPt[0]) > 1e-4 || Math.abs(lastR[1] - nowPt[1]) > 1e-4) raw.push(nowPt);
    const col = COL[p.net];
    const solid = [[]], gaps = [];
    for (let i = 0; i < raw.length; i++) {
      if (i === 0) { solid[0].push([raw[0][0], raw[0][1]]); continue; }
      const a = raw[i - 1], b = raw[i];
      if (b[3] - a[3] > 150) {           // hueco sin datos: no sabemos por dónde fue
        gaps.push([[a[0], a[1]], [b[0], b[1]]]);
        solid.push([[b[0], b[1]]]);
      } else solid[solid.length - 1].push(...curve(a, b));
    }
    gaps.forEach((g) => L.polyline(g, { color: col, weight: 2, opacity: 0.45, dashArray: '4 7', interactive: false }).addTo(trackLayer));
    solid.filter((s) => s.length > 1).forEach((s) => {
      L.polyline(s, { color: '#04121c', weight: 6, opacity: 0.5, interactive: false, lineJoin: 'round' }).addTo(trackLayer);
      L.polyline(s, { color: col, weight: 3, opacity: 0.95, interactive: false, lineJoin: 'round' }).addTo(trackLayer);
    });
    if (raw.length > 1) {
      const mins = Math.max(1, Math.round(((t.now || Date.now() / 1000) - raw[0][3]) / 60));
      L.circleMarker([raw[0][0], raw[0][1]], { radius: 4, color: '#04121c', weight: 1.5, fillColor: col, fillOpacity: 1 })
        .bindTooltip(`Recorrido grabado desde hace ${mins >= 60 ? Math.floor(mins / 60) + ' h ' + (mins % 60) + ' min' : mins + ' min'}`, { direction: 'top' })
        .addTo(trackLayer);
    }
    if (t.dep) {
      L.circleMarker([t.dep.lat, t.dep.lon], { radius: 4, color: '#04121c', weight: 1.5, fillColor: col, fillOpacity: 0.8, interactive: false })
        .bindTooltip('Salida ' + esc(t.dep.code), { permanent: true, direction: 'left', className: 'tfc-apt' }).addTo(trackLayer);
    }
    trackLayer.addTo(map);
  }
  function hideTrack() { trackReq++; trackLayer.clearLayers(); }

  async function refresh() {
    if (!on || !serverOk || document.hidden) return;
    const b = map.getBounds().pad(0.2);
    try {
      const r = await (await fetch(`/api/traffic?nets=${nets.join(',')}&bbox=${b.getSouth()},${b.getWest()},${b.getNorth()},${b.getEast()}`)).json();
      layer.clearLayers();
      r.pilots.forEach((p) => {
        const m = L.marker([p.lat, p.lon], { icon: ico(p), zIndexOffset: 500 })
          .bindTooltip(`<b>${esc(p.cs || '')}</b> · ${NAME[p.net]}<br>${esc(p.ac || '')} ${p.dep ? esc(p.dep) + ' → ' + esc(p.arr || '?') : ''}<br>${Math.round(p.alt || 0).toLocaleString('es-ES')} ft · ${Math.round(p.gs || 0)} kt<br><small style="opacity:.7">Clic: dejar fija la línea del recorrido</small>`, { direction: 'top' })
          .addTo(layer);
        m.on('mouseover', () => { hoverKey = keyOf(p); showTrack(p); });
        m.on('mouseout', () => { hoverKey = null; if (pinned) showTrack(pinned); else hideTrack(); });
        m.on('click', () => {
          if (pinned && keyOf(pinned) === keyOf(p)) { pinned = null; hideTrack(); toast('Recorrido quitado'); }
          else { pinned = p; showTrack(p); toast(`Recorrido de ${p.cs || 'este avión'} fijado (clic otra vez para quitarlo)`); }
        });
        if (pinned && keyOf(pinned) === keyOf(p)) pinned = p;
      });
      if (pinned && !hoverKey) {
        if (r.pilots.some((p) => keyOf(p) === keyOf(pinned))) showTrack(pinned); else { pinned = null; hideTrack(); }
      }
      btn.querySelector('small').textContent = r.count;
    } catch (e) { /* sin conexión */ }
  }
  const tellServer = () => { if (serverOk) post('/api/traffic/on', { on, nets }).catch(() => {}); };
  function set(v) {
    on = v; store('simdirect.traffic', on); tellServer();
    btn.classList.toggle('on', on);
    clearInterval(timer);
    if (on) { layer.addTo(map); refresh(); timer = setInterval(refresh, 8000); }
    else { map.removeLayer(layer); pinned = null; hideTrack(); btn.querySelector('small').textContent = ''; }
  }
  const Ctl = L.Control.extend({
    options: { position: 'bottomleft' },
    onAdd() {
      const d = L.DomUtil.create('div', 'tfc-ctl');
      d.innerHTML = `<button class="map-btn" id="tfcBtn">👥 Jugadores online <small></small></button>
        <div class="tfc-nets"><label><input type="checkbox" data-net="msfs" ${nets.includes('msfs') ? 'checked' : ''}> <b style="color:#ffb547">MSFS</b></label><label><input type="checkbox" data-net="vatsim" ${nets.includes('vatsim') ? 'checked' : ''}> VATSIM</label>
        <label><input type="checkbox" data-net="ivao" ${nets.includes('ivao') ? 'checked' : ''}> IVAO</label></div>`;
      L.DomEvent.disableClickPropagation(d); L.DomEvent.disableScrollPropagation(d);
      return d;
    },
  });
  map.addControl(new Ctl());
  const btn = document.getElementById('tfcBtn');
  btn.onclick = () => set(!on);
  document.querySelectorAll('.tfc-nets input').forEach((c) => c.onchange = () => {
    nets = [...document.querySelectorAll('.tfc-nets input:checked')].map((x) => x.dataset.net);
    store('simdirect.trafficNets', nets); tellServer(); refresh();
  });
  map.on('moveend', () => { clearTimeout(refresh.t); refresh.t = setTimeout(refresh, 500); });
  setTimeout(() => set(on), 1500);
  setInterval(() => { if (on) tellServer(); }, 60000);
  return { set };
})();
