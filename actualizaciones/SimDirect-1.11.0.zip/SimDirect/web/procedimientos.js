'use strict';
/* Cualquier aeropuerto del mundo, pistas, SID/STAR/aproximaciones reales (de MSFS) y mapa del aeropuerto */

const Proc = (() => {
  const cache = {};
  const layer = L.layerGroup().addTo(map);
  let shown = null, openedGround = false;
  if (!plan.proc) plan.proc = {};

  async function getAirport(code, force) {
    code = (code || '').toUpperCase().trim();
    if (!code || !serverOk) return null;
    if (cache[code] && !force && (cache[code].source === 'msfs' || liveMode !== 'sim')) return cache[code];
    try {
      const r = await (await fetch('/api/airport/' + encodeURIComponent(code))).json();
      if (r.ok) { cache[code] = r; return r; }
    } catch (e) { /* sin servidor */ }
    return null;
  }

  /* ---------- cualquier aeropuerto: completa el buscador y la lista */
  let searchT = null;
  ['#depCode', '#arrCode'].forEach((sel) => $(sel).addEventListener('input', (e) => {
    clearTimeout(searchT);
    const q = e.target.value.trim(); if (q.length < 2 || !serverOk) return;
    searchT = setTimeout(async () => {
      try {
        const res = await (await fetch('/api/airports/search?q=' + encodeURIComponent(q))).json();
        $('#aptList').innerHTML = res.map((a) => `<option value="${esc(a.code)}">${esc(a.name)}${a.city ? ' · ' + esc(a.city) : ''}</option>`).join('');
      } catch (err) { /* */ }
    }, 220);
  }));
  // sustituye la búsqueda de aeropuertos: primero la base mundial, si no, colocar a mano
  window.setAirport = async function (which) {
    const code = $('#' + which + 'Code').value.toUpperCase().trim();
    if (!code) { plan[which] = null; render(); return; }
    let a = apt(code);
    const info = await getAirport(code);
    if (info) a = { code, name: info.name || code, lat: info.lat, lon: info.lon, elev: info.elev || 0 };
    if (a) {
      plan[which] = a; plan.proc = plan.proc || {};
      if (which === 'dep') { plan.proc.depRwy = plan.proc.sid = plan.proc.sidTrans = ''; } else { plan.proc.arrRwy = plan.proc.star = plan.proc.starTrans = plan.proc.appr = ''; }
      fillForm(); render(); renderBox(); showAirport(code);
      return;
    }
    startPlacing(which, code);
  };
  $('#depCode').onchange = () => window.setAirport('dep');
  $('#arrCode').onchange = () => window.setAirport('arr');

  /* ---------- mapa del aeropuerto */
  function rwyEnds(r) {
    if (r.le && r.he) return [r.le, r.he];
    const L2 = (r.length_m || 2000) / 2, h = (r.heading || 0) * Math.PI / 180, k = Math.cos(r.lat * Math.PI / 180);
    const dLat = Math.cos(h) * L2 / 110540, dLon = Math.sin(h) * L2 / (111320 * k);
    return [[r.lat - dLat, r.lon - dLon], [r.lat + dLat, r.lon + dLon]];
  }
  async function showAirport(code) {
    const info = await getAirport(code); if (!info) { toast('No encuentro ' + code); return; }
    shown = code; layer.clearLayers();
    const sel = [plan.proc.depRwy, plan.proc.arrRwy].filter(Boolean);
    const pts = [];
    info.runways.forEach((r) => {
      const [a, b] = rwyEnds(r); pts.push(a, b);
      const w = Math.max(4, Math.min(14, (r.width_m || 45) / 6));
      L.polyline([a, b], { color: '#e9eef3', weight: w + 4, opacity: .55, interactive: false }).addTo(layer);
      L.polyline([a, b], { color: '#31363d', weight: w, opacity: .95, interactive: false }).addTo(layer);
      L.polyline([a, b], { color: '#fff', weight: 1, dashArray: '10 12', opacity: .8, interactive: false }).addTo(layer);
      [[a, r.ends[0]], [b, r.ends[1]]].forEach(([p, n]) => n && L.marker(p, { interactive: false,
        icon: L.divIcon({ className: '', iconSize: [0, 0], html: `<span class="rwy-label ${sel.includes(n) ? 'sel' : ''}">${esc(n)}</span>` }) }).addTo(layer));
    });
    const sat = baseLayers['Google satélite'] || baseLayers['Satélite + nombres'];
    if (sat && !map.hasLayer(sat)) { Object.values(baseLayers).forEach((l) => map.hasLayer(l) && map.removeLayer(l)); sat.addTo(map); }
    if (pts.length) map.fitBounds(L.latLngBounds(pts).pad(0.25), { maxZoom: 16 }); else map.setView([info.lat, info.lon], 14);
    airportCtl.show(info);
  }
  const AirportCtl = L.Control.extend({
    options: { position: 'topright' },
    onAdd() { const d = L.DomUtil.create('div', 'airport-ctl hidden'); L.DomEvent.disableClickPropagation(d); this.d = d; return d; },
    show(info) {
      this.d.classList.remove('hidden');
      this.d.innerHTML = `🛬 <b>${esc(info.code)}</b> ${esc(info.name || '')}<br><small>${info.runways.length} pista${info.runways.length === 1 ? '' : 's'} · ${esc(String(info.elev || 0))} ft${info.source === 'msfs' ? ' · datos de MSFS' : ''}</small><br><button id="aptBack" style="margin-top:6px">← Volver a la ruta</button>`;
      this.d.querySelector('#aptBack').onclick = () => { layer.clearLayers(); shown = null; this.d.classList.add('hidden'); fitRoute(); };
    },
  });
  const airportCtl = new AirportCtl(); map.addControl(airportCtl);

  /* ---------- procedimientos en el plan */
  function opts(list, cur, empty) {
    return `<option value="">${empty}</option>` + list.map((v) => `<option ${v === cur ? 'selected' : ''}>${esc(v)}</option>`).join('');
  }
  async function renderBox() {
    const box = $('#procBox'); if (!box) return;
    plan.proc = plan.proc || {};
    const P = plan.proc;
    const [dep, arr] = await Promise.all([plan.dep ? getAirport(plan.dep.code) : null, plan.arr ? getAirport(plan.arr.code) : null]);
    const rw = (info) => (info ? [...new Set(info.runways.flatMap((r) => r.ends).filter(Boolean))].sort() : []);
    const sids = dep ? dep.sids.filter((x) => !P.depRwy || !x.runways.length || x.runways.includes(P.depRwy)) : [];
    const stars = arr ? arr.stars.filter((x) => !P.arrRwy || !x.runways.length || x.runways.includes(P.arrRwy)) : [];
    const apprs = arr ? arr.approaches.filter((x) => !P.arrRwy || x.runway === P.arrRwy) : [];
    const sidObj = dep && dep.sids.find((x) => x.name === P.sid), starObj = arr && arr.stars.find((x) => x.name === P.star);
    const noNav = (info) => info && info.source !== 'msfs' ? `<p class="hint">${liveMode === 'sim' ? 'Cargando SID/STAR de MSFS…' : 'Las SID/STAR reales se cargan de MSFS 2024: ábrelo y entra en un vuelo.'}</p>` : '';
    box.innerHTML = `
      <div class="proc"><h4>🛫 Salida ${plan.dep ? esc(plan.dep.code) : ''} ${plan.dep ? '<button data-apt="dep">🗺 Ver aeropuerto</button>' : ''}</h4>
        ${plan.dep ? `<div class="row3">
          <label>Pista<select data-p="depRwy">${opts(rw(dep), P.depRwy, '—')}</select></label>
          <label>SID<select data-p="sid" ${sids.length ? '' : 'disabled'}>${opts(sids.map((x) => x.name), P.sid, sids.length ? 'Ninguna' : '—')}</select></label>
          <label>Transición<select data-p="sidTrans" ${sidObj && sidObj.transitions.length ? '' : 'disabled'}>${opts(sidObj ? sidObj.transitions : [], P.sidTrans, '—')}</select></label>
        </div>${noNav(dep)}` : '<p class="hint">Elige el aeropuerto de salida.</p>'}</div>
      <div class="proc"><h4>🛬 Llegada ${plan.arr ? esc(plan.arr.code) : ''} ${plan.arr ? '<button data-apt="arr">🗺 Ver aeropuerto</button>' : ''}</h4>
        ${plan.arr ? `<div class="row3">
          <label>STAR<select data-p="star" ${stars.length ? '' : 'disabled'}>${opts(stars.map((x) => x.name), P.star, stars.length ? 'Ninguna' : '—')}</select></label>
          <label>Aproximación<select data-p="appr" ${apprs.length ? '' : 'disabled'}>${opts(apprs.map((x) => x.name + ' ' + x.runway), P.appr, apprs.length ? 'Ninguna' : '—')}</select></label>
          <label>Pista<select data-p="arrRwy">${opts(rw(arr), P.arrRwy, '—')}</select></label>
        </div>${starObj && starObj.transitions.length ? `<label style="margin-top:6px">Transición STAR<select data-p="starTrans">${opts(starObj.transitions, P.starTrans, '—')}</select></label>` : ''}${noNav(arr)}` : '<p class="hint">Elige el aeropuerto de llegada.</p>'}</div>`;
    box.querySelectorAll('[data-p]').forEach((s) => s.onchange = () => {
      P[s.dataset.p] = s.value;
      if (s.dataset.p === 'appr' && s.value) P.arrRwy = s.value.split(' ').pop();
      if (s.dataset.p === 'depRwy') { P.sid = P.sidTrans = ''; }
      if (s.dataset.p === 'arrRwy') { P.star = P.starTrans = P.appr = ''; }
      store('simdirect.draft', plan); renderBox();
      if (shown) showAirport(shown);
    });
    box.querySelectorAll('[data-apt]').forEach((b) => b.onclick = () => showAirport(plan[b.dataset.apt].code));
  }

  /* ---------- al conectar en tierra: abrir el mapa del aeropuerto donde estás */
  async function onData(d) {
    if (!d || openedGround || !d.on_ground || !serverOk) return;
    openedGround = true;
    if (document.querySelector('#tab-push.active')) return;
    // aeropuerto más cercano: salida del plan si estás cerca, si no, el más cercano de la lista
    let code = null;
    if (plan.dep && distNm(plan.dep, d) < 5) code = plan.dep.code;
    if (!code) {
      let best = 99;
      Object.entries(AIRPORTS).forEach(([c, a]) => { const x = distNm(a, d); if (x < best) { best = x; code = c; } });
      if (best > 5) code = null;
    }
    if (code) { showAirport(code); toast('Estás en ' + code + ': mapa del aeropuerto abierto', 3500); }
    else map.setView([d.lat, d.lon], 15);
    if (plan.dep) { delete cache[plan.dep.code]; renderBox(); }
  }

  // refrescar procedimientos al conectar con MSFS
  let wasSim = false;
  setInterval(() => { const s = liveMode === 'sim'; if (s && !wasSim) { Object.keys(cache).forEach((k) => { if (cache[k].source !== 'msfs') delete cache[k]; }); renderBox(); } wasSim = s; }, 3000);
  setTimeout(renderBox, 1500);
  return { onData, showAirport, renderBox, getAirport };
})();
window.Proc = Proc;
