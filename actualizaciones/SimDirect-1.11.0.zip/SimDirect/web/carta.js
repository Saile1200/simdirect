'use strict';
/* Carta aeronáutica de SimDirect: relieve oscuro con tono de carta, cuadrícula, aeropuertos con su
   símbolo y pistas, y radioayudas (VOR, NDB, DME) con frecuencia. Los datos salen de la base libre
   que SimDirect ya descarga (OurAirports) a través de /api/chart. */
(() => {
  const C = {
    grid: 'rgba(120,175,230,.16)', gridTxt: 'rgba(150,195,240,.55)',
    big: '#3aa6ff', small: '#c97bff', soft: '#9fb7cc', rwy: '#cfe6ff', rwyEdge: '#0b2238',
    vor: '#57c7ff', ndb: '#d08cff', dme: '#57c7ff', halo: 'rgba(5,14,24,.85)',
  };

  const ChartOverlay = L.Layer.extend({
    onAdd(map) {
      this._map = map;
      if (!map.getPane('chartPane')) { const p = map.createPane('chartPane'); p.style.zIndex = 350; p.style.pointerEvents = 'none'; }
      this._cv = L.DomUtil.create('canvas', 'chart-canvas', map.getPane('chartPane'));
      this._tip = L.DomUtil.create('div', 'chart-tip', map.getContainer());
      this._tip.hidden = true;
      this._data = { airports: [], navaids: [] };
      this._hits = [];
      map.on('moveend zoomend resize', this._update, this);
      map.on('zoomstart', this._hide, this);
      map.on('mousemove', this._hover, this);
      map.on('mouseout', this._out, this);
      this._update();
    },
    onRemove(map) {
      map.off('moveend zoomend resize', this._update, this);
      map.off('zoomstart', this._hide, this);
      map.off('mousemove', this._hover, this);
      map.off('mouseout', this._out, this);
      this._cv.remove(); this._tip.remove();
    },
    _hide() { this._cv.style.opacity = 0; this._tip.hidden = true; },
    _update() {
      clearTimeout(this._t);
      this._draw();
      this._t = setTimeout(() => this._fetch(), 150);
    },
    async _fetch() {
      const m = this._map; if (!m) return;
      const b = m.getBounds().pad(0.25), z = Math.round(m.getZoom());
      const q = `bbox=${b.getSouth().toFixed(3)},${b.getWest().toFixed(3)},${b.getNorth().toFixed(3)},${b.getEast().toFixed(3)}&z=${z}`;
      if (q === this._q) return;
      try {
        const r = await fetch('/api/chart?' + q);
        if (!r.ok) return;
        this._data = await r.json(); this._q = q;
        this._draw();
      } catch (e) { /* sin servidor: solo la cuadrícula */ }
    },
    _draw() {
      const m = this._map; if (!m) return;
      const size = m.getSize(), dpr = Math.min(2, window.devicePixelRatio || 1), cv = this._cv;
      cv.width = size.x * dpr; cv.height = size.y * dpr; cv.style.width = size.x + 'px'; cv.style.height = size.y + 'px';
      L.DomUtil.setPosition(cv, m.containerPointToLayerPoint([0, 0]));
      cv.style.opacity = 1;
      const ctx = cv.getContext('2d'); ctx.setTransform(dpr, 0, 0, dpr, 0, 0); ctx.clearRect(0, 0, size.x, size.y);
      const z = m.getZoom(), P = (lat, lon) => m.latLngToContainerPoint([lat, lon]);
      this._hits = []; const boxes = [];
      const free = (x, y, w, h) => { if (boxes.some((r) => x < r[0] + r[2] && x + w > r[0] && y < r[1] + r[3] && y + h > r[1])) return false; boxes.push([x, y, w, h]); return true; };

      /* cuadrícula de latitud y longitud */
      const step = z >= 9 ? 0.5 : z >= 6 ? 1 : z >= 4 ? 5 : 10;
      const bb = m.getBounds();
      ctx.lineWidth = 1; ctx.strokeStyle = C.grid; ctx.fillStyle = C.gridTxt; ctx.font = '600 10px ui-monospace, Consolas, monospace';
      for (let la = Math.ceil(bb.getSouth() / step) * step; la <= bb.getNorth(); la += step) {
        const y = Math.round(P(la, bb.getWest()).y) + 0.5; ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(size.x, y); ctx.stroke();
        ctx.fillText(`${Math.abs(la).toFixed(step < 1 ? 1 : 0)}°${la >= 0 ? 'N' : 'S'}`, 6, y - 3);
      }
      for (let lo = Math.ceil(bb.getWest() / step) * step; lo <= bb.getEast(); lo += step) {
        const x = Math.round(P(bb.getNorth(), lo).x) + 0.5; ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x, size.y); ctx.stroke();
        ctx.fillText(`${Math.abs(lo).toFixed(step < 1 ? 1 : 0)}°${lo >= 0 ? 'E' : 'W'}`, x + 3, size.y - 6);
      }

      const label = (x, y, lines, col, bold) => {
        ctx.font = `${bold ? 700 : 600} 11px ui-monospace, Consolas, monospace`;
        const w = Math.max(...lines.map((l, i) => { ctx.font = `${i === 0 && bold ? 700 : 600} ${i === 0 ? 11 : 10}px ui-monospace, Consolas, monospace`; return ctx.measureText(l).width; })) + 8;
        const h = lines.length * 12 + 4;
        if (!free(x, y - h / 2, w, h)) return false;
        ctx.fillStyle = C.halo; ctx.strokeStyle = col; ctx.lineWidth = 1;
        ctx.beginPath(); ctx.roundRect ? ctx.roundRect(x, y - h / 2, w, h, 3) : ctx.rect(x, y - h / 2, w, h); ctx.fill(); ctx.globalAlpha = .55; ctx.stroke(); ctx.globalAlpha = 1;
        lines.forEach((l, i) => { ctx.font = `${i === 0 && bold ? 700 : 600} ${i === 0 ? 11 : 10}px ui-monospace, Consolas, monospace`; ctx.fillStyle = i === 0 ? col : 'rgba(210,228,245,.8)'; ctx.fillText(l, x + 4, y - h / 2 + 12 + i * 12); });
        return true;
      };

      /* radioayudas */
      const navs = this._data.navaids || [];
      navs.forEach((v) => {
        const p = P(v.lat, v.lon); if (p.x < -60 || p.y < -60 || p.x > size.x + 60 || p.y > size.y + 60) return;
        const isVor = v.t.startsWith('VOR') || v.t === 'TACAN', isNdb = v.t.startsWith('NDB');
        const col = isNdb ? C.ndb : C.vor;
        ctx.save(); ctx.translate(p.x, p.y);
        if (isVor && z >= 9) {        // rosa de los vientos
          const R = z >= 11 ? 70 : z >= 10 ? 56 : 42;
          ctx.strokeStyle = 'rgba(87,199,255,.38)'; ctx.lineWidth = 1;
          ctx.beginPath(); ctx.arc(0, 0, R, 0, 7); ctx.stroke();
          for (let a = 0; a < 360; a += 10) {
            const r0 = a % 90 === 0 ? R - 12 : a % 30 === 0 ? R - 8 : R - 4;
            const s = Math.sin(a * Math.PI / 180), c = -Math.cos(a * Math.PI / 180);
            ctx.beginPath(); ctx.moveTo(s * r0, c * r0); ctx.lineTo(s * R, c * R); ctx.stroke();
          }
          ctx.fillStyle = 'rgba(87,199,255,.75)'; ctx.font = '700 9px ui-monospace, Consolas, monospace'; ctx.textAlign = 'center';
          ctx.fillText('N', 0, -R - 3); ctx.textAlign = 'left';
        }
        ctx.strokeStyle = col; ctx.fillStyle = col; ctx.lineWidth = 1.8;
        if (isVor) {
          const r = 7;
          ctx.beginPath(); for (let i = 0; i < 6; i++) { const a = Math.PI / 3 * i; ctx[i ? 'lineTo' : 'moveTo'](Math.cos(a) * r, Math.sin(a) * r); } ctx.closePath();
          ctx.fillStyle = C.halo; ctx.fill(); ctx.stroke();
          if (v.t === 'VOR-DME') { ctx.strokeRect(-r, -r * 0.87, r * 2, r * 1.74); }
          if (v.t === 'VORTAC' || v.t === 'TACAN') { ctx.fillStyle = col; [0, 2, 4].forEach((i) => { const a = Math.PI / 3 * i + Math.PI / 6; ctx.beginPath(); ctx.arc(Math.cos(a) * (r + 2), Math.sin(a) * (r + 2), 2.4, 0, 7); ctx.fill(); }); }
          ctx.fillStyle = col; ctx.beginPath(); ctx.arc(0, 0, 1.8, 0, 7); ctx.fill();
        } else if (isNdb) {
          ctx.fillStyle = col;
          for (let ring = 1; ring <= 2; ring++) { const rr = ring * 4 + 1, n = ring * 8; for (let i = 0; i < n; i++) { const a = i / n * Math.PI * 2; ctx.beginPath(); ctx.arc(Math.cos(a) * rr, Math.sin(a) * rr, 1, 0, 7); ctx.fill(); } }
          ctx.beginPath(); ctx.arc(0, 0, 2.2, 0, 7); ctx.fill();
        } else { ctx.fillStyle = C.halo; ctx.fillRect(-5, -5, 10, 10); ctx.strokeRect(-5, -5, 10, 10); ctx.fillStyle = col; ctx.beginPath(); ctx.arc(0, 0, 1.6, 0, 7); ctx.fill(); }
        ctx.restore();
        this._hits.push({ x: p.x, y: p.y, r: 10, html: `<b>${v.id}</b> · ${v.t}${v.f ? ' · ' + v.f + (isNdb ? ' kHz' : ' MHz') : ''}<br>${v.n}` });
        label(p.x + 11, p.y - 12, z >= 8 && v.f ? [v.id, v.f] : [v.id], col, true);
      });

      /* aeropuertos */
      const aps = this._data.airports || [];
      const sizeOf = (a) => (a.r === 0 ? 10 : a.r === 1 ? 8 : 6) * (z >= 9 ? 1.15 : 1);
      // primero las pistas reales (de cerca)
      if (z >= 10) aps.forEach((a) => {
        if (!a.rw) return;
        a.rw.forEach((r) => {
          const p1 = P(r[0], r[1]), p2 = P(r[2], r[3]);
          const w = Math.max(3, Math.min(14, (z - 9) * 2.6));
          ctx.lineCap = 'butt';
          ctx.strokeStyle = C.rwyEdge; ctx.lineWidth = w + 3; ctx.beginPath(); ctx.moveTo(p1.x, p1.y); ctx.lineTo(p2.x, p2.y); ctx.stroke();
          ctx.strokeStyle = a.h ? C.rwy : C.soft; ctx.lineWidth = w; ctx.beginPath(); ctx.moveTo(p1.x, p1.y); ctx.lineTo(p2.x, p2.y); ctx.stroke();
          if (a.h && w >= 6) { ctx.strokeStyle = 'rgba(11,34,56,.8)'; ctx.lineWidth = 1; ctx.setLineDash([6, 6]); ctx.beginPath(); ctx.moveTo(p1.x, p1.y); ctx.lineTo(p2.x, p2.y); ctx.stroke(); ctx.setLineDash([]); }
        });
      });
      aps.slice().reverse().forEach((a) => {
        const p = P(a.lat, a.lon); if (p.x < -40 || p.y < -40 || p.x > size.x + 40 || p.y > size.y + 40) return;
        const col = a.r <= 1 && a.h ? C.big : a.h ? C.small : C.soft, s = sizeOf(a);
        const showSymbol = !(z >= 10 && a.rw && a.rw.length);
        ctx.save(); ctx.translate(p.x, p.y);
        if (showSymbol) {
          if (a.r === 4) {                // helipuerto
            ctx.strokeStyle = col; ctx.lineWidth = 1.6; ctx.beginPath(); ctx.arc(0, 0, 6, 0, 7); ctx.stroke();
            ctx.fillStyle = col; ctx.font = '700 9px system-ui'; ctx.textAlign = 'center'; ctx.fillText('H', 0, 3); ctx.textAlign = 'left';
          } else if (a.h) {
            ctx.fillStyle = C.halo; ctx.beginPath(); ctx.arc(0, 0, s + 1.5, 0, 7); ctx.fill();
            ctx.strokeStyle = col; ctx.lineWidth = a.r === 0 ? 2.6 : 2.2; ctx.beginPath(); ctx.arc(0, 0, s, 0, 7); ctx.stroke();
            if (a.b !== null && a.b !== undefined) {
              ctx.rotate(a.b * Math.PI / 180); ctx.fillStyle = col;
              const L2 = s * 1.45; ctx.fillRect(-1.6, -L2, 3.2, L2 * 2);
              ctx.rotate(-a.b * Math.PI / 180);
            }
            if (a.r <= 1) { ctx.lineWidth = 2; for (let i = 0; i < 4; i++) { const ang = i * Math.PI / 2 + Math.PI / 4; ctx.beginPath(); ctx.moveTo(Math.cos(ang) * s, Math.sin(ang) * s); ctx.lineTo(Math.cos(ang) * (s + 4), Math.sin(ang) * (s + 4)); ctx.stroke(); } }
          } else {
            ctx.fillStyle = C.halo; ctx.beginPath(); ctx.arc(0, 0, s, 0, 7); ctx.fill();
            ctx.strokeStyle = col; ctx.lineWidth = 1.8; ctx.beginPath(); ctx.arc(0, 0, s, 0, 7); ctx.stroke();
            ctx.fillStyle = col; ctx.beginPath(); ctx.arc(0, 0, 1.8, 0, 7); ctx.fill();
          }
        }
        ctx.restore();
        const elev = `${a.e} ft`;
        this._hits.push({ x: p.x, y: p.y, r: s + 6, html: `<b>${a.c}</b> · ${a.n}<br>Elevación ${a.e} ft${a.l ? ' · pista más larga ' + a.l + ' m' : ''}` });
        const show = a.r === 0 || (a.r === 1 && z >= 7) || (a.r === 2 && z >= 10) || z >= 12;
        if (show) label(p.x + s + 6, p.y, z >= 8 ? [a.c, elev] : [a.c], col, a.r <= 1);
      });
    },
    _hover(e) {
      const p = e.containerPoint;
      let best = null, bd = 1e9;
      for (const h of this._hits) { const d = Math.hypot(h.x - p.x, h.y - p.y); if (d < h.r && d < bd) { best = h; bd = d; } }
      if (!best) { this._tip.hidden = true; return; }
      this._tip.innerHTML = best.html; this._tip.hidden = false;
      this._tip.style.left = (best.x + 14) + 'px'; this._tip.style.top = (best.y + 14) + 'px';
    },
    _out() { this._tip.hidden = true; },
  });

  window.makeChartLayer = () => {
    const opt = { maxZoom: 19, maxNativeZoom: 16 };
    return L.layerGroup([
      L.tileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/Canvas/World_Dark_Gray_Base/MapServer/tile/{z}/{y}/{x}', { ...opt, className: 'chart-base', attribution: '© Esri · OurAirports' }),
      L.tileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/Elevation/World_Hillshade_Dark/MapServer/tile/{z}/{y}/{x}', { maxZoom: 19, maxNativeZoom: 15, className: 'chart-relief' }),
      L.tileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/Canvas/World_Dark_Gray_Reference/MapServer/tile/{z}/{y}/{x}', { ...opt, className: 'chart-labels' }),
      new ChartOverlay(),
    ]);
  };
})();
