'use strict';
/* Diario de vuelos y nota del aterrizaje */
const Diario = (() => {
  const panel = document.getElementById('tab-diario');
  const layer = L.layerGroup().addTo(map);
  let data = null, open = null, lastLandingVer = null, lastSavedVer = null;
  const fmtH = (min) => `${Math.floor(min / 60)}h ${String(min % 60).padStart(2, '0')}m`;
  const colOf = (s) => s >= 9 ? '#3ddc84' : s >= 7.5 ? '#8be06a' : s >= 6 ? '#ffd24a' : s >= 4 ? '#ffb547' : '#ff5d5d';
  const ICON = { fpm: '↓', g: 'G', bank: '↻', crab: '⤢', zone: '⟷', center: '┃', bounce: '⤒' };

  function scoreRing(s, size = 64) {
    const c = colOf(s), p = Math.max(0, Math.min(1, s / 10)), r = size / 2 - 5, L2 = 2 * Math.PI * r;
    return `<svg class="ld-ring" width="${size}" height="${size}" viewBox="0 0 ${size} ${size}"><circle cx="${size / 2}" cy="${size / 2}" r="${r}" fill="none" stroke="#223140" stroke-width="6"/>
      <circle cx="${size / 2}" cy="${size / 2}" r="${r}" fill="none" stroke="${c}" stroke-width="6" stroke-linecap="round" stroke-dasharray="${L2 * p} ${L2}" transform="rotate(-90 ${size / 2} ${size / 2})"/>
      <text x="50%" y="54%" text-anchor="middle" dominant-baseline="middle" fill="${c}" font-size="${size * 0.3}" font-weight="800">${s.toFixed(1)}</text></svg>`;
  }
  function notesHtml(l) {
    return `<div class="ld-notes">${(l.notes || []).map((n) => `<div><span class="ld-i">${ICON[n.k] || '•'}</span><b>${esc(n.v)}</b><small>${esc(n.t)}</small></div>`).join('')}</div>`;
  }

  /* ---------- cartel al aterrizar */
  function landingCard(l) {
    document.querySelector('.ld-card')?.remove();
    const d = document.createElement('div');
    d.className = 'ld-card';
    d.innerHTML = `<button class="ld-x" title="Cerrar">✕</button>
      <div class="ld-top">${scoreRing(l.score, 78)}<div><small>Aterrizaje${l.airport ? ' en ' + esc(l.airport) : ''}${l.rwy ? ' · pista ' + esc(l.rwy.runway) : ''}</small>
      <h3 style="color:${colOf(l.score)}">${esc(l.label)}${l.score >= 9 ? ' 🧈' : ''}</h3><span>${Math.abs(l.fpm)} fpm · ${l.g.toFixed(2)} G</span></div></div>${notesHtml(l)}`;
    document.querySelector('main').appendChild(d);
    d.querySelector('.ld-x').onclick = () => d.remove();
    setTimeout(() => d.classList.add('fade'), 14000);
    setTimeout(() => d.remove(), 15000);
  }

  window.onDiario = (st) => {
    if (!st) return;
    if (lastLandingVer !== null && st.landing_ver !== lastLandingVer && st.last_landing) landingCard(st.last_landing);
    lastLandingVer = st.landing_ver;
    if (lastSavedVer !== null && st.saved_ver !== lastSavedVer) { toast('✈ Vuelo guardado en el diario'); load(); }
    lastSavedVer = st.saved_ver;
    const ph = document.getElementById('phaseChip');
    if (ph) ph.textContent = st.phase_txt || '—';
  };

  /* ---------- pestaña Diario */
  async function load() {
    if (!serverOk) { render(); return; }
    try { data = await (await fetch('/api/diario')).json(); } catch (e) { data = null; }
    render();
  }
  function render() {
    if (!panel) return;
    if (!data) { panel.innerHTML = '<h2 class="ptitle">Diario de vuelos</h2><div class="msfs-banner off">Abre SimDirect desde su icono.</div>'; return; }
    const t = data.totals;
    panel.innerHTML = `<h2 class="ptitle">Diario de vuelos</h2><p class="psub">Cada vuelo se guarda solo: despegue, aterrizaje, ruta y la nota de la toma.</p>
      <div class="stats">
        <div class="stat"><b>${t.flights}</b><span>Vuelos</span></div>
        <div class="stat"><b>${t.hours} h</b><span>Horas (calzo a calzo)</span></div>
        <div class="stat"><b>${(t.nm || 0).toLocaleString('es-ES')} nm</b><span>Distancia volada</span></div>
        <div class="stat"><b>${t.airports}</b><span>Aeropuertos</span></div>
        <div class="stat"><b style="color:${t.avg_score !== null ? colOf(t.avg_score) : 'inherit'}">${t.avg_score ?? '—'}</b><span>Nota media de aterrizaje</span></div>
        <div class="stat"><b>${t.avg_fpm ?? '—'}${t.avg_fpm ? ' fpm' : ''}</b><span>Toma media</span></div>
      </div>
      <div id="dOpen"></div>
      <div class="section-head"><h3>Vuelos</h3></div>
      <div class="d-list">${data.flights.length ? data.flights.map((f) => `
        <button class="d-item${open && open.id === f.id ? ' on' : ''}" data-id="${esc(f.id)}">
          <div><b>${esc(f.dep || '????')} → ${esc(f.arr || '????')}</b><small>${esc(f.date)} · ${esc((f.aircraft || '').slice(0, 30))}</small>
          <small>${fmtH(f.air_min || 0)} en el aire · ${f.dist_nm} nm${f.partial ? ' · incompleto' : ''}</small></div>
          ${f.landing ? `<span class="d-score" style="border-color:${colOf(f.landing.score)};color:${colOf(f.landing.score)}">${f.landing.score.toFixed(1)}<small>${Math.abs(f.landing.fpm)} fpm</small></span>` : '<span class="d-score none">—</span>'}
        </button>`).join('') : '<p class="hint">Aún no hay vuelos. Despega con MSFS abierto y SimDirect lo apuntará solo al aterrizar y aparcar.</p>'}</div>`;
    panel.querySelectorAll('.d-item').forEach((b) => b.onclick = () => show(b.dataset.id));
    if (open) renderOpen();
  }
  async function show(id) {
    if (open && open.id === id) { open = null; layer.clearLayers(); render(); return; }
    try { open = await (await fetch('/api/diario/' + encodeURIComponent(id))).json(); } catch (e) { return; }
    render();
    layer.clearLayers();
    const pts = (open.track || []).map((p) => [p[0], p[1]]);
    if (pts.length > 1) {
      L.polyline(pts, { color: '#04121c', weight: 7, opacity: .5 }).addTo(layer);
      L.polyline(pts, { color: '#3cc8ff', weight: 3.5, opacity: .95 }).addTo(layer);
      (open.landings || []).forEach((l) => L.circleMarker([l.lat, l.lon], { radius: 7, color: '#04121c', weight: 2, fillColor: colOf(l.score), fillOpacity: 1 })
        .bindTooltip(`Toma ${l.score.toFixed(1)} · ${Math.abs(l.fpm)} fpm`).addTo(layer));
      map.fitBounds(L.latLngBounds(pts).pad(0.15));
    }
  }
  function renderOpen() {
    const box = panel.querySelector('#dOpen'); if (!box || !open) return;
    const l = open.landing;
    box.innerHTML = `<div class="d-open">
      <div class="d-open-h"><b>${esc(open.dep || '????')} → ${esc(open.arr || '????')}</b><small>${esc(open.date)} · ${esc(open.aircraft || '')}</small></div>
      <div class="stats">
        <div class="stat"><b>${fmtH(open.block_min || 0)}</b><span>Calzo a calzo</span></div>
        <div class="stat"><b>${fmtH(open.air_min || 0)}</b><span>En el aire</span></div>
        <div class="stat"><b>${open.dist_nm} nm</b><span>Distancia</span></div>
        <div class="stat"><b>FL${Math.round((open.max_alt || 0) / 100)}</b><span>Altitud máxima</span></div>
        ${open.fuel_kg ? `<div class="stat wide"><b>${open.fuel_kg.toLocaleString('es-ES')} kg</b><span>Combustible gastado</span></div>` : ''}
      </div>
      ${l ? `<div class="ld-top" style="margin-top:8px">${scoreRing(l.score, 64)}<div><h3 style="color:${colOf(l.score)};margin:0">${esc(l.label)}</h3><span>${Math.abs(l.fpm)} fpm · ${l.g.toFixed(2)} G${l.rwy ? ' · pista ' + esc(l.rwy.runway) : ''}</span></div></div>${notesHtml(l)}` : '<p class="hint">Este vuelo no terminó con un aterrizaje.</p>'}
      ${(open.landings || []).length > 1 ? `<p class="hint">${open.landings.length} tomas en este vuelo (tomas y despegues): se muestra la última.</p>` : ''}
      <div class="toolbar"><button id="dClose">Cerrar</button><button id="dDel" class="danger">Borrar vuelo</button></div></div>`;
    box.querySelector('#dClose').onclick = () => { open = null; layer.clearLayers(); render(); };
    box.querySelector('#dDel').onclick = async () => {
      if (!confirm('¿Borrar este vuelo del diario?')) return;
      await fetch('/api/diario/' + encodeURIComponent(open.id), { method: 'DELETE' });
      open = null; layer.clearLayers(); load();
    };
  }
  document.querySelectorAll('.tab[data-tab]').forEach((t) => t.addEventListener('click', () => {
    if (t.dataset.tab === 'diario') load(); else if (open) { open = null; layer.clearLayers(); }
  }));
  render();
  return { load, landingCard };
})();
