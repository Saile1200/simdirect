'use strict';
/* Pasajeros, carga, peso y combustible. Vale para cualquier avión: si MSFS está abierto usa sus pesos reales. */

const Peso = (() => {
  let ffAvg = null, ffSamples = [], lastTitle = '';
  const S = Object.assign({ pax: 150, paxKg: 84, bagKg: 15, cargo: 1500, gaPax: 2, gaCargo: 20, altMin: 30, reserveMin: 30, contPct: 5 },
    store('simdirect.peso') || {});
  const save = () => store('simdirect.peso', S);
  const kg = (v) => Math.round(v).toLocaleString('es-ES') + ' kg';

  // perfiles base (si MSFS no está abierto)
  const BASE = {
    jet: { oew: 42600, mtow: 79000, mlw: 67400, mzfw: 64300, cap: 18700, seats: 180, cols: 6 },
    ga: { oew: 767, mtow: 1157, mlw: 1157, mzfw: 1157, cap: 145, seats: 4, cols: 2 },
  };
  function guessProfile(t) {
    t = (t || '').toLowerCase();
    if (/a32\d|a319|a321|airbus a3[12]/.test(t)) return 'a320';
    if (/737|b738|b38m/.test(t)) return 'b738';
    if (/787|b78|777|b77|a350|a330|747/.test(t)) return 'b78x';
    if (/tbm|pc-?12|king ?air|caravan|208/.test(t)) return 'tbm9';
    if (/172|152|182|piper|pa-?28|da40|da62|sr22|cub|extra|cessna/.test(t)) return 'c172';
    return null;
  }
  function simAircraft() { return live && live.aircraft && live.aircraft.title ? live.aircraft : null; }

  // datos del avión que se usa para los cálculos
  function spec() {
    const a = simAircraft(), ga = isGA(), b = ga ? BASE.ga : BASE.jet;
    if (a && a.max) {
      const seats = a.max < 2500 ? 4 : a.max < 9000 ? 9 : a.max < 30000 ? 70 : a.max < 95000 ? 180 : a.max < 260000 ? 290 : 400;
      return { title: a.title, oew: a.empty, mtow: a.max, mlw: a.max * (ga ? 1 : 0.86), mzfw: a.max * (ga ? 1 : 0.82),
        cap: a.fuel_cap || b.cap, seats, cols: seats <= 4 ? 2 : seats <= 9 ? 3 : seats <= 70 ? 4 : seats <= 180 ? 6 : 9, live: true, fuelNow: a.fuel, cg: a.cg };
    }
    return { title: ga ? 'Avioneta (Cessna 172)' : 'Avión de línea (tipo A320)', ...b, live: false };
  }

  // cálculo completo de carga y combustible para el plan actual
  function compute() {
    const sp = spec(), ga = isGA();
    const pax = Math.max(0, Math.min(sp.seats, ga ? S.gaPax : S.pax));
    const cargo = Math.max(0, ga ? S.gaCargo : S.cargo);
    const payload = pax * (S.paxKg + (ga ? 0 : S.bagKg)) + cargo;
    const zfw = sp.oew + payload;
    const r = computeRoute(), est = estimates(r), ac = aircraft();
    const burn = ffAvg || (sp.live && sp.mtow ? Math.max(20, sp.mtow * 0.028) : ac.burnKgH);
    const taxi = ga ? 3 : Math.round(sp.mtow * 0.0028);
    const trip = est.time * burn, cont = trip * S.contPct / 100, alt = burn * S.altMin / 60, fin = burn * S.reserveMin / 60;
    const block = Math.min(sp.cap || 1e9, taxi + trip + cont + alt + fin);
    const tow = zfw + block - taxi, lw = tow - trip;
    return { sp, pax, cargo, payload, zfw, taxi, trip, cont, alt, fin, block, tow, lw, burn, r, est, ga,
      over: { zfw: zfw > sp.mzfw, tow: tow > sp.mtow, lw: lw > sp.mlw, cap: taxi + trip + cont + alt + fin > (sp.cap || 1e9) } };
  }

  // asocia el avión de MSFS al plan (velocidades y crucero reales)
  function syncAircraft(a) {
    if (!a || !a.title) return;
    const base = AIRCRAFT.find((x) => x.id === guessProfile(a.title)) || (a.max && a.max < 6000 ? AIRCRAFT.find((x) => x.id === 'c172') : AIRCRAFT[0]);
    const cruiseAlt = a.cruise_alt > 1000 ? a.cruise_alt : base.cruiseAlt;
    const tas = a.vc > 40 ? Math.round(a.vc * (1 + cruiseAlt / 1000 * 0.02)) : base.cruiseTas;
    let sim = AIRCRAFT.find((x) => x.id === 'sim');
    if (!sim) { sim = { id: 'sim' }; AIRCRAFT.unshift(sim); }
    Object.assign(sim, { name: a.title.slice(0, 40), cruiseTas: tas, cruiseAlt, ceiling: Math.max(cruiseAlt + 4000, base.ceiling),
      climbFtNm: base.climbFtNm, descFtNm: base.descFtNm, burnKgH: Math.round(ffAvg || (a.max ? Math.max(20, a.max * 0.028) : base.burnKgH)), fuelUnit: 'kg' });
    if (a.title !== lastTitle) {
      lastTitle = a.title;
      $('#aircraft').innerHTML = AIRCRAFT.map((x) => `<option value="${x.id}">${esc(x.name)}</option>`).join('');
      plan.aircraftId = 'sim'; plan.cruiseAlt = Math.round(cruiseAlt / 1000) * 1000;
      fillForm(); autoAltitudes(); render();
      toast('Avión detectado: ' + a.title, 3500);
    }
  }
  function onData(d) {
    const a = d && d.aircraft; if (!a) return;
    if (!d.on_ground && Math.abs(d.vs) < 300 && a.ff > 0) {
      ffSamples.push(a.ff); if (ffSamples.length > 300) ffSamples.shift();
      if (ffSamples.length > 20) ffAvg = ffSamples.reduce((x, y) => x + y, 0) / ffSamples.length;
    }
    syncAircraft(a);
    if (document.querySelector('#tab-weight.active') && Date.now() - (onData.t || 0) > 2000 && !document.activeElement.closest('#tab-weight')) { onData.t = Date.now(); renderPanel(); }
  }

  // mapa de asientos visto desde arriba, con los pasajeros sentados
  function seatMap(c) {
    const { seats, cols } = c.sp, rows = Math.ceil(seats / cols);
    const occ = new Set(); let n = 0;
    // reparte a los pasajeros de forma natural (primero ventanas y pasillo, de delante a atrás con huecos)
    const order = [];
    for (let r = 0; r < rows; r++) for (let k = 0; k < cols; k++) order.push([r, k]);
    order.sort((a, b) => ((a[0] * 7 + a[1] * 13) % 11) - ((b[0] * 7 + b[1] * 13) % 11) || a[0] - b[0]);
    for (const [r, k] of order) { if (n >= c.pax) break; occ.add(r + '-' + k); n++; }
    const sw = 12, sh = 12, gap = 3, aisle = cols >= 6 ? 14 : 10;
    const half = Math.ceil(cols / 2);
    const W = cols * (sw + gap) + aisle + 30, H = rows * (sh + gap) + 90;
    const x0 = 15, y0 = 60;
    let seatsSvg = '';
    for (let r = 0; r < rows; r++) for (let k = 0; k < cols; k++) {
      if (r * cols + k >= seats) continue;
      const x = x0 + k * (sw + gap) + (k >= half ? aisle : 0), y = y0 + r * (sh + gap);
      const on = occ.has(r + '-' + k);
      seatsSvg += `<rect x="${x}" y="${y}" width="${sw}" height="${sh}" rx="3" fill="${on ? '#3cc8ff' : '#1d2a36'}" stroke="${on ? '#9ee9ff' : '#2c3d4d'}"/>`;
      if (on) seatsSvg += `<circle cx="${x + sw / 2}" cy="${y + sh / 2 - 1}" r="2.6" fill="#0a2a3a"/>`;
    }
    const cx = W / 2;
    return `<svg class="seatmap" viewBox="0 0 ${W} ${H}" preserveAspectRatio="xMidYMin meet">
      <path d="M${cx} 4 C ${W - 6} 28, ${W - 4} 50, ${W - 4} 60 L ${W - 4} ${H - 30} C ${W - 4} ${H - 10}, ${cx + 10} ${H - 2}, ${cx} ${H - 2} C ${cx - 10} ${H - 2}, 4 ${H - 10}, 4 ${H - 30} L 4 60 C 4 50, 6 28, ${cx} 4 Z" fill="#0f1922" stroke="#33485b" stroke-width="2"/>
      <path d="M${cx - 14} 30 Q ${cx} 20 ${cx + 14} 30 L ${cx + 12} 40 L ${cx - 12} 40 Z" fill="#203245"/>
      ${seatsSvg}</svg>`;
  }

  function renderPanel() {
    const box = $('#tab-weight'); if (!box) return;
    const c = compute(), sp = c.sp, ga = c.ga;
    const warn = (b) => (b ? ' warn' : '');
    const fuelNow = sp.live ? sp.fuelNow : null;
    const diff = fuelNow != null ? fuelNow - c.block : null;
    box.innerHTML = `<h2 class="ptitle">Pasajeros y combustible</h2>
      <p class="psub">${sp.live ? '✈ <b>' + esc(sp.title) + '</b> (datos reales de MSFS)' : esc(sp.title) + ' · abre MSFS para usar los datos reales de tu avión'}</p>
      <div class="pax-wrap">
        <div class="pax-controls">
          <label class="field">Pasajeros (${sp.seats} asientos)<input type="range" id="wPax" min="0" max="${sp.seats}" value="${c.pax}"><b class="big-num">${c.pax}</b></label>
          <label class="field">Carga en bodega (kg)<input type="number" id="wCargo" value="${c.cargo}" min="0" step="${ga ? 5 : 100}"></label>
          <div class="stat"><b>${kg(c.payload)}</b><span>Carga de pago${ga ? '' : ` (${S.paxKg} kg/pax + ${S.bagKg} kg maleta)`}</span></div>
          <button id="wFull">Lleno</button> <button id="wHalf">Mitad</button> <button id="wEmpty">Vacío</button>
        </div>
        <div class="pax-plane">${seatMap(c)}</div>
      </div>
      <div class="section-head"><h3>⛽ Combustible a cargar</h3></div>
      <div class="fuel-big ${c.over.cap ? 'warn' : ''}"><b>${kg(c.block)}</b><span>${c.over.cap ? '⚠ el plan necesita más de lo que cabe en los depósitos' : `para «${esc(plan.name)}» · ${fmtNm(c.r.total)} · ${fmtTime(c.est.time)}`}</span></div>
      ${fuelNow != null ? `<p class="${diff < 0 ? 'job err' : 'job ok'}">${diff < 0 ? `Llevas ${kg(fuelNow)}: faltan ${kg(-diff)}` : `Llevas ${kg(fuelNow)}: sobran ${kg(diff)}`}</p>` : ''}
      <table class="ftable">
        <tr><td>Rodaje</td><td>${kg(c.taxi)}</td></tr>
        <tr><td>Viaje</td><td>${kg(c.trip)}</td></tr>
        <tr><td>Contingencia ${S.contPct}%</td><td>${kg(c.cont)}</td></tr>
        <tr><td>Alternativo ${S.altMin} min</td><td>${kg(c.alt)}</td></tr>
        <tr><td>Reserva final ${S.reserveMin} min</td><td>${kg(c.fin)}</td></tr>
        <tr class="tot"><td>Total a cargar</td><td>${kg(c.block)}</td></tr>
      </table>
      <div class="section-head"><h3>⚖ Pesos</h3></div>
      ${bar([{ n: 'Vacío', v: sp.oew, c: '#4b6276' }, { n: 'Pasajeros y carga', v: c.payload, c: '#3cc8ff' }, { n: 'Combustible', v: c.block, c: '#ffb547' }], sp.mtow)}
      <div class="stats">
        <div class="stat${warn(c.over.zfw)}"><b>${kg(c.zfw)}</b><span>ZFW (sin combustible) · máx ${kg(sp.mzfw)}</span></div>
        <div class="stat${warn(c.over.tow)}"><b>${kg(c.tow)}</b><span>Despegue (TOW) · máx ${kg(sp.mtow)}</span></div>
        <div class="stat${warn(c.over.lw)}"><b>${kg(c.lw)}</b><span>Aterrizaje (LW) · máx ${kg(sp.mlw)}</span></div>
        <div class="stat"><b>${sp.cg ? sp.cg + ' %' : '—'}</b><span>Centro de gravedad (MSFS)</span></div>
      </div>
      ${(c.over.zfw || c.over.tow || c.over.lw) ? '<p class="job err">⚠ Te pasas de algún peso máximo: quita pasajeros, carga o combustible.</p>' : ''}
      <p class="hint">Carga estos pasajeros y este combustible en la tablet (EFB) del avión en MSFS. La PERFORMANCE de despegue y aterrizaje está en la pestaña <b>FMC</b>.</p>
      <div class="section-head"><h3>Reservas</h3></div>
      <div class="row2"><label class="field">Contingencia %<input type="number" id="wCont" value="${S.contPct}" min="0" max="20"></label>
      <label class="field">Alternativo (min)<input type="number" id="wAlt" value="${S.altMin}" min="0" max="120" step="5"></label>
      <label class="field">Reserva (min)<input type="number" id="wRes" value="${S.reserveMin}" min="0" max="90" step="5"></label></div>`;
    const setPax = (v) => { if (ga) S.gaPax = v; else S.pax = v; save(); renderPanel(); };
    $('#wPax').oninput = (e) => { e.target.nextElementSibling.textContent = e.target.value; };
    $('#wPax').onchange = (e) => setPax(+e.target.value);
    $('#wFull').onclick = () => setPax(sp.seats); $('#wHalf').onclick = () => setPax(Math.round(sp.seats / 2)); $('#wEmpty').onclick = () => setPax(0);
    $('#wCargo').onchange = (e) => { if (ga) S.gaCargo = Math.max(0, +e.target.value || 0); else S.cargo = Math.max(0, +e.target.value || 0); save(); renderPanel(); };
    const bind = (id, k) => { const el = $(id); if (el) el.onchange = () => { S[k] = Math.max(0, +el.value || 0); save(); renderPanel(); }; };
    bind('#wCont', 'contPct'); bind('#wAlt', 'altMin'); bind('#wRes', 'reserveMin');
  }
  function bar(parts, max) {
    const tot = parts.reduce((x, p) => x + p.v, 0), scale = Math.max(max || tot, tot) || 1;
    return `<div class="wbar">${parts.map((p) => `<span style="width:${(p.v / scale) * 100}%;background:${p.c}"></span>`).join('')}${max ? `<i style="left:${(max / scale) * 100}%"></i>` : ''}</div>
      <div class="wlegend">${parts.map((p) => `<span><b style="background:${p.c}"></b>${p.n} ${kg(p.v)}</span>`).join('')}<span>│ máx ${kg(max)}</span></div>`;
  }

  document.querySelector('.tab[data-tab="weight"]').addEventListener('click', renderPanel);
  return { onData, renderPanel, compute };
})();
window.Peso = Peso;
