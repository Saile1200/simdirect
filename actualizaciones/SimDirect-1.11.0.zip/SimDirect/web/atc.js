'use strict';
/* Radio: con quién hablar en cada fase del vuelo y en qué frecuencia (y ponerla en el COM1) */
(() => {
  let st = null, lastVer = null, expanded = store('simdirect.radioOpen') === true, live = false;
  let net = store('simdirect.atcNet') || '';
  const NETS = { '': 'Sin red', vatsim: 'VATSIM', ivao: 'IVAO' };
  const Ctl = L.Control.extend({
    options: { position: 'topright' },
    onAdd() {
      const d = L.DomUtil.create('div', 'radio-w');
      L.DomEvent.disableClickPropagation(d); L.DomEvent.disableScrollPropagation(d);
      return d;
    },
  });
  const ctl = new Ctl(); map.addControl(ctl);
  const box = ctl.getContainer();

  async function com(mhz, swap) {
    try { const r = await post('/api/atc/com', { mhz, swap }); toast(r.ok ? '📻 ' + r.msg : r.error, 3000); } catch (e) { toast('Sin conexión con SimDirect'); }
  }
  async function setNet(v) {
    net = v; store('simdirect.atcNet', net);
    try { await post('/api/atc/net', { net: net || null }); } catch (e) { /* */ }
    toast(net ? `Radio: usando los controladores de ${NETS[net]} conectados` : 'Radio: frecuencias reales de los aeropuertos');
    render();
  }

  function render() {
    if (!live || !st || !st.now) {
      box.innerHTML = `<div class="radio-h"><span>📻 Radio</span><small id="phaseChip">${live ? 'Calculando…' : 'Entra en un vuelo de MSFS'}</small></div>`;
      return;
    }
    const n = st.now;
    box.innerHTML = `
      <div class="radio-h"><span>📻 Radio</span><small id="phaseChip">${esc(st.phase_txt || '')}</small><button class="radio-t" title="${expanded ? 'Menos' : 'Todas las frecuencias'}">${expanded ? '▴' : '▾'}</button></div>
      <div class="radio-now"><small>Contacta con</small><b>${esc(n.name)}</b>
        <div class="radio-f"><span class="radio-mhz">${esc(n.mhz)}</span>${n.online ? '<span class="radio-on">● online</span>' : ''}</div>
        <div class="radio-btns"><button data-mhz="${esc(n.mhz)}">COM1 STBY</button><button data-mhz="${esc(n.mhz)}" data-swap="1" class="primary">Activa</button></div></div>
      ${st.atis && n.type !== 'ATIS' ? `<div class="radio-atis">ATIS <b>${esc(st.atis.mhz)}</b> <button data-mhz="${esc(st.atis.mhz)}" class="mini">STBY</button></div>` : ''}
      ${expanded ? `<div class="radio-list">${(st.list || []).map((f) => `<div class="${f.mhz === n.mhz ? 'on' : ''}"><span>${esc(f.label)}${f.desc && f.desc.toUpperCase() !== f.type ? ` <small>${esc(f.desc)}</small>` : ''}</span><b>${esc(f.mhz)}</b>${f.online ? '<i>●</i>' : ''}<button data-mhz="${esc(f.mhz)}" class="mini">STBY</button></div>`).join('') || '<p class="hint">Sin frecuencias para este aeropuerto.</p>'}</div>
        <div class="radio-net">${Object.entries(NETS).map(([k, v]) => `<label><input type="radio" name="atcnet" value="${k}" ${k === (net || '') ? 'checked' : ''}> ${v}</label>`).join('')}</div>` : ''}`;
    box.querySelectorAll('button[data-mhz]').forEach((b) => b.onclick = () => com(b.dataset.mhz, !!b.dataset.swap));
    box.querySelector('.radio-t').onclick = () => { expanded = !expanded; store('simdirect.radioOpen', expanded); render.sig = null; render(); };
    box.querySelectorAll('input[name=atcnet]').forEach((r) => r.onchange = () => setNet(r.value));
  }

  let phaseTxt = '';
  const prevDiario = window.onDiario;
  window.onDiario = (d) => { if (prevDiario) prevDiario(d); phaseTxt = (d && d.phase_txt) || ''; if (st) st.phase_txt = phaseTxt; };
  window.onAtc = (a, isLive) => {
    const wasLive = live; live = !!isLive;
    if (a && a.now) { st = { ...a, phase_txt: phaseTxt }; }
    if (live && st && lastVer !== null && st.ver !== lastVer && st.now) {
      toast(`📻 Contacta con ${st.now.name} · ${st.now.mhz}`, 4500);
    }
    if (st) lastVer = st.ver;
    const sig = JSON.stringify([live, st && st.now, st && st.atis, st && (st.list || []).map((f) => f.mhz + f.online), phaseTxt, expanded, net]);
    if (sig !== render.sig) { render.sig = sig; render(); }
  };
  if (net) setTimeout(() => { if (serverOk) post('/api/atc/net', { net }).catch(() => {}); }, 2500);
  render();
})();
