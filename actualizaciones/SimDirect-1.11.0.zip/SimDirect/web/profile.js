'use strict';
/* El inicio de sesión se ha quitado. Si una versión vieja de la página carga este archivo, quita el botón. */
document.querySelectorAll('#profileBtn').forEach((b) => b.remove());
