#!/usr/bin/env python3
"""
SimDirect - recorrido de los jugadores online (MSFS, VATSIM e IVAO).

VATSIM, IVAO y el multijugador de MSFS solo dan la posición actual de cada avión, así que
SimDirect la va grabando en segundo plano (con el rumbo y la velocidad) mientras tienes
«Jugadores online» activado. Los recorridos se guardan en datos/trayectos.json para no
perderlos al cerrar la app. La interfaz dibuja la línea con curvas usando el rumbo de cada
punto, así se ven los giros que ha hecho.
"""
import json
import math
import threading
import time
from collections import deque
from pathlib import Path

BASE = Path(__file__).resolve().parent
FILE = BASE / "datos" / "trayectos.json"
_lock = threading.Lock()
TRACKS = {}             # "red:CALLSIGN" -> {"pts": deque[(lat, lon, alt, t, hdg, gs)], "seen", "dep", "arr", "since"}
_last_prune = 0.0
_last_save = 0.0
_loaded = False
MAX_PTS = 5000
FORGET_S = 60 * 60      # si no se ve a un jugador en 1 h, se olvida su recorrido


def _km(a_lat, a_lon, b_lat, b_lon):
    k = math.cos(math.radians((a_lat + b_lat) / 2))
    return math.hypot((b_lat - a_lat) * 111.0, (b_lon - a_lon) * 111.0 * k)


def _brg(a_lat, a_lon, b_lat, b_lon):
    k = math.cos(math.radians((a_lat + b_lat) / 2))
    return (math.degrees(math.atan2((b_lon - a_lon) * k, b_lat - a_lat)) + 360) % 360


def _adiff(a, b):
    return abs((a - b + 540) % 360 - 180)


def key(net, cs):
    return f"{net}:{str(cs or '').strip().upper()}"


def load():
    global _loaded
    with _lock:
        if _loaded:
            return
        _loaded = True
        try:
            data = json.loads(FILE.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            return
        now = time.time()
        for k, t in data.items():
            if now - t.get("seen", 0) > FORGET_S:
                continue
            TRACKS[k] = {"pts": deque((tuple(p) for p in t.get("pts", [])), maxlen=MAX_PTS), "seen": t["seen"],
                         "dep": t.get("dep", ""), "arr": t.get("arr", ""), "since": t.get("since", now)}


def save(force=False):
    global _last_save
    now = time.time()
    if not force and now - _last_save < 60:
        return
    _last_save = now
    with _lock:
        data = {k: {"pts": list(t["pts"]), "seen": t["seen"], "dep": t["dep"], "arr": t["arr"], "since": t["since"]}
                for k, t in TRACKS.items() if len(t["pts"]) > 1}
    try:
        FILE.parent.mkdir(parents=True, exist_ok=True)
        tmp = FILE.with_suffix(".tmp")
        tmp.write_text(json.dumps(data, separators=(",", ":")), encoding="utf-8")
        tmp.replace(FILE)
    except OSError:
        pass


def record(pilots):
    global _last_prune
    load()
    now = time.time()
    with _lock:
        for p in pilots:
            cs = p.get("cs")
            try:
                lat, lon = float(p["lat"]), float(p["lon"])
                alt = float(p.get("alt") or 0)
                gs = float(p.get("gs") or 0)
                hdg = float(p.get("hdg") or 0) % 360
            except (KeyError, TypeError, ValueError):
                continue
            if not cs or (abs(lat) < 1e-6 and abs(lon) < 1e-6):
                continue
            k = key(p.get("net"), cs)
            t = TRACKS.get(k)
            dep, arr = (p.get("dep") or "").upper(), (p.get("arr") or "").upper()
            if t is None or (dep and t["dep"] and dep != t["dep"]):
                t = TRACKS[k] = {"pts": deque(maxlen=MAX_PTS), "seen": now, "dep": dep, "arr": arr, "since": now}
            t["dep"], t["arr"] = dep or t["dep"], arr or t["arr"]
            pts = t["pts"]
            if pts:
                la, lo, al, tt = pts[-1][:4]
                d = _km(la, lo, lat, lon)
                dt = max(1.0, now - tt)
                # salto imposible (se ha recolocado o es otro vuelo): empieza de cero
                if d > max(60.0, (max(gs, 250) * 1.852 / 3600) * dt * 3):
                    pts.clear()
                    t["since"] = now
                elif d < 0.15 and abs(alt - al) < 200 and _adiff(hdg, pts[-1][4] if len(pts[-1]) > 4 else hdg) < 3:
                    t["seen"] = now          # parado o sin cambios: no hace falta otro punto
                    continue
                # si el rumbo que da la red no cuadra con el movimiento (algunas redes lo dan raro), usar el real
                if d > 0.5 and gs > 40 and _adiff(hdg, _brg(la, lo, lat, lon)) > 100:
                    hdg = _brg(la, lo, lat, lon)
            pts.append((round(lat, 5), round(lon, 5), int(alt), int(now), int(round(hdg)), int(gs)))
            t["seen"] = now
        if now - _last_prune > 60:
            _last_prune = now
            for k in [k for k, t in TRACKS.items() if now - t["seen"] > FORGET_S]:
                TRACKS.pop(k, None)
    save()


def get(net, cs):
    load()
    with _lock:
        t = TRACKS.get(key(net, cs))
        if not t:
            return None
        return {"pts": [[p[0], p[1], p[2], p[3], p[4] if len(p) > 4 else None, p[5] if len(p) > 5 else None]
                        for p in t["pts"]],
                "dep": t["dep"], "arr": t["arr"], "since": int(t["since"])}
