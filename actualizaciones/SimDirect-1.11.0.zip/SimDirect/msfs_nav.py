"""
SimDirect - datos de navegación del propio MSFS 2024 (Facility Data API de SimConnect):
pistas, salidas (SID), llegadas (STAR) y aproximaciones de cualquier aeropuerto.

Abre una conexión SimConnect propia (aparte de la de telemetría) y pide los datos con
SimConnect_AddToFacilityDefinition + SimConnect_RequestFacilityData.
"""
import ctypes
import struct
import threading
import time
from ctypes import byref, c_char_p, c_void_p, c_uint32, POINTER
from pathlib import Path

HRESULT = ctypes.c_long
_lock = threading.Lock()
_cache = {}

# Tipos de dato de facilidades (SIMCONNECT_FACILITY_DATA_TYPE)
T_AIRPORT, T_RUNWAY, T_APPROACH, T_DEPARTURE, T_ARRIVAL, T_RWY_TRANS, T_ENR_TRANS = 0, 1, 5, 10, 11, 12, 13

RWY_DESIG = {0: "", 1: "L", 2: "R", 3: "C", 4: "W", 5: "A", 6: "B"}
APPR_TYPE = {0: "", 1: "GPS", 2: "VOR", 3: "NDB", 4: "ILS", 5: "LOC", 6: "SDF", 7: "LDA", 8: "VORDME",
             9: "NDBDME", 10: "RNAV", 11: "BC"}

# Campos que pedimos y cómo se leen (formato struct, tamaño fijo, empaquetado sin relleno)
DEF = [
    ("OPEN AIRPORT", None),
    ("LATITUDE", "d"), ("LONGITUDE", "d"), ("ALTITUDE", "d"),
    ("N_RUNWAYS", "i"), ("N_APPROACHES", "i"), ("N_DEPARTURES", "i"), ("N_ARRIVALS", "i"),
    ("OPEN RUNWAY", None),
    ("LATITUDE", "d"), ("LONGITUDE", "d"), ("ALTITUDE", "d"), ("HEADING", "f"), ("LENGTH", "f"), ("WIDTH", "f"),
    ("PRIMARY_NUMBER", "i"), ("PRIMARY_DESIGNATOR", "i"), ("SECONDARY_NUMBER", "i"), ("SECONDARY_DESIGNATOR", "i"),
    ("CLOSE RUNWAY", None),
    ("OPEN APPROACH", None),
    ("TYPE", "i"), ("SUFFIX", "i"), ("RUNWAY_NUMBER", "i"), ("RUNWAY_DESIGNATOR", "i"),
    ("CLOSE APPROACH", None),
    ("OPEN DEPARTURE", None),
    ("NAME", "8s"),
    ("OPEN RUNWAY_TRANSITION", None), ("RUNWAY_NUMBER", "i"), ("RUNWAY_DESIGNATOR", "i"), ("CLOSE RUNWAY_TRANSITION", None),
    ("OPEN ENROUTE_TRANSITION", None), ("NAME", "8s"), ("CLOSE ENROUTE_TRANSITION", None),
    ("CLOSE DEPARTURE", None),
    ("OPEN ARRIVAL", None),
    ("NAME", "8s"),
    ("OPEN RUNWAY_TRANSITION", None), ("RUNWAY_NUMBER", "i"), ("RUNWAY_DESIGNATOR", "i"), ("CLOSE RUNWAY_TRANSITION", None),
    ("OPEN ENROUTE_TRANSITION", None), ("NAME", "8s"), ("CLOSE ENROUTE_TRANSITION", None),
    ("CLOSE ARRIVAL", None),
    ("CLOSE AIRPORT", None),
]

# formato de cada tipo, en el orden de DEF
FMT = {
    T_AIRPORT: "<dddiiii",
    T_RUNWAY: "<dddfffiiii",
    T_APPROACH: "<iiii",
    T_DEPARTURE: "<8s",
    T_ARRIVAL: "<8s",
    T_RWY_TRANS: "<ii",
    T_ENR_TRANS: "<8s",
}


def rwy_name(num, des):
    if not num:
        return ""
    if num <= 36:
        s = f"{num:02d}"
    else:
        s = {37: "N", 38: "NE", 39: "E", 40: "SE", 41: "S", 42: "SW", 43: "W", 44: "NW"}.get(num, str(num))
    return s + RWY_DESIG.get(des, "")


def _dll():
    try:
        import SimConnect
        path = Path(SimConnect.__file__).parent / "SimConnect.dll"
    except Exception:  # noqa: BLE001
        return None
    dll = ctypes.WinDLL(str(path))
    dll.SimConnect_Open.restype = HRESULT
    dll.SimConnect_Open.argtypes = [POINTER(c_void_p), c_char_p, c_void_p, c_uint32, c_void_p, c_uint32]
    dll.SimConnect_Close.argtypes = [c_void_p]
    dll.SimConnect_AddToFacilityDefinition.restype = HRESULT
    dll.SimConnect_AddToFacilityDefinition.argtypes = [c_void_p, c_uint32, c_char_p]
    dll.SimConnect_RequestFacilityData.restype = HRESULT
    dll.SimConnect_RequestFacilityData.argtypes = [c_void_p, c_uint32, c_uint32, c_char_p, c_char_p]
    dll.SimConnect_GetNextDispatch.restype = HRESULT
    dll.SimConnect_GetNextDispatch.argtypes = [c_void_p, POINTER(c_void_p), POINTER(c_uint32)]
    return dll


def fetch_airport(icao, timeout=12.0):
    """Devuelve {lat, lon, alt, runways[], sids[], stars[], approaches[]} desde MSFS, o lanza excepción."""
    icao = icao.upper().strip()
    if icao in _cache and time.time() - _cache[icao][0] < 3600:
        return _cache[icao][1]
    with _lock:
        dll = _dll()
        if dll is None:
            raise RuntimeError("SimConnect no disponible")
        h = c_void_p()
        if dll.SimConnect_Open(byref(h), b"SimDirectNav", None, 0, None, 0) != 0:
            raise RuntimeError("MSFS no está abierto")
        try:
            DEF_ID, REQ_ID = 77, 7701
            for field, _ in DEF:
                dll.SimConnect_AddToFacilityDefinition(h, DEF_ID, field.encode())
            if dll.SimConnect_RequestFacilityData(h, DEF_ID, REQ_ID, icao.encode(), b"") != 0:
                raise RuntimeError("Petición rechazada")
            items = {}       # unique_id -> (type, parent, values)
            order = []
            errors = 0
            t0 = time.time()
            done = False
            while time.time() - t0 < timeout and not done:
                p = c_void_p()
                size = c_uint32()
                if dll.SimConnect_GetNextDispatch(h, byref(p), byref(size)) != 0 or not p.value:
                    time.sleep(0.01)
                    continue
                raw = ctypes.string_at(p.value, size.value)
                if len(raw) < 16:
                    continue
                dw_size, _ver, dw_id = struct.unpack_from("<III", raw, 0)
                if dw_id == 1:                                  # excepción (campo no válido, etc.)
                    errors += 1
                    continue
                user_req = struct.unpack_from("<I", raw, 12)[0]
                if user_req != REQ_ID:
                    continue
                if dw_size <= 20 and len(raw) <= 20:            # FACILITY_DATA_END
                    done = True
                    continue
                if len(raw) < 40:
                    continue
                uniq, parent, ftype, _is_list, _idx, _lsize = struct.unpack_from("<IIIIII", raw, 16)
                fmt = FMT.get(ftype)
                if not fmt:
                    continue
                try:
                    vals = struct.unpack_from(fmt, raw, 40)
                except struct.error:
                    continue
                items[uniq] = (ftype, parent, vals)
                order.append(uniq)
            if not order:
                raise RuntimeError("MSFS no devolvió datos de " + icao + (f" ({errors} errores)" if errors else ""))
        finally:
            dll.SimConnect_Close(h)

    out = {"icao": icao, "source": "msfs", "runways": [], "sids": {}, "stars": {}, "approaches": []}
    nodes = {}
    for u in order:
        ftype, parent, v = items[u]
        if ftype == T_AIRPORT:
            out.update(lat=v[0], lon=v[1], alt_m=v[2])
        elif ftype == T_RUNWAY:
            lat, lon, _alt, hdg, length, width, pn, pd, sn, sd = v
            out["runways"].append({"lat": lat, "lon": lon, "heading": hdg, "length_m": length, "width_m": width,
                                   "ends": [rwy_name(pn, pd), rwy_name(sn, sd)]})
        elif ftype == T_APPROACH:
            t, suf, rn, rd = v
            name = APPR_TYPE.get(t, "APP") + (f" {chr(suf)}" if 65 <= suf <= 90 else "")
            out["approaches"].append({"type": APPR_TYPE.get(t, ""), "name": name.strip(), "runway": rwy_name(rn, rd)})
        elif ftype in (T_DEPARTURE, T_ARRIVAL):
            name = v[0].split(b"\0")[0].decode("ascii", "ignore")
            key = "sids" if ftype == T_DEPARTURE else "stars"
            proc = out[key].setdefault(name, {"name": name, "runways": [], "transitions": []})
            nodes[u] = proc
        elif ftype == T_RWY_TRANS and parent in nodes:
            r = rwy_name(*v)
            if r and r not in nodes[parent]["runways"]:
                nodes[parent]["runways"].append(r)
        elif ftype == T_ENR_TRANS and parent in nodes:
            n = v[0].split(b"\0")[0].decode("ascii", "ignore")
            if n:
                nodes[parent]["transitions"].append(n)
    out["sids"] = sorted(out["sids"].values(), key=lambda x: x["name"])
    out["stars"] = sorted(out["stars"].values(), key=lambda x: x["name"])
    _cache[icao] = (time.time(), out)
    return out
