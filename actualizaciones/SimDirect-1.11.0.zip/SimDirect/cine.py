"""
SimDirect · Cine: vídeos tipo película de tus vuelos en MSFS 2024.

  - Grabar el vuelo (posición, actitud, tren, flaps, spoilers) unas 25 veces por segundo.
  - Reproducirlo moviendo tu avión (congelado) a cualquier velocidad, con línea de tiempo.
  - Momentos destacados automáticos: despegue, toma de contacto, virajes cerrados, crucero…
  - Director de cámaras: cortes entre persecución, cabina, cámaras fijas del avión y dron,
    a mano o en automático según la fase del vuelo, con barridos lentos.
  - Grabar el vídeo en MP4 con la Xbox Game Bar de Windows (Win+Alt+R) sin salir del juego.

Usa su propia conexión SimConnect (aparte de la de telemetría).
"""
import ctypes
import json
import math
import random
import struct
import sys
import threading
import time
from ctypes import byref, c_char_p, c_void_p, c_uint32, c_float, POINTER
from pathlib import Path

BASE = Path(__file__).resolve().parent
CINE_DIR = BASE / "Cine"                       # carpeta propia de SimDirect para tus vuelos
REC_DIR = CINE_DIR / "Repeticiones"           # grabaciones del vuelo (para repetirlas)
VID_DIR = CINE_DIR / "Videos"                 # vídeos MP4 de tus vuelos


def ensure_dirs():
    """Crea Cine\\Repeticiones y Cine\\Videos y trae las grabaciones de versiones anteriores."""
    REC_DIR.mkdir(parents=True, exist_ok=True)
    VID_DIR.mkdir(parents=True, exist_ok=True)
    old = BASE / "grabaciones"
    if old.is_dir():
        for p in old.glob("*.json"):
            try:
                p.replace(REC_DIR / p.name)
            except OSError:
                pass
        try:
            old.rmdir()
        except OSError:
            pass

USER = 0                     # SIMCONNECT_OBJECT_ID_USER
F64 = 4                      # SIMCONNECT_DATATYPE_FLOAT64
REC_FIELDS = [               # (simvar, unidades)
    ("PLANE LATITUDE", "degrees"), ("PLANE LONGITUDE", "degrees"), ("PLANE ALTITUDE", "feet"),
    ("PLANE PITCH DEGREES", "degrees"), ("PLANE BANK DEGREES", "degrees"), ("PLANE HEADING DEGREES TRUE", "degrees"),
    ("GROUND VELOCITY", "knots"), ("SIM ON GROUND", "bool"), ("GEAR HANDLE POSITION", "bool"),
    ("FLAPS HANDLE INDEX", "number"), ("SPOILERS HANDLE POSITION", "percent over 100"),
    ("VERTICAL SPEED", "feet per minute"), ("AIRSPEED INDICATED", "knots"), ("PLANE ALT ABOVE GROUND", "feet"),
]
KEYS = ["lat", "lon", "alt", "pitch", "bank", "hdg", "gs", "gnd", "gear", "flaps", "spl", "vs", "ias", "agl"]
POS_FIELDS = REC_FIELDS[:6]
SYS_FIELDS = [("GEAR HANDLE POSITION", "bool"), ("FLAPS HANDLE INDEX", "number"), ("SPOILERS HANDLE POSITION", "percent over 100")]
ANGLE = {"pitch", "bank", "hdg"}

# variables de cámara (MSFS 2024, se pueden escribir)
CAM_VARS = {
    "state": ("CAMERA STATE", "enum"),
    "vtype": ("CAMERA VIEW TYPE AND INDEX:0", "enum"),
    "vidx": ("CAMERA VIEW TYPE AND INDEX:1", "number"),
    "chase_zoom": ("CHASE CAMERA ZOOM", "percent"),
    "chase_head": ("CHASE CAMERA HEADLOOK", "enum"),
    "drone_follow": ("DRONE CAMERA FOLLOW", "bool"),
    "drone_locked": ("DRONE CAMERA LOCKED", "bool"),
    "drone_fov": ("DRONE CAMERA FOV", "percent"),
    "dc_yaw": ("DIRECTORS CUT CAMERA YAW", "percent"),
    "dc_pitch": ("DIRECTORS CUT CAMERA PITCH", "percent"),
    "cockpit_zoom": ("COCKPIT CAMERA ZOOM", "percent"),
}

# planos de cámara: nombre -> (etiqueta, ajustes, animación opcional)
SHOTS = {
    "persecucion": ("Persecución", {"state": 3, "vtype": 0, "chase_zoom": 45}, None),
    "persecucion_lejos": ("Persecución lejana", {"state": 3, "vtype": 0, "chase_zoom": 85}, None),
    "persecucion_cerca": ("Persecución cerca", {"state": 3, "vtype": 0, "chase_zoom": 15}, None),
    "cabina": ("Cabina", {"state": 2, "vtype": 1, "vidx": 0, "cockpit_zoom": 50}, None),
    "cabina_amplia": ("Cabina panorámica", {"state": 2, "vtype": 1, "vidx": 0, "cockpit_zoom": 15}, None),
    "ala": ("Cámara fija 1 (ala)", {"state": 4, "vtype": 5, "vidx": 0}, None),
    "cola": ("Cámara fija 2", {"state": 4, "vtype": 5, "vidx": 1}, None),
    "tren": ("Cámara fija 3", {"state": 4, "vtype": 5, "vidx": 2}, None),
    "fija4": ("Cámara fija 4", {"state": 4, "vtype": 5, "vidx": 3}, None),
    "barrido": ("Barrido lento", {"state": 4, "vtype": 5, "vidx": 0, "dc_pitch": 50}, ("dc_yaw", 20, 80)),
    "dron": ("Dron siguiendo", {"state": 8, "drone_follow": 1, "drone_locked": 1, "drone_fov": 45}, None),
    "dron_tele": ("Dron teleobjetivo", {"state": 8, "drone_follow": 1, "drone_locked": 1, "drone_fov": 15}, None),
}
# qué planos quedan bien en cada fase
PHASE_SHOTS = {
    "tierra": ["persecucion_cerca", "cabina", "tren", "ala", "dron_tele", "persecucion"],
    "despegue": ["persecucion_lejos", "tren", "dron_tele", "ala", "cabina_amplia"],
    "subida": ["ala", "barrido", "persecucion", "dron", "cabina_amplia"],
    "crucero": ["barrido", "persecucion_lejos", "ala", "dron", "cola", "cabina"],
    "descenso": ["persecucion", "ala", "barrido", "cabina_amplia", "dron"],
    "aterrizaje": ["cabina", "persecucion_lejos", "tren", "dron_tele", "ala"],
}


# ------------------------------------------------------------------ utilidades (sin SimConnect)
def lerp_angle(a, b, f):
    d = (b - a + 180) % 360 - 180
    return a + d * f


def sample_at(frames, t):
    """Estado interpolado en el segundo t de la grabación."""
    if not frames:
        return None
    if t <= frames[0]["t"]:
        return dict(frames[0])
    if t >= frames[-1]["t"]:
        return dict(frames[-1])
    lo, hi = 0, len(frames) - 1
    while hi - lo > 1:
        m = (lo + hi) // 2
        if frames[m]["t"] <= t:
            lo = m
        else:
            hi = m
    a, b = frames[lo], frames[hi]
    f = (t - a["t"]) / max(1e-6, b["t"] - a["t"])
    out = {"t": t}
    for k in KEYS:
        if k in ANGLE:
            out[k] = lerp_angle(a[k], b[k], f)
        elif k in ("gnd", "gear", "flaps"):
            out[k] = a[k] if f < 0.5 else b[k]
        else:
            out[k] = a[k] + (b[k] - a[k]) * f
    return out


def phase_of(s):
    if s["gnd"] >= 0.5:
        return "despegue" if s["gs"] > 40 else "tierra"
    if s["agl"] < 1500 and s["vs"] < -200:
        return "aterrizaje"
    if s["agl"] < 2500 and s["vs"] > 200:
        return "despegue"
    if s["vs"] > 400:
        return "subida"
    if s["vs"] < -400:
        return "descenso"
    return "crucero"


def highlights(frames):
    """Momentos destacados: despegue, toma, virajes, máxima altitud, puesta de gases…"""
    out = []
    if len(frames) < 3:
        return out
    last_kind_t = {}

    def add(kind, label, t):
        if t - last_kind_t.get(kind, -999) > 20:
            last_kind_t[kind] = t
            out.append({"t": round(max(0.0, t), 1), "kind": kind, "label": label})

    for a, b in zip(frames, frames[1:]):
        if a["gnd"] >= 0.5 and b["gnd"] < 0.5 and b["gs"] > 30:
            add("despegue", "Despegue", b["t"] - 8)
        if a["gnd"] < 0.5 and b["gnd"] >= 0.5:
            fpm = min(f["vs"] for f in frames if b["t"] - 2 <= f["t"] <= b["t"])
            add("toma", f"Toma de contacto ({abs(fpm):.0f} fpm)", b["t"] - 10)
        if abs(b["bank"]) > 25 and abs(a["bank"]) <= 25 and b["gnd"] < 0.5:
            add("viraje", f"Viraje de {abs(b['bank']):.0f}°", b["t"] - 3)
        if a["gear"] >= 0.5 and b["gear"] < 0.5 and b["gnd"] < 0.5:
            add("tren", "Tren arriba", b["t"] - 3)
        if a["gear"] < 0.5 and b["gear"] >= 0.5 and b["gnd"] < 0.5:
            add("tren", "Tren abajo", b["t"] - 3)
    top = max(frames, key=lambda f: f["alt"])
    if top["gnd"] < 0.5 and top["alt"] - frames[0]["alt"] > 3000:
        add("crucero", f"Crucero ({top['alt']:.0f} ft)", top["t"])
    out.sort(key=lambda h: h["t"])
    return out


def list_recordings():
    ensure_dirs()
    out = []
    for p in sorted(REC_DIR.glob("*.json"), key=lambda p: p.stat().st_mtime, reverse=True):
        try:
            meta = json.loads(p.read_text(encoding="utf-8")).get("meta", {})
        except (OSError, ValueError):
            continue
        out.append({"name": p.stem, "duration": meta.get("duration", 0), "date": meta.get("date", ""),
                    "frames": meta.get("frames", 0), "title": meta.get("title", p.stem)})
    return out


def load_recording(name):
    p = REC_DIR / (Path(name).name + ".json")
    d = json.loads(p.read_text(encoding="utf-8"))
    frames = [dict(zip(["t"] + KEYS, row)) for row in d["frames"]]
    return d.get("meta", {}), frames


# ------------------------------------------------------------------ vídeos grabados (MP4)
VIDEO_EXT = {".mp4", ".mkv", ".mov", ".webm"}


def capture_dirs():
    """Donde guarda la Xbox Game Bar (Vídeos\\Capturas). De ahí se traen a Cine\\Videos."""
    dirs = []
    if sys.platform == "win32":
        try:
            import uuid
            guid = uuid.UUID("18989B1D-99B5-455B-841C-AB7C74E4DDFC").bytes_le       # FOLDERID_Videos
            p = ctypes.c_wchar_p()
            if ctypes.windll.shell32.SHGetKnownFolderPath(ctypes.c_char_p(guid), 0, None, ctypes.byref(p)) == 0:
                dirs.append(Path(p.value) / "Captures")
                ctypes.windll.ole32.CoTaskMemFree(p)
        except Exception:  # noqa: BLE001
            pass
    d = Path.home() / "Videos" / "Captures"
    if d not in dirs:
        dirs.append(d)
    return dirs


def video_dirs():
    return [VID_DIR]


def collect_videos():
    """Mueve los vídeos de MSFS de Vídeos\\Capturas a Cine\\Videos (cuando ya están terminados)."""
    ensure_dirs()
    moved = 0
    for d in capture_dirs():
        if not d.is_dir():
            continue
        for p in d.iterdir():
            if p.suffix.lower() not in VIDEO_EXT or "flight simulator" not in p.name.lower():
                continue
            try:
                if time.time() - p.stat().st_mtime < 8:        # todavía se está grabando
                    continue
                dst = VID_DIR / p.name
                n = 1
                while dst.exists():
                    dst = VID_DIR / f"{p.stem} ({n}){p.suffix}"
                    n += 1
                import shutil
                shutil.move(str(p), str(dst))
                moved += 1
            except OSError:
                continue                                       # abierto por la Game Bar: luego
    return moved


def list_videos():
    ensure_dirs()
    out = []
    for p in VID_DIR.iterdir():
        if p.suffix.lower() in VIDEO_EXT and p.is_file():
            st = p.stat()
            out.append({"name": p.name, "size": st.st_size, "mtime": st.st_mtime,
                        "date": time.strftime("%d/%m/%Y %H:%M", time.localtime(st.st_mtime)), "msfs": True})
    out.sort(key=lambda v: v["mtime"], reverse=True)
    return out


def find_video(name):
    name = Path(name).name                    # nunca rutas: solo el nombre del archivo
    for d in video_dirs():
        p = d / name
        if p.suffix.lower() in VIDEO_EXT and p.is_file():
            return p
    return None


# ------------------------------------------------------------------ SimConnect (ctypes)
class SimConnectLink:
    DEF_REC, DEF_POS, DEF_SYS, REQ_REC = 501, 502, 503, 5101
    EV_BASE = 600
    EVENTS = ["FREEZE_LATITUDE_LONGITUDE_SET", "FREEZE_ALTITUDE_SET", "FREEZE_ATTITUDE_SET"]

    def __init__(self):
        import SimConnect
        dll = ctypes.WinDLL(str(Path(SimConnect.__file__).parent / "SimConnect.dll"))
        L = ctypes.c_long
        dll.SimConnect_Open.restype = L
        dll.SimConnect_Open.argtypes = [POINTER(c_void_p), c_char_p, c_void_p, c_uint32, c_void_p, c_uint32]
        dll.SimConnect_Close.argtypes = [c_void_p]
        dll.SimConnect_AddToDataDefinition.restype = L
        dll.SimConnect_AddToDataDefinition.argtypes = [c_void_p, c_uint32, c_char_p, c_char_p, c_uint32, c_float, c_uint32]
        dll.SimConnect_RequestDataOnSimObject.restype = L
        dll.SimConnect_RequestDataOnSimObject.argtypes = [c_void_p, c_uint32, c_uint32, c_uint32, c_uint32, c_uint32,
                                                          c_uint32, c_uint32, c_uint32]
        dll.SimConnect_SetDataOnSimObject.restype = L
        dll.SimConnect_SetDataOnSimObject.argtypes = [c_void_p, c_uint32, c_uint32, c_uint32, c_uint32, c_uint32, c_void_p]
        dll.SimConnect_MapClientEventToSimEvent.restype = L
        dll.SimConnect_MapClientEventToSimEvent.argtypes = [c_void_p, c_uint32, c_char_p]
        dll.SimConnect_TransmitClientEvent.restype = L
        dll.SimConnect_TransmitClientEvent.argtypes = [c_void_p, c_uint32, c_uint32, c_uint32, c_uint32, c_uint32]
        dll.SimConnect_GetNextDispatch.restype = L
        dll.SimConnect_GetNextDispatch.argtypes = [c_void_p, POINTER(c_void_p), POINTER(c_uint32)]
        self.dll = dll
        self.h = c_void_p()
        if dll.SimConnect_Open(byref(self.h), b"SimDirectCine", None, 0, None, 0) != 0:
            raise RuntimeError("MSFS no está abierto")
        for name, unit in REC_FIELDS:
            dll.SimConnect_AddToDataDefinition(self.h, self.DEF_REC, name.encode(), unit.encode(), F64, 0.0, 0xFFFFFFFF)
        for name, unit in POS_FIELDS:
            dll.SimConnect_AddToDataDefinition(self.h, self.DEF_POS, name.encode(), unit.encode(), F64, 0.0, 0xFFFFFFFF)
        for name, unit in SYS_FIELDS:
            dll.SimConnect_AddToDataDefinition(self.h, self.DEF_SYS, name.encode(), unit.encode(), F64, 0.0, 0xFFFFFFFF)
        self.cam_def = {}
        for i, (k, (name, unit)) in enumerate(CAM_VARS.items()):
            did = 520 + i
            dll.SimConnect_AddToDataDefinition(self.h, did, name.encode(), unit.encode(), F64, 0.0, 0xFFFFFFFF)
            self.cam_def[k] = did
        for i, ev in enumerate(self.EVENTS):
            dll.SimConnect_MapClientEventToSimEvent(self.h, self.EV_BASE + i, ev.encode())
        self.last = None
        self.stream = False

    def close(self):
        try:
            self.dll.SimConnect_Close(self.h)
        except Exception:  # noqa: BLE001
            pass

    def start_stream(self):
        # SIMCONNECT_PERIOD_SIM_FRAME = 3, cada 2 fotogramas
        self.dll.SimConnect_RequestDataOnSimObject(self.h, self.REQ_REC, self.DEF_REC, USER, 3, 0, 0, 2, 0)
        self.stream = True

    def stop_stream(self):
        self.dll.SimConnect_RequestDataOnSimObject(self.h, self.REQ_REC, self.DEF_REC, USER, 0, 0, 0, 0, 0)
        self.stream = False

    def pump(self):
        """Lee todos los mensajes pendientes; guarda el último estado del avión en self.last."""
        n = 0
        while n < 200:
            p, size = c_void_p(), c_uint32()
            if self.dll.SimConnect_GetNextDispatch(self.h, byref(p), byref(size)) != 0 or not p.value:
                break
            n += 1
            raw = ctypes.string_at(p.value, size.value)
            if len(raw) < 12:
                continue
            rid = struct.unpack_from("<I", raw, 8)[0]
            if rid == 3:                                   # SIMCONNECT_RECV_ID_QUIT
                raise RuntimeError("MSFS se ha cerrado")
            if rid == 8 and len(raw) >= 40 + 8 * len(KEYS):
                req = struct.unpack_from("<I", raw, 12)[0]
                if req == self.REQ_REC:
                    self.last = dict(zip(KEYS, struct.unpack_from("<" + "d" * len(KEYS), raw, 40)))

    def set_def(self, did, values):
        buf = struct.pack("<" + "d" * len(values), *values)
        cb = ctypes.create_string_buffer(buf, len(buf))
        self.dll.SimConnect_SetDataOnSimObject(self.h, did, USER, 0, 0, len(buf), cb)

    def set_pose(self, s):
        self.set_def(self.DEF_POS, [s["lat"], s["lon"], s["alt"], s["pitch"], s["bank"], s["hdg"]])

    def set_systems(self, s):
        self.set_def(self.DEF_SYS, [round(s["gear"]), round(s["flaps"]), s["spl"]])

    def freeze(self, on):
        for i in range(len(self.EVENTS)):
            self.dll.SimConnect_TransmitClientEvent(self.h, USER, self.EV_BASE + i, 1 if on else 0, 1, 0x10)

    def cam(self, key, value):
        if key in self.cam_def:
            self.set_def(self.cam_def[key], [float(value)])


# ------------------------------------------------------------------ Game Bar (grabar vídeo)
def _msfs_in_front():
    if sys.platform != "win32":
        return False
    from ctypes import wintypes
    u, k = ctypes.windll.user32, ctypes.windll.kernel32
    pid = wintypes.DWORD()
    u.GetWindowThreadProcessId(u.GetForegroundWindow(), byref(pid))
    h = k.OpenProcess(0x1000, False, pid.value)
    if not h:
        return False
    try:
        buf = ctypes.create_unicode_buffer(520)
        n = wintypes.DWORD(520)
        k.QueryFullProcessImageNameW(h, 0, buf, byref(n))
        return buf.value.lower().endswith(("flightsimulator2024.exe", "flightsimulator.exe"))
    finally:
        k.CloseHandle(h)


def _press(vks):
    u = ctypes.windll.user32
    for v in vks:
        u.keybd_event(v, u.MapVirtualKeyW(v, 0), 0, 0)
        time.sleep(0.03)
    time.sleep(0.06)
    for v in reversed(vks):
        u.keybd_event(v, u.MapVirtualKeyW(v, 0), 2, 0)
        time.sleep(0.03)


# ------------------------------------------------------------------ el estudio de cine
class Studio:
    def __init__(self, link_factory=SimConnectLink):
        self.link_factory = link_factory
        self.link = None
        self.lock = threading.RLock()
        self.mode = "idle"            # idle | rec | play
        self.frames = []
        self.rec_t0 = 0.0
        self.play = None              # {name, frames, meta, t, speed, paused, hl, restore}
        self.auto = {"on": False, "interval": 7.0, "next": 0.0, "shot": None, "anim": None}
        self.video = {"recording": False, "pending": None, "since": 0}
        self.msg = ""
        self.err = ""
        self.thread = threading.Thread(target=self._loop, daemon=True)
        self.thread.start()

    # ---- conexión
    def _need_link(self):
        if self.link is None:
            self.link = self.link_factory()
            self.link.start_stream()
        return self.link

    def _drop_link(self):
        if self.link:
            try:
                self.link.stop_stream()
            except Exception:  # noqa: BLE001
                pass
            self.link.close()
        self.link = None

    # ---- acciones
    def rec_start(self, title=""):
        with self.lock:
            if self.mode == "play":
                self.play_stop()
            self._need_link()
            self.frames, self.rec_t0, self.mode = [], time.time(), "rec"
            self.rec_title = title.strip()
            self.msg = "Grabando el vuelo…"
            return True

    def rec_stop(self):
        with self.lock:
            if self.mode != "rec":
                return None
            self.mode = "idle"
            fr = self.frames
            self.frames = []
            if len(fr) < 10:
                self.msg = "La grabación era demasiado corta"
                return None
            ensure_dirs()
            name = time.strftime("vuelo_%Y%m%d_%H%M%S")
            meta = {"date": time.strftime("%d/%m/%Y %H:%M"), "duration": round(fr[-1]["t"], 1), "frames": len(fr),
                    "title": self.rec_title or time.strftime("Vuelo del %d/%m %H:%M")}
            rows = [[round(f["t"], 3)] + [round(f[k], 7 if k in ("lat", "lon") else 3) for k in KEYS] for f in fr]
            (REC_DIR / (name + ".json")).write_text(json.dumps({"meta": meta, "frames": rows}), encoding="utf-8")
            self.msg = f"Grabación guardada ({meta['duration']:.0f} s)"
            return name

    def play_start(self, name, t=0.0, speed=1.0):
        with self.lock:
            if self.mode == "rec":
                self.rec_stop()
            meta, frames = load_recording(name)
            link = self._need_link()
            restore = None
            for _ in range(20):            # guarda dónde estabas para devolverte al terminar
                link.pump()
                if link.last:
                    restore = dict(link.last)
                    break
                time.sleep(0.05)
            if self.play is None:
                link.freeze(True)
            self.play = {"name": name, "frames": frames, "meta": meta, "t": float(t), "speed": float(speed),
                         "paused": False, "hl": highlights(frames), "restore": restore or (self.play or {}).get("restore"),
                         "sys_t": 0.0}
            self.mode = "play"
            self.msg = f"Reproduciendo «{meta.get('title', name)}»"
            return True

    def play_control(self, paused=None, speed=None, t=None):
        with self.lock:
            if not self.play:
                return False
            if paused is not None:
                self.play["paused"] = bool(paused)
            if speed is not None:
                self.play["speed"] = max(0.1, min(8.0, float(speed)))
            if t is not None:
                self.play["t"] = max(0.0, min(self.play["meta"].get("duration", 0), float(t)))
                self.play["sys_t"] = 0.0
            return True

    def play_stop(self, restore=True):
        with self.lock:
            if not self.play:
                return False
            link = self.link
            try:
                if restore and self.play.get("restore") and link:
                    r = self.play["restore"]
                    link.set_pose(r)
                    link.set_systems(r)
                    time.sleep(0.15)
                if link:
                    link.freeze(False)
            except Exception:  # noqa: BLE001
                pass
            self.play = None
            self.mode = "idle"
            self.msg = "Has vuelto a tu vuelo" if restore else "Control devuelto aquí"
            return True

    def shot(self, key):
        with self.lock:
            if key not in SHOTS:
                return False
            link = self._need_link()
            label, sets, anim = SHOTS[key]
            for k, v in sets.items():
                link.cam(k, v)
            self.auto["shot"] = key
            self.auto["anim"] = (anim, time.time()) if anim else None
            self.msg = "Plano: " + label
            return True

    def set_auto(self, on, interval=None):
        with self.lock:
            self.auto["on"] = bool(on)
            if interval:
                self.auto["interval"] = max(3.0, min(30.0, float(interval)))
            self.auto["next"] = 0.0
            if on:
                self._need_link()
            self.msg = "Director automático activado" if on else "Director automático apagado"
            return True

    def video_toggle(self):
        """Arranca/para la grabación de vídeo de la Xbox Game Bar en cuanto MSFS está delante."""
        with self.lock:
            self.video["pending"] = "stop" if self.video["recording"] else "start"
            self.video["since"] = time.time()
            self.msg = "Vuelve a la ventana de MSFS: el vídeo empezará solo" if self.video["pending"] == "start" \
                else "Vuelve a la ventana de MSFS para parar el vídeo"
            return self.video["pending"]

    def delete(self, name):
        p = REC_DIR / (Path(name).name + ".json")
        if p.exists():
            p.unlink()
            return True
        return False

    def state(self):
        with self.lock:
            p = self.play
            out = {"mode": self.mode, "msg": self.msg, "err": self.err, "connected": self.link is not None,
                   "rec_seconds": round(time.time() - self.rec_t0, 1) if self.mode == "rec" else 0,
                   "auto": {"on": self.auto["on"], "interval": self.auto["interval"], "shot": self.auto["shot"]},
                   "video": {"recording": self.video["recording"], "pending": self.video["pending"]},
                   "shots": [{"key": k, "label": v[0]} for k, v in SHOTS.items()]}
            if p:
                out["play"] = {"name": p["name"], "title": p["meta"].get("title", p["name"]), "t": round(p["t"], 2),
                               "duration": p["meta"].get("duration", 0), "speed": p["speed"], "paused": p["paused"],
                               "highlights": p["hl"]}
            return out

    # ---- bucle principal (≈30 Hz)
    def _loop(self):
        last = time.time()
        while True:
            time.sleep(1 / 30)
            now = time.time()
            dt, last = now - last, now
            try:
                self._video_tick()
                with self.lock:
                    link = self.link
                    if not link:
                        continue
                    link.pump()
                    if self.mode == "rec" and link.last:
                        t = now - self.rec_t0
                        if not self.frames or t - self.frames[-1]["t"] >= 0.04:
                            self.frames.append({"t": t, **link.last})
                    if self.mode == "play" and self.play:
                        p = self.play
                        dur = p["meta"].get("duration", 0)
                        if not p["paused"]:
                            p["t"] += dt * p["speed"]
                            if p["t"] >= dur:
                                p["t"], p["paused"] = dur, True
                                self.msg = "Fin de la grabación (pulsa Volver a mi vuelo)"
                        s = sample_at(p["frames"], p["t"])
                        link.set_pose(s)
                        if now - p["sys_t"] > 0.5:
                            link.set_systems(s)
                            p["sys_t"] = now
                        self._director(s, now)
                    elif self.auto["on"] and link.last:
                        self._director(link.last, now)
                    self._anim(now)
                    if self.mode == "idle" and not self.auto["on"] and not self.auto.get("anim"):
                        self._drop_link()
                self.err = ""
            except Exception as exc:  # noqa: BLE001
                self.err = str(exc)
                with self.lock:
                    self.play = None
                    if self.mode == "play":
                        self.mode = "idle"
                    self._drop_link()
                time.sleep(2)

    def _director(self, s, now):
        if not self.auto["on"] or now < self.auto["next"]:
            return
        opts = [k for k in PHASE_SHOTS[phase_of(s)] if k != self.auto["shot"]]
        key = random.choice(opts)
        label, sets, anim = SHOTS[key]
        for k, v in sets.items():
            self.link.cam(k, v)
        self.auto["shot"] = key
        self.auto["anim"] = (anim, now) if anim else None
        self.auto["next"] = now + self.auto["interval"] * random.uniform(0.8, 1.25)

    def _anim(self, now):
        a = self.auto.get("anim")
        if not a or not self.link:
            return
        (var, v0, v1), t0 = a
        f = min(1.0, (now - t0) / max(3.0, self.auto["interval"]))
        f = f * f * (3 - 2 * f)                     # suave al empezar y al terminar
        self.link.cam(var, v0 + (v1 - v0) * f)
        if f >= 1.0:
            self.auto["anim"] = None

    def _video_tick(self):
        v = self.video
        if not v["pending"]:
            return
        if time.time() - v["since"] > 120:
            v["pending"] = None
            return
        if _msfs_in_front():
            time.sleep(0.5)
            _press([0x5B, 0x12, 0x52])             # Win + Alt + R (Xbox Game Bar)
            v["recording"] = v["pending"] == "start"
            v["pending"] = None
            self.msg = "Grabando vídeo (Win+Alt+R para parar). Irá a la carpeta Cine\\Videos de SimDirect" if v["recording"] \
                else "Vídeo guardado: aparecerá en «Mis vídeos» en unos segundos"


STUDIO = None


def studio():
    global STUDIO
    if STUDIO is None:
        STUDIO = Studio()
    return STUDIO
