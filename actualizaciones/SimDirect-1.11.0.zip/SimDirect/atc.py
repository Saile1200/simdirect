#!/usr/bin/env python3
"""
SimDirect - avisos de ATC.

Según la fase del vuelo y dónde estás, dice con qué dependencia tienes que hablar y en qué
frecuencia (autorización, rodadura, torre, salidas, aproximación, ATIS...). Las frecuencias
salen de OurAirports (dominio público) y, si eliges VATSIM o IVAO, de los controladores que
están conectados en ese momento. La frecuencia se puede poner en el COM1 del avión.
"""
import csv
import math
import threading
import time

import aeropuertos as AP

_lock = threading.Lock()
_freqs = None
ONLINE = {"vatsim": {}, "ivao": {}}      # red -> {"LEBL_TWR": "118.100", ...}

KIND = {  # tipo de OurAirports -> (nuestro tipo, nombre en español)
    "CLD": ("DEL", "Autorización"), "DEL": ("DEL", "Autorización"), "CLNC": ("DEL", "Autorización"),
    "GND": ("GND", "Rodadura"), "TWR": ("TWR", "Torre"), "APP": ("APP", "Aproximación"),
    "DEP": ("DEP", "Salidas"), "ATIS": ("ATIS", "ATIS"), "ATIS DEP": ("ATIS", "ATIS salidas"),
    "ATIS ARR": ("ATIS", "ATIS llegadas"), "CTAF": ("RDO", "Frecuencia de tráfico"), "UNIC": ("RDO", "Unicom"),
    "A/D": ("RDO", "Radio"), "AFIS": ("RDO", "Información (AFIS)"), "A/G": ("RDO", "Radio"), "INFO": ("RDO", "Información"),
    "RDO": ("RDO", "Radio"), "CNTR": ("CTR", "Control"), "ACC": ("CTR", "Control"), "RDR": ("APP", "Radar"),
}
ORDER = ["ATIS", "DEL", "GND", "TWR", "DEP", "APP", "CTR", "RDO"]


def load():
    global _freqs
    with _lock:
        if _freqs is not None:
            return _freqs
        try:
            fn = AP._download("airport-frequencies.csv")
        except Exception as exc:  # noqa: BLE001
            print(f"[!] No pude descargar las frecuencias: {exc}", flush=True)
            return {}
        out = {}
        with open(fn, encoding="utf-8", errors="ignore", newline="") as fh:
            for row in csv.DictReader(fh):
                t = (row.get("type") or "").upper().strip()
                k = KIND.get(t)
                if not k:
                    continue
                try:
                    mhz = float(row.get("frequency_mhz") or 0)
                except ValueError:
                    continue
                if not 108 <= mhz <= 137:
                    continue
                out.setdefault((row.get("airport_ident") or "").upper(), []).append(
                    {"type": k[0], "label": k[1], "desc": (row.get("description") or "").strip()[:30], "mhz": f"{mhz:.3f}"})
        _freqs = out
        print(f"[OK] Frecuencias de aeropuertos: {len(out)}", flush=True)
        return out


def _city(code):
    a = AP.airport(code) or {}
    try:
        return AP.nice_name(a) if a else code
    except Exception:  # noqa: BLE001
        return a.get("city") or code


def freqs_for(code, net=None):
    """Frecuencias de un aeropuerto, con las de los controladores online primero."""
    if not code:
        return []
    out = []
    online = ONLINE.get(net or "", {})
    for cs, mhz in online.items():
        if not cs.startswith(code + "_"):
            continue
        suf = cs.rsplit("_", 1)[-1]
        t = {"DEL": "DEL", "GND": "GND", "TWR": "TWR", "APP": "APP", "DEP": "DEP", "ATIS": "ATIS", "CTR": "CTR"}.get(suf)
        if t:
            out.append({"type": t, "label": KIND.get(t, (t, t))[1] if t != "CTR" else "Control", "desc": cs, "mhz": mhz, "online": True})
    for f in load().get(code, []):
        if not any(o["type"] == f["type"] and o.get("online") for o in out):
            out.append(dict(f))
    out.sort(key=lambda f: (ORDER.index(f["type"]) if f["type"] in ORDER else 99, not f.get("online")))
    return out


def _nm(a, b):
    k = math.cos(math.radians((a["lat"] + b["lat"]) / 2))
    return math.hypot(a["lat"] - b["lat"], (a["lon"] - b["lon"]) * k) * 60


class Radio:
    def __init__(self):
        self.state = {"ver": 0}
        self.last_key = None
        self.t = 0.0
        self.net = None

    def update(self, d, phase, plan, net=None):
        """d: telemetría; phase: fase del diario; plan: {"dep": código, "arr": código}."""
        now = time.time()
        if now - self.t < 2:
            return
        self.t = now
        self.net = net if net in ("vatsim", "ivao") else None
        here = AP.nearest(d["lat"], d["lon"], 3.0)
        dep, arr = (plan or {}).get("dep"), (plan or {}).get("arr")
        arr_ap = AP.airport(arr) if arr else None
        dist_arr = _nm(d, arr_ap) if arr_ap and arr_ap.get("lat") is not None else None
        agl = d.get("agl", 0)
        want, code = [], None
        if phase in ("parked", "taxi_out", "unknown") and d.get("on_ground"):
            code = here["code"] if here else dep
            want = ["DEL", "GND", "TWR", "RDO"] if phase == "parked" else ["GND", "TWR", "RDO"]
        elif phase == "takeoff":
            code = (here or {}).get("code") or dep
            want = ["TWR", "RDO"]
        elif phase in ("climb",) and agl < 12000:
            code = dep or (here or {}).get("code")
            want = ["DEP", "APP", "TWR", "RDO"]
        elif phase in ("landing", "taxi_in"):
            code = (here or {}).get("code") or arr
            want = ["GND", "TWR", "RDO"]
        elif dist_arr is not None and dist_arr < 15 and agl < 4000:
            code, want = arr, ["TWR", "APP", "RDO"]
        elif dist_arr is not None and dist_arr < 60:
            code, want = arr, ["APP", "DEP", "TWR", "RDO"]
        elif dist_arr is not None and dist_arr < 120 and phase in ("descent", "approach"):
            code, want = arr, ["ATIS", "APP"]
        elif phase == "approach":
            near = AP.nearest(d["lat"], d["lon"], 25.0, max_rank=2)
            code, want = (near or {}).get("code"), ["APP", "TWR", "RDO"]
        lst = freqs_for(code, self.net) if code else []
        pick = next((f for w in want for f in lst if f["type"] == w), None)
        if pick is None:
            pick = {"type": "UNI", "label": "Unicom", "desc": "Sin control en tu zona", "mhz": "122.800", "online": False}
            place = "Unicom"
        else:
            place = f"{_city(code)} {pick['label']}" if pick["type"] != "RDO" else f"{_city(code)} {pick['label'].lower()}"
        atis = next((f for f in lst if f["type"] == "ATIS"), None)
        key = (code, pick["type"], pick["mhz"])
        ver = self.state.get("ver", 0) + (1 if key != self.last_key else 0)
        self.last_key = key
        self.state = {"ver": ver, "airport": code, "phase": phase, "net": self.net,
                      "now": {**pick, "name": place}, "atis": atis,
                      "list": lst[:14], "plan": {"dep": dep, "arr": arr}}

    def status(self):
        return self.state


RADIO = Radio()


def parse_vatsim_controllers(j):
    out = {}
    for c in (j.get("controllers") or []) + (j.get("atis") or []):
        cs, f = (c.get("callsign") or "").upper(), c.get("frequency") or ""
        if cs and f and f != "199.998":
            out[cs] = f"{float(f):.3f}"
    return out


def parse_ivao_controllers(j):
    out = {}
    clients = j.get("clients") or {}
    for c in (clients.get("atcs") or []):
        cs = (c.get("callsign") or "").upper()
        f = (c.get("atcSession") or {}).get("frequency")
        if cs and f:
            out[cs] = f"{float(f):.3f}"
    return out
