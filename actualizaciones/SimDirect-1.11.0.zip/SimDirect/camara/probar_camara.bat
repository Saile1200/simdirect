@echo off
chcp 65001 >nul
cd /d "%~dp0\.."
call instalar.bat || exit /b 1
call .venv\Scripts\activate.bat
python camara\camara_fisica.py --prueba
pause
