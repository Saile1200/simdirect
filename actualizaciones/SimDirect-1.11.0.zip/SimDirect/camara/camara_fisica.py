#!/usr/bin/env python3
"""
SimDirect - Física de cámara de cabina ultrarrealista para MSFS 2024.

Lee del simulador las fuerzas y el estado del avión y mueve la cabeza del piloto como un
cuerpo real (cabeza ~5 kg sobre un cuello elástico):
  - inercia al acelerar / frenar / rotar, hundimiento con G sostenidas
  - inclinación y mirada hacia el interior en los virajes
  - golpe de aterrizaje proporcional a la velocidad vertical al tocar
  - rodadura: temblor según velocidad + golpes periódicos de juntas de pista
  - turbulencia (sacudidas reales del simulador)
  - temblor de pérdida (stall buffet), vibración de spoilers y por sobrevelocidad
  - vibración de motores

Se envía a OpenTrack por UDP (puerto 4242) y OpenTrack lo pasa a MSFS como TrackIR.
Los ajustes se leen de camara_ajustes.json (la app SimDirect los cambia con deslizadores).

Uso:
    python camara_fisica.py           -> modo normal (conecta con MSFS)
    python camara_fisica.py --prueba  -> la cámara se mueve sola para comprobar OpenTrack
"""
import json
import math
import random
import socket
import struct
import sys
import threading
import time
from pathlib import Path

AJUSTES_FILE = Path(__file__).resolve().parent / "camara_ajustes.json"
AJUSTES_DEFECTO = {
    "general": 1.0,      # todo junto
    "g": 1.0,            # aceleraciones, frenadas, rebotes
    "virajes": 1.0,      # inclinación y mirada en los virajes
    "pista": 1.0,        # temblor y juntas al rodar
    "aterrizaje": 1.0,   # golpe al tocar tierra
    "buffet": 1.0,       # pérdida, spoilers, sobrevelocidad
    "motor": 0.5,        # vibración de motores
    "suavidad": 1.0,     # >1 más lento y suave, <1 más rápido y seco
}
OPENTRACK_IP = "127.0.0.1"
OPENTRACK_PUERTO = 4242
FPS = 90
MAX_DESPLAZ_CM = 7.0
MAX_GIRO_GRADOS = 8.0

SIMVARS = {
    "ax": ("ACCELERATION BODY X", "feet per second squared"),   # lateral (+ derecha)
    "ay": ("ACCELERATION BODY Y", "feet per second squared"),   # vertical (+ arriba)
    "az": ("ACCELERATION BODY Z", "feet per second squared"),   # longitudinal (+ adelante)
    "rx": ("ROTATION VELOCITY BODY X", "radians per second"),   # cabeceo
    "ry": ("ROTATION VELOCITY BODY Y", "radians per second"),   # guiñada
    "rz": ("ROTATION VELOCITY BODY Z", "radians per second"),   # alabeo
    "bank": ("PLANE BANK DEGREES", "degrees"),
    "gs": ("GROUND VELOCITY", "knots"),
    "vs": ("VERTICAL SPEED", "feet per minute"),
    "ground": ("SIM ON GROUND", "bool"),
    "eng": ("GENERAL ENG COMBUSTION:1", "bool"),
    "stall": ("STALL WARNING", "bool"),
    "overspeed": ("OVERSPEED WARNING", "bool"),
    "spoilers": ("SPOILERS HANDLE POSITION", "percent over 100"),
    "paused": ("SIM DISABLED", "bool"),
}
G = 32.174  # ft/s²

ajustes = dict(AJUSTES_DEFECTO)


def cargar_ajustes():
    global ajustes
    try:
        data = json.loads(AJUSTES_FILE.read_text(encoding="utf-8"))
        nuevo = dict(AJUSTES_DEFECTO)
        nuevo.update({k: float(v) for k, v in data.items() if k in AJUSTES_DEFECTO})
        ajustes = nuevo
    except (OSError, ValueError):
        pass


class Muelle:
    """Muelle-amortiguador de 2º orden: la cabeza sigue al objetivo con inercia y un pequeño rebote."""

    def __init__(self, frecuencia, amortiguacion):
        self.f, self.z = frecuencia, amortiguacion
        self.x = self.v = 0.0

    def paso(self, objetivo, dt, impulso=0.0):
        w = self.f / max(0.3, ajustes["suavidad"])
        self.v += impulso
        # integración en sub-pasos para que sea estable con cualquier FPS
        n = max(1, int(dt * w * 4) + 1)
        h = dt / n
        for _ in range(n):
            a = w * w * (objetivo - self.x) - 2 * self.z * w * self.v
            self.v += a * h
            self.x += self.v * h
        return self.x


class PasoAlto:
    """Quita poco a poco la parte constante: el cuerpo se adapta a una fuerza sostenida."""

    def __init__(self, segundos):
        self.tau, self.base = segundos, 0.0

    def paso(self, valor, dt):
        self.base += (valor - self.base) * min(1.0, dt / self.tau)
        return valor - self.base


class Ruido:
    """Ruido suave (interpolado) a una frecuencia dada en Hz."""

    def __init__(self, hz):
        self.hz, self.t = hz, 0.0
        self.a, self.b = random.uniform(-1, 1), random.uniform(-1, 1)

    def paso(self, dt, hz=None):
        self.t += dt * (hz or self.hz)
        while self.t >= 1.0:
            self.t -= 1.0
            self.a, self.b = self.b, random.uniform(-1, 1)
        s = self.t * self.t * (3 - 2 * self.t)
        return self.a + (self.b - self.a) * s


def limitar(v, m):
    return max(-m, min(m, v))


class Fisica:
    def __init__(self):
        # cuello: lateral, vertical, adelante/atrás, cabeceo, alabeo, guiñada
        self.mx, self.my, self.mz = Muelle(5.0, 0.45), Muelle(6.5, 0.40), Muelle(4.5, 0.50)
        self.mpitch, self.mroll, self.myaw = Muelle(5.0, 0.50), Muelle(3.5, 0.60), Muelle(1.2, 0.90)
        self.hx, self.hz = PasoAlto(2.5), PasoAlto(3.5)
        self.hy_rapido = PasoAlto(0.6)     # baches/turbulencia
        self.hroll = PasoAlto(4.0)
        self.n1, self.n2, self.n3 = Ruido(9), Ruido(14), Ruido(6)
        self.buf1, self.buf2 = Ruido(11), Ruido(17)
        self.motor = Ruido(32)
        self.en_tierra = True
        self.vs_previo = 0.0
        self.junta = 0.0                   # distancia recorrida hasta la próxima junta de pista
        self.g_sostenida = 1.0

    def calcular(self, d, dt):
        a = ajustes
        gen = a["general"]
        kg = gen * a["g"]
        tocando = bool(d["ground"])
        # parado en tierra: MSFS manda pequeñas aceleraciones "falsas" del tren de aterrizaje
        # (el avión parece vibrar). Se ignoran y se recuperan poco a poco al empezar a rodar.
        mov = 1.0 if not tocando else min(1.0, max(0.0, (d["gs"] - 1.0) / 8.0))
        zm = lambda v: math.copysign(max(0.0, abs(v) - 0.03), v)       # zona muerta de 0,03 G
        gx = zm(d["ax"] / G) * mov
        gy = zm((d["ay"] / G) if not tocando else d["ay"] / G) * mov
        gz = zm(d["az"] / G) * mov

        impulso_y = impulso_pitch = 0.0
        # ---------- aterrizaje: golpe según la velocidad vertical justo antes de tocar
        if tocando and not self.en_tierra:
            fpm = abs(min(0.0, self.vs_previo))
            golpe = min(1.0, fpm / 600.0)            # 600 fpm = toma muy dura
            impulso_y = -(0.6 + 9.0 * golpe) * gen * a["aterrizaje"]
            impulso_pitch = (4.0 + 25.0 * golpe) * gen * a["aterrizaje"]
        self.en_tierra = tocando
        if not tocando:
            self.vs_previo = d["vs"]

        # ---------- inercia (lo que siente el cuerpo)
        lat = self.hx.paso(gx, dt)
        lon = self.hz.paso(gz, dt)
        bache = self.hy_rapido.paso(gy, dt)
        # G vertical sostenida (tirar en un viraje cerrado): la cabeza se hunde un poco
        carga = 1.0 / max(0.2, math.cos(math.radians(min(80.0, abs(d["bank"]))))) if not tocando else 1.0
        self.g_sostenida += (carga - self.g_sostenida) * min(1.0, dt / 1.5)
        hundimiento = -(self.g_sostenida - 1.0) * 1.8 * kg

        x = self.mx.paso(-lat * 6.0 * kg, dt)
        y = self.my.paso(-bache * 6.0 * kg + hundimiento, dt, impulso_y)
        z = self.mz.paso(-lon * 9.0 * kg, dt)

        # ---------- rotaciones de cabeza
        vroll = self.hroll.paso(math.degrees(d["rz"]) * mov, dt)
        kv = gen * a["virajes"]
        roll = self.mroll.paso(-vroll * 0.07 * kv - lat * 3.0 * kg, dt)
        pitch = self.mpitch.paso(lon * 3.5 * kg + bache * 2.0 * kg - math.degrees(d["rx"]) * 0.05 * kg * mov,
                                 dt, impulso_pitch)
        # el piloto mira ligeramente hacia el interior del viraje (como en la realidad)
        mirar = 0.0 if tocando else limitar(-d["bank"] * 0.12, 6.0)
        yaw = self.myaw.paso(mirar * kv, dt)

        # ---------- rodadura en tierra
        if tocando and d["gs"] > 1.5:
            kp = gen * a["pista"]
            v = min(1.0, d["gs"] / 90.0)
            hz = 5 + 10 * v
            y += self.n1.paso(dt, hz) * 0.45 * v * kp
            pitch += self.n2.paso(dt, hz * 1.3) * 0.35 * v * kp
            roll += self.n3.paso(dt, hz * 0.7) * 0.30 * v * kp
            # juntas de las losas de hormigón (aprox. cada 15 m)
            self.junta += d["gs"] * 0.5144 * dt
            if self.junta > 15.0:
                self.junta -= 15.0
                self.my.paso(self.my.x, 0.0, -0.25 * (0.4 + v) * kp)

        # ---------- buffet: pérdida, spoilers en vuelo, sobrevelocidad
        kb = gen * a["buffet"]
        nivel = 0.0
        if d["stall"] and not tocando and d["gs"] > 30:   # en tierra el aviso de pérdida no cuenta
            nivel += 1.0
        if not tocando and d["spoilers"] > 0.05:
            nivel += 0.35 * d["spoilers"] * min(1.0, d["gs"] / 200.0)
        if d["overspeed"] and not tocando:
            nivel += 0.6
        if nivel > 0:
            y += self.buf1.paso(dt) * 0.5 * nivel * kb
            pitch += self.buf2.paso(dt) * 0.6 * nivel * kb
            roll += self.buf1.paso(dt * 0.7) * 0.4 * nivel * kb

        # ---------- motores
        if d["eng"]:
            # muy suave parado (no debe parecer que tiembla el avión); algo más al rodar o en vuelo
            m = self.motor.paso(dt) * (0.015 + 0.045 * mov) * gen * a["motor"]
            y += m
            pitch += m * 0.6

        return (limitar(x, MAX_DESPLAZ_CM), limitar(y, MAX_DESPLAZ_CM), limitar(z, MAX_DESPLAZ_CM),
                limitar(yaw, MAX_GIRO_GRADOS), limitar(pitch, MAX_GIRO_GRADOS), limitar(roll, MAX_GIRO_GRADOS))

    def reposo(self, dt):
        return (self.mx.paso(0, dt), self.my.paso(0, dt), self.mz.paso(0, dt),
                self.myaw.paso(0, dt), self.mpitch.paso(0, dt), self.mroll.paso(0, dt))


# ------------------------------------------------------------------ lectura del simulador
datos = None
datos_lock = threading.Lock()


def lector_msfs():
    global datos
    try:
        from SimConnect import SimConnect
        try:
            from SimConnect import Request
        except ImportError:
            from SimConnect.RequestList import Request
    except Exception as exc:
        print(f"[!] Falta la librería SimConnect ({exc}). Ejecuta iniciar_camara.bat.")
        return
    avisado = False
    while True:
        sm = None
        try:
            sm = SimConnect()
            reqs = {k: Request((n.encode(), u.encode()), sm, _time=10) for k, (n, u) in SIMVARS.items()}
            print("[OK] Conectado a MSFS. Física de cámara activa.")
            avisado = False
            fallos = 0
            while True:
                raw = {k: r.value for k, r in reqs.items()}
                if raw["ax"] is None:
                    fallos += 1
                    if fallos > 50:
                        raise RuntimeError("el simulador no responde")
                    time.sleep(0.02)
                    continue
                fallos = 0
                d = {k: float(v or 0) for k, v in raw.items()}
                with datos_lock:
                    datos = d
                time.sleep(1 / 45)
        except Exception as exc:
            with datos_lock:
                datos = None
            if not avisado:
                print(f"[i] Esperando a MSFS... ({exc})")
                avisado = True
            try:
                if sm:
                    sm.exit()
            except Exception:
                pass
            time.sleep(3)


def datos_prueba(t):
    """Secuencia inventada: rodaje y despegue, virajes, turbulencia, pérdida y aterrizaje."""
    base = {"ax": 0, "ay": 0, "az": 0, "rx": 0, "ry": 0, "rz": 0, "bank": 0, "gs": 0, "vs": 0,
            "ground": 1, "eng": 1, "stall": 0, "overspeed": 0, "spoilers": 0, "paused": 0}
    c = t % 30
    if c < 6:                                   # carrera de despegue
        base.update(az=8.0, gs=20 + c * 22)
    elif c < 12:                                # virajes alternos
        s = math.sin((c - 6) * 1.1)
        base.update(ground=0, gs=250, ax=s * 9, rz=s * 0.25, bank=s * 30)
    elif c < 18:                                # turbulencia
        base.update(ground=0, gs=280, ay=random.uniform(-9, 9), ax=random.uniform(-3, 3))
    elif c < 22:                                # pérdida
        base.update(ground=0, gs=120, stall=1)
    elif c < 24:                                # aproximación final a -700 fpm
        base.update(ground=0, gs=140, vs=-700)
    else:                                       # toma y frenada
        base.update(ground=1, gs=max(0, 140 - (c - 24) * 25), az=-6 if c < 28 else 0)
    return base


# ------------------------------------------------------------------ salidas
class SalidaOpenTrack:
    """Envía la pose a OpenTrack por UDP (si prefieres usar OpenTrack abierto)."""
    nombre = "OpenTrack (UDP 4242)"

    def __init__(self):
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)

    def enviar(self, pose):
        self.sock.sendto(struct.pack("<6d", *pose), (OPENTRACK_IP, OPENTRACK_PUERTO))

    def cerrar(self):
        self.enviar((0, 0, 0, 0, 0, 0))


class SalidaDirecta:
    """
    Habla directamente con MSFS como un TrackIR (protocolo FreeTrack/NPClient), sin abrir OpenTrack.
    Usa la memoria compartida "FT_SharedMem" que lee NPClient64.dll (incluida en la carpeta seguimiento).
    """
    nombre = "Directo a MSFS (TrackIR)"
    FT = struct.Struct("<Iii20f")         # FTData: DataID, CamWidth, CamHeight, 20 floats
    SIZE = FT.size + 4 + 8 + 4             # + GameID + table[8] + GameID2

    def __init__(self, info):
        import ctypes
        import mmap
        import winreg
        self.info = info
        self.k32 = ctypes.windll.kernel32
        self.mutex = self.k32.CreateMutexW(None, False, "FT_Mutext")
        self.mem = mmap.mmap(-1, self.SIZE, tagname="FT_SharedMem")
        self.mem[:] = b"\0" * self.SIZE
        struct.pack_into("<Iii", self.mem, 0, 1, 100, 250)
        path = info["dir"].replace("\\", "/").rstrip("/") + "/"
        for sub in (r"Software\NaturalPoint\NATURALPOINT\NPClient Location", r"Software\Freetrack\FreetrackClient"):
            with winreg.CreateKey(winreg.HKEY_CURRENT_USER, sub) as k:
                winreg.SetValueEx(k, "Path", 0, winreg.REG_SZ, path)
        self.game_id = 0
        self.data_id = 1
        self.dummy = None
        if info.get("trackir"):
            try:
                import subprocess
                self.dummy = subprocess.Popen([info["trackir"]], creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
            except OSError:
                self.dummy = None

    def tabla_juego(self, gid):
        csv = self.info.get("csv")
        if not csv:
            return b"\0" * 8
        try:
            for line in open(csv, encoding="utf-8", errors="ignore"):
                c = line.rstrip("\r\n").split(";")
                if len(c) == 8 and c[6].strip() == str(gid) and c[3] != "V160" and len(c[7]) == 22:
                    b = [int(c[7][i:i + 2], 16) for i in range(0, 22, 2)]
                    # mismo orden que opentrack: fuzz, fuzz, t3, t2, t1, t0, t7, t6, t5, t4, fuzz
                    t = [0] * 8
                    t[3], t[2], t[1], t[0], t[7], t[6], t[5], t[4] = b[2:10]
                    return bytes(t)
        except OSError:
            pass
        return b"\0" * 8

    def enviar(self, pose):
        x, y, z, yaw, pitch, roll = pose
        d2r = math.pi / 180
        # misma conversión que opentrack: grados -> radianes, cm -> mm
        vals = (-yaw * d2r, -pitch * d2r, roll * d2r, x * 10, y * 10, z * 10)
        struct.pack_into("<6f", self.mem, 12, *vals)
        struct.pack_into("<6f", self.mem, 36, *vals)
        gid = struct.unpack_from("<i", self.mem, self.FT.size)[0]
        if gid != self.game_id:
            self.mem[self.FT.size + 4:self.FT.size + 12] = self.tabla_juego(gid)
            struct.pack_into("<i", self.mem, self.FT.size + 12, gid)
            self.data_id = 0
            self.game_id = gid
            print(f"[OK] Juego conectado al seguimiento de cabeza (id {gid})", flush=True)
        else:
            self.data_id = (self.data_id + 1) & 0xFFFFFFFF
        struct.pack_into("<I", self.mem, 0, self.data_id)

    def cerrar(self):
        try:
            self.enviar((0, 0, 0, 0, 0, 0))
            if self.dummy:
                self.dummy.terminate()
        except Exception:  # noqa: BLE001
            pass


def elegir_salida():
    cfg = {}
    try:
        cfg = json.loads((Path(__file__).resolve().parent.parent / "config.json").read_text(encoding="utf-8"))
    except (OSError, ValueError):
        pass
    if sys.platform == "win32" and cfg.get("camera_output", "directo") == "directo":
        info = cfg.get("tracking")
        if not info:
            try:
                sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
                import herramientas
                info = herramientas.find_tracking_files()
            except Exception:  # noqa: BLE001
                info = None
        if info:
            try:
                return SalidaDirecta(info)
            except Exception as exc:  # noqa: BLE001
                print(f"[!] Modo directo no disponible ({exc}); uso OpenTrack UDP", flush=True)
        else:
            print("[!] Faltan los archivos de seguimiento (instálalos en Configurar). Uso OpenTrack UDP.", flush=True)
    return SalidaOpenTrack()


def main():
    prueba = "--prueba" in sys.argv
    fis = Fisica()
    cargar_ajustes()
    salida = elegir_salida()
    print("=" * 56)
    print("  SimDirect · Física de cámara de cabina")
    print(f"  Salida: {salida.nombre}")
    print("  MODO PRUEBA: la cámara se moverá sola" if prueba else "  Esperando a MSFS 2024…")
    print("=" * 56, flush=True)
    if not prueba:
        threading.Thread(target=lector_msfs, daemon=True).start()

    dt = 1.0 / FPS
    t0 = last = ultimo_ajuste = time.perf_counter()
    try:
        while True:
            now = time.perf_counter()
            paso = min(0.05, now - last)
            last = now
            if now - ultimo_ajuste > 1.0:
                cargar_ajustes()
                ultimo_ajuste = now
            if prueba:
                d = datos_prueba(now - t0)
            else:
                with datos_lock:
                    d = datos
            pose = fis.reposo(paso) if d is None or d.get("paused") else fis.calcular(d, paso)
            salida.enviar(pose)
            time.sleep(max(0.0, dt - (time.perf_counter() - now)))
    except KeyboardInterrupt:
        pass
    finally:
        salida.cerrar()
        print("\nCámara centrada.")


if __name__ == "__main__":
    main()
