# Física de cámara de cabina (SimDirect)

Hace que la vista de cabina se mueva como un cuerpo real:
- Al acelerar en el despegue, la cabeza se va hacia atrás; al frenar, hacia delante.
- En los virajes se inclina un poco y luego se adapta.
- En el aterrizaje hay un rebote proporcional a lo fuerte que toques.
- Con turbulencia, la cabeza se sacude.
- Rodando por pista tiembla según la velocidad, y con el motor encendido hay una vibración suave.

## Cómo funciona

El programa lee las fuerzas del avión desde MSFS y calcula el movimiento de la cabeza. Se lo envía a **OpenTrack** (gratuito), y OpenTrack se lo pasa a MSFS como si fuera un **TrackIR**.

## Instalación (una sola vez)

1. Descarga e instala **OpenTrack**: https://github.com/opentrack/opentrack/releases (el instalador `.exe` más reciente).
2. Abre OpenTrack y configura:
   - **Input**: `UDP over network`. Pulsa el botón de ajustes de al lado y comprueba que el puerto sea **4242**.
   - **Output**: `freetrack 2.0 Enhanced`. En sus ajustes elige **"Use TrackIR"** o "Enable both".
   - **Filter**: `Accela` o ninguno. Con el filtro desactivado la física se nota más.
   - En **Mapping**, deja las curvas en línea recta: X/Y/Z a 1:1 y Yaw/Pitch/Roll a 1:1.
3. En MSFS 2024: Opciones → General → Cámara, activa el **modo TrackIR**. Desactiva o baja el "movimiento de cabeza" o "efecto G" propio del simulador para que no se sumen los dos.

## Uso

1. Abre OpenTrack y pulsa **Start**.
2. Ejecuta `iniciar_camara.bat`.
3. Abre MSFS 2024 y entra en la cabina.

Para comprobarlo sin volar, ejecuta `probar_camara.bat`: la cámara se mueve sola (aceleración, virajes y baches). Si en la ventana de OpenTrack ves moverse la cabeza del avioncito, la conexión funciona.

## Ajustar la intensidad

Abre `camara_fisica.py` con el Bloc de notas y cambia los valores de arriba:

```
INTENSIDAD_GENERAL = 1.0   # todo junto (0.5 = la mitad, 2 = el doble)
INTENSIDAD_G = 1.0         # aceleraciones, frenadas, rebotes
INTENSIDAD_VIRAJES = 1.0
INTENSIDAD_PISTA = 1.0     # temblor rodando
INTENSIDAD_MOTOR = 0.5
SUAVIDAD = 1.0             # más alto = movimiento más lento y suave
```

## Notas

- Si ya usas un TrackIR o una webcam con OpenTrack, ten en cuenta que OpenTrack solo admite una entrada a la vez. Este programa sustituye al seguimiento de cabeza mientras está activo.
- Si la cámara se mueve al revés en algún eje, márcalo como "Invert" en OpenTrack (Options → Output).
- Para centrar la vista, usa la tecla de centrado de OpenTrack o la de MSFS.
