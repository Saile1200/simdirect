"""
SimDirect - aviones que hay en MSFS a tu alrededor (jugadores del multijugador y tráfico),
leídos con SimConnect_RequestDataOnSimObjectType (radio de hasta 200 km).
Usa una conexión SimConnect propia, aparte de la de telemetría.
"""
import ctypes
import struct
import threading
import time
from ctypes import byref, c_char_p, c_void_p, c_uint32, c_float, c_double, POINTER

_lock = threading.Lock()
_cache = {"t": 0, "data": []}

# (nombre, unidades, tipo SIMCONNECT_DATATYPE, formato struct)
FIELDS = [
    ("PLANE LATITUDE", "degrees", 4, "d"),
    ("PLANE LONGITUDE", "degrees", 4, "d"),
    ("PLANE ALTITUDE", "feet", 4, "d"),
    ("PLANE HEADING DEGREES TRUE", "degrees", 4, "d"),
    ("GROUND VELOCITY", "knots", 4, "d"),
    ("IS USER SIM", "bool", 4, "d"),
    ("ATC ID", None, 6, "32s"),          # STRING32
    ("ATC AIRLINE", None, 7, "64s"),     # STRING64
    ("ATC FLIGHT NUMBER", None, 5, "8s"),  # STRING8
    ("TITLE", None, 8, "128s"),          # STRING128
]
FMT = "<" + "".join(f[3] for f in FIELDS)


def _dll():
    import SimConnect
    from pathlib import Path
    dll = ctypes.WinDLL(str(Path(SimConnect.__file__).parent / "SimConnect.dll"))
    dll.SimConnect_Open.restype = ctypes.c_long
    dll.SimConnect_Open.argtypes = [POINTER(c_void_p), c_char_p, c_void_p, c_uint32, c_void_p, c_uint32]
    dll.SimConnect_Close.argtypes = [c_void_p]
    dll.SimConnect_AddToDataDefinition.restype = ctypes.c_long
    dll.SimConnect_AddToDataDefinition.argtypes = [c_void_p, c_uint32, c_char_p, c_char_p, c_uint32, c_float, c_uint32]
    dll.SimConnect_RequestDataOnSimObjectType.restype = ctypes.c_long
    dll.SimConnect_RequestDataOnSimObjectType.argtypes = [c_void_p, c_uint32, c_uint32, c_uint32, c_uint32]
    dll.SimConnect_GetNextDispatch.restype = ctypes.c_long
    dll.SimConnect_GetNextDispatch.argtypes = [c_void_p, POINTER(c_void_p), POINTER(c_uint32)]
    return dll


def _txt(b):
    return b.split(b"\0")[0].decode("utf-8", "ignore").strip()


def fetch(radius_m=200000, timeout=4.0, cache_s=4):
    """Lista de aviones cercanos en MSFS (sin incluir el tuyo). Caché de unos segundos (cada lectura abre una conexión)."""
    if time.time() - _cache["t"] < cache_s:
        return _cache["data"]
    with _lock:
        dll = _dll()
        h = c_void_p()
        if dll.SimConnect_Open(byref(h), b"SimDirectTraffic", None, 0, None, 0) != 0:
            raise RuntimeError("MSFS no está abierto")
        out = []
        try:
            DEF, REQ = 91, 9101
            for name, unit, dtype, _ in FIELDS:
                dll.SimConnect_AddToDataDefinition(h, DEF, name.encode(), unit.encode() if unit else None, dtype, 0.0, 0xFFFFFFFF)
            # tipo 1 = SIMCONNECT_SIMOBJECT_TYPE_AIRCRAFT
            if dll.SimConnect_RequestDataOnSimObjectType(h, REQ, DEF, int(radius_m), 1) != 0:
                raise RuntimeError("Petición rechazada")
            need = struct.calcsize(FMT)
            t0, total, got = time.time(), None, 0
            while time.time() - t0 < timeout:
                p, size = c_void_p(), c_uint32()
                if dll.SimConnect_GetNextDispatch(h, byref(p), byref(size)) != 0 or not p.value:
                    if total is not None and got >= total:
                        break
                    time.sleep(0.01)
                    continue
                raw = ctypes.string_at(p.value, size.value)
                if len(raw) < 40:
                    continue
                dw_id = struct.unpack_from("<I", raw, 8)[0]
                if dw_id != 9:                  # SIMCONNECT_RECV_ID_SIMOBJECT_DATA_BYTYPE
                    continue
                req, obj, _def, _flags, entry, outof, _cnt = struct.unpack_from("<7I", raw, 12)
                if req != REQ:
                    continue
                total, got = outof, got + 1
                if outof == 0 or len(raw) < 40 + need:
                    continue
                v = struct.unpack_from(FMT, raw, 40)
                if v[5] >= 0.5:                  # es tu propio avión
                    continue
                atc, airline, fnum, title = _txt(v[6]), _txt(v[7]), _txt(v[8]), _txt(v[9])
                cs = (airline + " " + fnum).strip() if airline and fnum else atc
                out.append({"cs": cs or atc or "MSFS", "lat": v[0], "lon": v[1], "alt": v[2], "hdg": v[3], "gs": v[4],
                            "ac": title[:40], "dep": "", "arr": "", "net": "msfs", "id": obj})
                if got >= outof:
                    break
        finally:
            dll.SimConnect_Close(h)
        _cache.update(t=time.time(), data=out)
        return out
