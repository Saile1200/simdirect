@echo off
rem Prepara SimDirect la primera vez (lo llaman los otros .bat). Instala Python solo si falta.
cd /d "%~dp0"
if exist ".venv\Scripts\python.exe" goto deps

set "PY="
for %%V in (313 312 311 310) do (
  if not defined PY if exist "%LOCALAPPDATA%\Programs\Python\Python%%V\python.exe" set "PY=%LOCALAPPDATA%\Programs\Python\Python%%V\python.exe"
)
if not defined PY (
  py -3 --version >nul 2>nul && set "PY=py -3"
)
if not defined PY (
  python --version >nul 2>nul && set "PY=python"
)
if not defined PY (
  echo.
  echo  ====================================================
  echo   No tienes Python. Lo instalo automaticamente...
  echo   (tarda 1-2 minutos, no cierres esta ventana)
  echo  ====================================================
  echo.
  winget install -e --id Python.Python.3.12 --scope user --silent --accept-package-agreements --accept-source-agreements
  if exist "%LOCALAPPDATA%\Programs\Python\Python312\python.exe" set "PY=%LOCALAPPDATA%\Programs\Python\Python312\python.exe"
)
if not defined PY (
  echo.
  echo  No se pudo instalar Python automaticamente.
  echo  Instalalo desde https://www.python.org/downloads/ marcando "Add Python to PATH"
  echo  y vuelve a abrir iniciar_simdirect.bat
  echo.
  pause
  exit /b 1
)

echo Preparando SimDirect por primera vez...
%PY% -m venv .venv
if not exist ".venv\Scripts\python.exe" (
  echo No se pudo crear el entorno de Python.
  pause
  exit /b 1
)

:deps
if exist ".venv\.instalado_v5" exit /b 0
echo Instalando componentes (aiohttp, SimConnect)...
".venv\Scripts\python.exe" -m pip install --upgrade pip >nul 2>nul
".venv\Scripts\python.exe" -m pip install -r requirements.txt
if errorlevel 1 (
  echo.
  echo  Error instalando componentes. Comprueba tu conexion a internet y vuelve a intentarlo.
  pause
  exit /b 1
)
echo ok> ".venv\.instalado_v5"
exit /b 0
