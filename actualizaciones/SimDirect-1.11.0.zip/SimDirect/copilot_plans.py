"""
SimCopilot - crea planes de vuelo reales al instante a partir de lo que escribes
("plan de Madrid a Lisboa", "3 rutas de 1 hora desde Barcelona en avioneta"...),
usando la base mundial de aeropuertos. La IA solo añade la explicación.
"""
import math
import random
import re

import aeropuertos as AP

STOP = r"(?:\s+(?:en|con|y|por|para\s+(?:un|una|el|la)|a\s+las|que|usando|sobre)\b|[,.;?!]|$)"


def _gc_points(a, b, n):
    """n puntos intermedios sobre el círculo máximo entre a y b."""
    la1, lo1, la2, lo2 = map(math.radians, (a["lat"], a["lon"], b["lat"], b["lon"]))
    d = 2 * math.asin(math.sqrt(math.sin((la2 - la1) / 2) ** 2 + math.cos(la1) * math.cos(la2) * math.sin((lo2 - lo1) / 2) ** 2))
    pts = []
    for i in range(1, n + 1):
        f = i / (n + 1)
        A, B = math.sin((1 - f) * d) / math.sin(d), math.sin(f * d) / math.sin(d)
        x = A * math.cos(la1) * math.cos(lo1) + B * math.cos(la2) * math.cos(lo2)
        y = A * math.cos(la1) * math.sin(lo1) + B * math.cos(la2) * math.sin(lo2)
        z = A * math.sin(la1) + B * math.sin(la2)
        pts.append((math.degrees(math.atan2(z, math.hypot(x, y))), math.degrees(math.atan2(y, x))))
    return pts, math.degrees(d) * 60


def build_plan(dep, arr, ga):
    pts, dist = _gc_points(dep, arr, 1)
    step = 45 if ga else 120
    n = max(0, min(8, int(dist // step)))
    pts, dist = _gc_points(dep, arr, n) if n else ([], dist)
    city5 = lambda a: "".join(ch for ch in AP._norm(a.get("city", "")).upper() if ch.isalpha())[:5]
    used = {dep["code"], arr["code"], city5(dep), city5(arr)}
    wps = []
    for i, (la, lo) in enumerate(pts):
        name = AP.nearest_place(la, lo, 40 if ga else 80, used)
        if not name:   # mar abierto: punto por coordenadas, estilo OACI (p. ej. 4005N)
            name = f"{abs(round(la)):02d}{'N' if la >= 0 else 'S'}{abs(round(lo)):02d}"[:5]
            if name in used:
                name = f"PT{i + 1:02d}"
        used.add(name)
        wps.append({"name": name, "lat": round(la, 4), "lon": round(lo, 4)})
    if ga:
        alt = 3500 if dist < 60 else 5500 if dist < 150 else 7500
    else:
        alt = 16000 if dist < 120 else 24000 if dist < 250 else 33000 if dist < 500 else 37000
    short = AP.nice_name
    return {"name": f"{dep['code']}-{arr['code']}", "dep": {"code": dep["code"], "name": short(dep), "lat": dep["lat"], "lon": dep["lon"], "elev": dep.get("elev", 0)},
            "arr": {"code": arr["code"], "name": short(arr), "lat": arr["lat"], "lon": arr["lon"], "elev": arr.get("elev", 0)},
            "cruiseAlt": alt, "aircraft": "c172" if ga else "a320", "waypoints": wps, "_dist": round(dist)}


def _resolve_tail(words):
    """Prueba los finales de la frase (de más largo a más corto): 'vuelo de Madrid' -> 'Madrid'."""
    for i in range(len(words)):
        a = AP.resolve(" ".join(words[i:]))
        if a:
            return a
    return None


def _resolve_head(words, near=None, small=False):
    for j in range(len(words), 0, -1):
        a = AP.resolve(" ".join(words[:j]), near, small)
        if a:
            return a
    return None


def plans_from_text(text):
    t = " " + text.strip() + " "
    ga = bool(re.search(r"cessna|avioneta|\bvfr\b|c172|piper|ligera|visual", t, re.I))
    # 1) origen y destino: "de X a Y", "desde X hasta Y"
    m = re.search(r"(?:\bde|\bdesde)\s+(.+?)\s+(?:a|al|hasta|hacia|para|->|–)\s+(.+?)" + STOP, t, re.I)
    if m:
        dep = _resolve_tail(m.group(1).split())
        arr = _resolve_head(m.group(2).split(), (dep["lat"], dep["lon"]) if dep else None, ga)
        if dep and arr and dep["code"] != arr["code"]:
            return [build_plan(dep, arr, ga)]
    # 2) ideas: "3 rutas de 1 hora desde Barcelona"
    dur = re.search(r"(\d+(?:[.,]\d+)?)\s*(h\b|hora|horas|min|minutos)", t, re.I)
    src = re.search(r"(?:desde|saliendo de|\bde)\s+(.+?)" + STOP, t, re.I)
    if (dur or re.search(r"ruta|vuelo|idea|destino|plan", t, re.I)) and src:
        words = src.group(1).split()
        dep = None
        for j in range(len(words), 0, -1):          # 'Barcelona en Cessna' -> 'Barcelona'
            dep = _resolve_head(words[:j]) or _resolve_tail(words[:j])
            if dep:
                break
        if not dep:
            return None
        hours = 1.0
        if dur:
            v = float(dur.group(1).replace(",", "."))
            hours = v / 60 if dur.group(2).lower().startswith("m") else v
        cnt = re.search(r"(\d+)\s*(rutas|vuelos|ideas|planes|destinos|opciones)", t, re.I)
        k = max(1, min(5, int(cnt.group(1)) if cnt else 3))
        speed = 110 if ga else 430
        target = max(30, hours * speed * (0.85 if not ga else 0.95) - (0 if ga else 40))
        kinds = ("large_airport", "medium_airport") if ga else ("large_airport",)
        cands = AP.airports_around(dep["lat"], dep["lon"], target * 0.8, target * 1.2, kinds)
        if ga and len(cands) < k:
            cands = AP.airports_around(dep["lat"], dep["lon"], target * 0.6, target * 1.4, kinds + ("small_airport",))
        random.shuffle(cands)
        # destinos en direcciones distintas
        chosen, bearings = [], []
        for d, a in cands:
            br = math.degrees(math.atan2(a["lon"] - dep["lon"], a["lat"] - dep["lat"])) % 360
            if all(min(abs(br - b), 360 - abs(br - b)) > 50 for b in bearings):
                full = AP.airport(a["code"])
                if full:
                    chosen.append(full)
                    bearings.append(br)
            if len(chosen) >= k:
                break
        return [build_plan(dep, a, ga) for a in chosen] or None
    return None


# ------------------------------------------------------------------ pistas y SID/STAR
import json
import urllib.request


def metar(codes):
    """Viento real de los aeropuertos (aviationweather.gov, gratis y sin clave)."""
    out = {}
    try:
        url = "https://aviationweather.gov/api/data/metar?format=json&ids=" + ",".join(codes)
        req = urllib.request.Request(url, headers={"User-Agent": "SimDirect/1.6"})
        with urllib.request.urlopen(req, timeout=5) as r:
            for m in json.loads(r.read() or b"[]"):
                wd = m.get("wdir")
                out[m.get("icaoId")] = {"dir": wd if isinstance(wd, (int, float)) else None, "spd": m.get("wspd") or 0,
                                        "raw": m.get("rawOb", "")}
    except Exception as exc:  # noqa: BLE001
        print(f"[i] METAR no disponible: {exc}", flush=True)
    return out


def _bearing(a, b):
    la1, la2 = math.radians(a["lat"]), math.radians(b["lat"])
    dl = math.radians(b["lon"] - a["lon"])
    return (math.degrees(math.atan2(math.sin(dl) * math.cos(la2), math.cos(la1) * math.sin(la2) - math.sin(la1) * math.cos(la2) * math.cos(dl))) + 360) % 360


def _diff(a, b):
    d = abs(a - b) % 360
    return min(d, 360 - d)


def pick_runway(ap, want_hdg, wind, ga):
    """Pista según el viento real (o, sin viento, la más alineada con la ruta). Prefiere las largas."""
    ends = []
    for r in ap.get("runways") or []:
        if not ga and r.get("length_m", 0) and r["length_m"] < 1500:
            continue
        for e in r.get("ends") or []:
            m = re.match(r"(\d{1,2})", e or "")
            if m:
                ends.append((e, int(m.group(1)) * 10 % 360, r.get("length_m", 0)))
    if not ends:
        return None, ""
    if wind and wind.get("dir") is not None and wind.get("spd", 0) >= 4:
        ref, why = wind["dir"], f"viento {int(wind['dir']):03d}° a {int(wind['spd'])} kt"
    else:
        ref, why = want_hdg, "viento en calma" if wind else "según la ruta"
    best = min(ends, key=lambda x: (round(_diff(x[1], ref) / 40), -x[2]))
    return best[0], why


def add_procedures(plans, nav_fetch=None):
    """Añade pistas (viento real) y SID/STAR/aproximación (de MSFS si está abierto) a cada plan."""
    codes = sorted({c for p in plans for c in (p["dep"]["code"], p["arr"]["code"])})
    wx = metar(codes)
    navs = {}
    if nav_fetch:
        for c in codes:
            try:
                navs[c] = nav_fetch(c)
            except Exception as exc:  # noqa: BLE001
                print(f"[i] Procedimientos {c}: {exc}", flush=True)
    for p in plans:
        ga = p["aircraft"] == "c172"
        dep, arr = AP.airport(p["dep"]["code"]) or {}, AP.airport(p["arr"]["code"]) or {}
        first = p["waypoints"][0] if p["waypoints"] else p["arr"]
        last = p["waypoints"][-1] if p["waypoints"] else p["dep"]
        drw, dwhy = pick_runway(dep, _bearing(p["dep"], first), wx.get(p["dep"]["code"]), ga)
        arw, awhy = pick_runway(arr, _bearing(last, p["arr"]), wx.get(p["arr"]["code"]), ga)
        proc = {"depRwy": drw or "", "arrRwy": arw or "", "sid": "", "star": "", "appr": "", "sidTrans": "", "starTrans": ""}
        info = {"depWhy": dwhy, "arrWhy": awhy, "msfs": bool(navs), "metar": {k: v["raw"] for k, v in wx.items()}}
        if not ga:
            nd, na = navs.get(p["dep"]["code"]), navs.get(p["arr"]["code"])
            if nd:
                sids = [s for s in nd.get("sids", []) if not s.get("runways") or drw in s["runways"]]
                if sids:
                    proc["sid"] = sids[0]["name"]
            if na:
                stars = [s for s in na.get("stars", []) if not s.get("runways") or arw in s["runways"]]
                if stars:
                    proc["star"] = stars[0]["name"]
                aps = [a for a in na.get("approaches", []) if a.get("runway") == arw]
                aps.sort(key=lambda a: (0 if a["name"].upper().startswith("ILS") else 1, a["name"]))
                if aps:
                    proc["appr"] = aps[0]["name"] + " " + aps[0]["runway"]
        p["proc"], p["procInfo"] = proc, info
    return plans
