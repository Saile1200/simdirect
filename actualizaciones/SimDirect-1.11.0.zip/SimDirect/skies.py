#!/usr/bin/env python3
"""
SimDirect Skies: tiempo, atmósfera y luz para MSFS 2024.

  * Tiempo   -> escribe un preset de tiempo (.WPR) en la carpeta de presets de MSFS 2024.
                Aparece al final de la lista de tiempo del simulador como «SimDirect Skies · ...».
  * Imagen   -> genera el perfil de ReShade SimDirect_Skies.ini (exposición, color, neblina,
                tono, viñeta, grano y bandas de cine) y lo pone como activo.
  * Hora     -> mueve el reloj del simulador por SimConnect.

No toca ningún archivo del simulador: el preset va a la carpeta de usuario y «Restaurar»
lo quita y devuelve tu ReShade de antes.
"""
import json
import os
import re
from pathlib import Path
from xml.sax.saxutils import escape

import herramientas as H

DATA = H.BASE / "datos" / "skies"          # «datos» no se borra al actualizar
PRESETS_FILE = DATA / "mis_presets.json"
STATE_FILE = DATA / "estado.json"
RS_SKIES = "SimDirect_Skies.ini"
WPR_NAME = "SimDirect_Skies.WPR"

LIMITS = {
    "cover": (0, 100), "base": (500, 12000), "cirrus": (0, 100), "vis": (0.3, 50), "wind": (0, 60),
    "wdir": (0, 360), "temp": (-30, 45), "qnh": (960, 1050), "rain": (0, 100),
    "haze": (0, 100), "dust": (0, 100), "blue": (50, 150), "hum": (0, 100), "glow": (0, 200),
    "hour": (0, 24), "bright": (50, 150), "sat": (40, 160), "warm": (-50, 50), "contrast": (60, 140),
    "flare": (0, 100), "grain": (0, 100), "cine": (0, 1),
}
DEFAULTS = {"cover": 28, "base": 5000, "cirrus": 25, "vis": 35, "wind": 8, "wdir": 240, "temp": 20, "qnh": 1015,
            "rain": 0, "haze": 15, "dust": 0, "blue": 100, "hum": 50, "glow": 100, "hour": 13, "bright": 100,
            "sat": 104, "warm": 0, "contrast": 104, "flare": 15, "grain": 6, "cine": 0}


def clean(values):
    out = dict(DEFAULTS)
    for k, (lo, hi) in LIMITS.items():
        try:
            out[k] = max(lo, min(hi, float((values or {}).get(k, out[k]))))
        except (TypeError, ValueError):
            pass
    out["hour"] = out["hour"] % 24
    return out


def _read(p, default):
    try:
        return json.loads(Path(p).read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return default


def _write(p, data):
    Path(p).parent.mkdir(parents=True, exist_ok=True)
    Path(p).write_text(json.dumps(data, ensure_ascii=False, indent=1), encoding="utf-8")


def load_state():
    return _read(STATE_FILE, {"values": dict(DEFAULTS), "name": None, "auto": False, "applied": False})


def save_state(**kw):
    st = load_state()
    st.update(kw)
    _write(STATE_FILE, st)
    return st


def load_presets():
    return _read(PRESETS_FILE, [])


def save_presets(items):
    good = []
    for it in (items or [])[:60]:
        name = str(it.get("name", "")).strip()[:32]
        if name:
            good.append({"name": name, "v": clean(it.get("v"))})
    _write(PRESETS_FILE, good)
    return good


# ------------------------------------------------------------------ Tiempo (.WPR)
def weather_dirs(create=True):
    """Carpetas de presets de tiempo de MSFS 2024 (Steam y Microsoft Store)."""
    out = []
    appdata, local = os.environ.get("APPDATA"), os.environ.get("LOCALAPPDATA")
    roots = []
    if appdata:
        roots.append(Path(appdata) / "Microsoft Flight Simulator 2024")
    if local:
        roots.append(Path(local) / "Packages" / "Microsoft.Limitless_8wekyb3d8bbwe" / "LocalState")
    for root in roots:
        if root.is_dir():
            d = root / "Weather" / "Presets"
            if create:
                try:
                    d.mkdir(parents=True, exist_ok=True)
                except OSError:
                    continue
            if d.is_dir():
                out.append(d)
    return out


def _ft2m(ft):
    return ft * 0.3048


def build_wpr(v, name):
    """Preset de tiempo con 3 capas de nubes (MSFS 2024 necesita exactamente 3)."""
    cover, cir, rain = v["cover"] / 100, v["cirrus"] / 100, v["rain"] / 100
    storm = max(0.0, (v["rain"] - 55) / 45) if v["cover"] > 80 else 0.0
    snow = v["temp"] <= 1
    # neblina, calima y visibilidad -> aerosoles (más alto = menos transparente)
    vis_k = max(0.0, (12 - v["vis"]) / 12)
    aerosol = 1 + v["haze"] / 100 * 2.5 + v["dust"] / 100 * 6 + vis_k * 7

    layers = []
    if v["vis"] < 1.5:   # niebla: capa pegada al suelo
        fog = (1.5 - v["vis"]) / 1.2
        layers.append((0, 60 + 220 * fog, min(1, 0.55 + 0.45 * fog), 1.0))
    base = _ft2m(v["base"])
    if cover > 0.01:
        depth = 300 + cover * 1700 + storm * 7000
        layers.append((base, base + depth, 0.25 + cover * 0.65 + storm * 0.1, cover))
    else:
        layers.append((base, base + 300, 0.0, 0.0))
    if len(layers) < 2:   # capa media (si no hay niebla), solo con mucho cielo cubierto
        mid = max(layers[-1][1] + 600, 4200)
        dens = max(0.0, cover - 0.55) * 0.7
        layers.append((mid, mid + 900, dens, min(1, cover * 0.6) if dens else 0.0))
    layers.append((9000, 9900, cir * 0.45, cir))
    layers = layers[:3]

    def cloud(bot, top, dens, scat):
        return (f"        <CloudLayer>\n"
                f"            <CloudLayerAltitudeBot value=\"{bot:.1f}\" unit=\"m\"/>\n"
                f"            <CloudLayerAltitudeTop value=\"{top:.1f}\" unit=\"m\"/>\n"
                f"            <CloudLayerDensity value=\"{max(0, min(1, dens)):.3f}\" unit=\"(0 - 1)\"/>\n"
                f"            <CloudLayerScattering value=\"{max(0, min(1, scat)):.3f}\" unit=\"(0 - 1)\"/>\n"
                f"        </CloudLayer>\n")

    wd, ws = v["wdir"] % 360, v["wind"]
    gust = ""
    if ws > 18:
        gust = (f"            <GustWave>\n"
                f"                <GustWaveDuration value=\"3.0\" unit=\"sec\"/>\n"
                f"                <GustWaveInterval value=\"14.0\" unit=\"sec\"/>\n"
                f"                <GustWaveSpeed value=\"{ws * 1.35:.1f}\" unit=\"knts\"/>\n"
                f"                <GustAngle value=\"{wd:.1f}\" unit=\"degrees\"/>\n"
                f"            </GustWave>\n")

    def wind(alt, ang, spd, extra=""):
        return (f"        <WindLayer>\n"
                f"            <WindLayerAltitude value=\"{alt:.1f}\" unit=\"m\"/>\n"
                f"            <WindLayerAngle value=\"{ang % 360:.1f}\" unit=\"degrees\"/>\n"
                f"            <WindLayerSpeed value=\"{spd:.1f}\" unit=\"knts\"/>\n{extra}"
                f"        </WindLayer>\n")

    if storm > 0.2:
        live = "WEATHER_STORM"
    elif rain > 0.02:
        live = "WEATHER_RAIN"
    elif cover > 0.85:
        live = "WEATHER_OVERCAST"
    elif cover > 0.55:
        live = "WEATHER_BROKEN_CLOUDS"
    elif cover > 0.3:
        live = "WEATHER_SCATTERED"
    elif cover > 0.05:
        live = "WEATHER_FEW_CLOUDS"
    elif cir > 0.3:
        live = "WEATHER_HIGH_CLOUDS"
    else:
        live = "WEATHER_CLEAR_SKY"
    prec = 0.5 + rain * 30 if rain > 0.02 else 0.0
    title = escape(f"SimDirect Skies · {name}"[:60])
    return (
        "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n"
        "<SimBase.Document Type=\"WeatherPreset\" version=\"1,3\">\n"
        "    <Descr>AceXML Document</Descr>\n"
        "    <WeatherPreset.Preset>\n"
        f"        <Name>{title}</Name>\n"
        "        <Order>9</Order>\n"
        "        <IsAltitudeAMGL>True</IsAltitudeAMGL>\n"
        f"        <LiveID>{live}</LiveID>\n"
        f"        <MSLPressure value=\"{v['qnh'] * 100:.1f}\" unit=\"pa\"/>\n"
        f"        <MSLTemperature value=\"{v['temp'] + 273.15:.2f}\" unit=\"k\"/>\n"
        f"        <AerosolDensity value=\"{aerosol:.3f}\" unit=\"m\"/>\n"
        f"        <Precipitations value=\"{prec:.2f}\" unit=\"mm/h\"/>\n"
        f"        <PrecipitationType>{'SNOW' if snow else 'RAIN'}</PrecipitationType>\n"
        f"        <SnowCover value=\"{(0.25 if v['temp'] < -2 else 0.0):.2f}\" unit=\"m\"/>\n"
        f"        <ThunderstormIntensity value=\"{storm:.2f}\" unit=\"(0 - 1)\"/>\n"
        + "".join(cloud(*l) for l in layers)
        + wind(0, wd, ws, gust)
        + wind(1500, wd + 15, ws * 1.4 + 4)
        + wind(9000, wd + 30, ws * 2.2 + 20)
        + "    </WeatherPreset.Preset>\n"
        "</SimBase.Document>\n"
    )


def install_wpr(v, name):
    xml = build_wpr(v, name)
    done, errors = [], []
    for d in weather_dirs():
        try:
            (d / WPR_NAME).write_text(xml, encoding="utf-8")
            done.append(str(d))
        except OSError as exc:
            errors.append(f"{d}: {exc}")
    return done, errors


def remove_wpr():
    for d in weather_dirs(create=False):
        try:
            (d / WPR_NAME).unlink(missing_ok=True)
        except OSError:
            pass


# ------------------------------------------------------------------ Imagen (ReShade)
def build_reshade(v, user=None):
    """Perfil de ReShade con los efectos que instala SimDirect (reshade-shaders + SweetFX)."""
    user = user or {}
    f = lambda x: f"{x:.6f}"
    w = v["warm"] / 25.0
    haze, dust = v["haze"] / 100, v["dust"] / 100
    lift = (1 - 0.03 * w + haze * 0.035 + dust * 0.05, 1 - 0.01 * w + haze * 0.035 + dust * 0.03, 1 + 0.03 * w + haze * 0.04)
    gain = (1 + 0.03 * w + dust * 0.03, 1 + 0.01 * w + dust * 0.01, 1 - 0.02 * w - dust * 0.04)
    sharpen = float(user.get("sharpen", 0.45))
    techs = ["Deband@Deband.fx"] if float(user.get("deband", 0)) >= 0.5 else []
    techs += ["Tonemap@Tonemap.fx", "LiftGammaGain@LiftGammaGain.fx", "Vibrance@Vibrance.fx",
              "Curves@Curves.fx", "ContrastAdaptiveSharpen@CAS.fx", "Vignette@Vignette.fx"]
    if v["grain"] > 1:
        techs.append("FilmGrain@FilmGrain.fx")
    if v["cine"] >= 0.5:
        techs.append("Border@Border.fx")
    t = ",".join(techs)
    return f"""PreprocessorDefinitions=
Techniques={t}
TechniqueSorting={t}

[Border.fx]
border_color=0.000000,0.000000,0.000000
border_ratio=2.350000
border_width=0.000000,0.000000

[CAS.fx]
Contrast=0.000000
Sharpening={f(sharpen)}

[Curves.fx]
Contrast={f((v["contrast"] - 100) / 100 * 0.9)}
Formula=2
Mode=0

[Deband.fx]
banding_depth=1.000000
debug_output=0
enable_depthbuffer=0
enable_sdeviation=1
enable_weber=1
iterations=1
range=24.000000
t1=0.007000
t2=0.040000

[FilmGrain.fx]
Intensity={f(v["grain"] / 100 * 0.6)}
Mean=0.500000
SignalToNoiseRatio=6
Variance=0.400000

[LiftGammaGain.fx]
RGB_Gain={f(gain[0])},{f(gain[1])},{f(gain[2])}
RGB_Gamma=1.000000,1.000000,1.000000
RGB_Lift={f(lift[0])},{f(lift[1])},{f(lift[2])}

[Tonemap.fx]
Bleach=0.000000
Defog=0.000000
Exposure={f((v["bright"] - 100) / 100 * 0.5)}
FogColor=0.000000,0.000000,1.000000
Gamma={f(float(user.get("gamma", 1.0)))}
Saturation={f((v["sat"] - 100) / 100 * 0.8)}

[Vibrance.fx]
Vibrance={f(float(user.get("vibrance", 0.12)) + (v["sat"] - 100) / 400)}
VibranceRGBBalance=1.000000,1.000000,1.000000
Vibrance_Luma=0

[Vignette.fx]
Amount={f(-(0.15 + v["cine"] * 0.2 + v["grain"] / 400))}
Center=0.500000,0.500000
Radius=2.000000
Ratio=1.000000
Slope=2
Type=0
"""


# ------------------------------------------------------------------ aplicar / restaurar
def apply(v, name, parts, msfs_dir, rs_user, send_event, sim_live):
    """parts = {"weather": bool, "look": bool, "time": bool}. Devuelve un resumen para la app."""
    v = clean(v)
    name = (str(name or "").strip() or "Mi cielo")[:32]
    res = {"ok": True, "weather": None, "look": None, "time": None, "msgs": []}
    if parts.get("weather", True):
        done, errs = install_wpr(v, name)
        res["weather"] = bool(done)
        if done:
            res["msgs"].append(f"Tiempo: en MSFS abre el menú de tiempo y elige «SimDirect Skies · {name}» al final de la lista.")
        else:
            res["msgs"].append("Tiempo: no encontré la carpeta de MSFS 2024 en este PC." + (" " + errs[0] if errs else ""))
    if parts.get("look", True):
        if msfs_dir:
            cfg = H.load_config()
            if cfg.get("reshade_preset") != RS_SKIES:
                H.set_config(skies_prev_preset=cfg.get("reshade_preset") or "SimDirect_Personal.ini")
            ini = build_reshade(v, rs_user)
            try:
                (Path(msfs_dir) / RS_SKIES).write_text(ini, encoding="utf-8")
            except OSError:
                pass
            res["look"] = bool(H.set_reshade_preset(msfs_dir, RS_SKIES, ini))
            res["msgs"].append("Imagen: aplicada en ReShade, se ve al volver a la ventana de MSFS."
                               if res["look"] else "Imagen: no pude escribir en la carpeta de MSFS.")
        else:
            res["look"] = False
            res["msgs"].append("Imagen: instala ReShade en Configurar para cambiar color, neblina y grano.")
    if parts.get("time", True):
        if sim_live:
            h = int(v["hour"]) % 24
            m = int(round((v["hour"] - int(v["hour"])) * 60)) % 60
            send_event("CLOCK_HOURS_SET", h)
            send_event("CLOCK_MINUTES_SET", m)
            res["time"] = True
            res["msgs"].append(f"Hora: puesta a las {h:02d}:{m:02d} en el simulador.")
        else:
            res["time"] = False
            res["msgs"].append("Hora: entra en un vuelo de MSFS para cambiar la hora.")
    save_state(values=v, name=name, applied=True)
    res["ok"] = any(res[k] for k in ("weather", "look", "time"))
    return res


def reset(msfs_dir):
    remove_wpr()
    prev = H.load_config().get("skies_prev_preset") or "SimDirect_Personal.ini"
    ok = True
    if msfs_dir and H.load_config().get("reshade_preset") == RS_SKIES:
        ok = bool(H.set_reshade_preset(msfs_dir, prev) or H.set_reshade_preset(msfs_dir, "SimDirect_Realista.ini"))
    save_state(applied=False)
    return {"ok": ok, "msg": "Listo: tu ReShade de antes vuelve a estar activo. En MSFS elige «Tiempo en vivo»."}


def safe_name(s):
    return re.sub(r"[^\w\- áéíóúñÁÉÍÓÚÑ·]", "", str(s or "")).strip()[:32]
