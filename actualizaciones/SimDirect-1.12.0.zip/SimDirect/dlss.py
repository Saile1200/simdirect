#!/usr/bin/env python3
"""
SimDirect - DLSS automático: si el PC tiene una NVIDIA RTX, deja MSFS 2024 con DLSS puesto.

  * Mira la tarjeta gráfica (la línea «Video Adapter» de UserCfg.opt o, si no, Windows).
  * En UserCfg.opt pone AntiAliasing DLSS y el modo elegido (Calidad por defecto).
  * Con una RTX 40 o 50 enciende también la generación de fotogramas (DLSSG).
  * Solo toca las líneas de escritorio (las de VR acaban en «VR») y guarda una copia
    UserCfg.opt.simdirect.bak la primera vez.
  * MSFS reescribe UserCfg.opt al cerrarse, así que solo se cambia con el simulador cerrado;
    si está abierto, se aplica sola la próxima vez que abras SimDirect con MSFS cerrado.

DLSS usa siempre la versión que trae MSFS (la 4.5 desde el Sim Update 6). DLSS 5 no existe
todavía en MSFS: cuando llegue, esta misma opción lo usará sin cambiar nada.
"""
import os
import re
import shutil
import subprocess
import sys
from pathlib import Path

MODES = ("QUALITY", "BALANCED", "PERFORMANCE", "ULTRA_PERFORMANCE", "DLAA")
BACKUP_SUFFIX = ".simdirect.bak"


def usercfg_paths():
    """UserCfg.opt de MSFS 2024 (Steam y Microsoft Store), los que existan."""
    out = []
    appdata, local = os.environ.get("APPDATA"), os.environ.get("LOCALAPPDATA")
    if appdata:
        out.append(Path(appdata) / "Microsoft Flight Simulator 2024" / "UserCfg.opt")
    if local:
        out.append(Path(local) / "Packages" / "Microsoft.Limitless_8wekyb3d8bbwe" / "LocalCache" / "UserCfg.opt")
    return [p for p in out if p.exists()]


def _gpu_from_usercfg(text):
    m = re.search(r'Video\s*Adapter\s+"([^"]+)"', text, re.I)
    return m.group(1) if m else None


def _gpu_from_windows():
    if sys.platform != "win32":
        return []
    try:
        r = subprocess.run(["powershell", "-NoProfile", "-Command",
                            "(Get-CimInstance Win32_VideoController).Name"],
                           capture_output=True, text=True, timeout=10,
                           creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
        return [x.strip() for x in r.stdout.splitlines() if x.strip()]
    except (OSError, subprocess.SubprocessError):
        return []


def detect_gpu():
    """Nombre de la gráfica NVIDIA RTX del PC, o None si no hay."""
    names = []
    for p in usercfg_paths():
        try:
            g = _gpu_from_usercfg(p.read_text(encoding="utf-8", errors="replace"))
        except OSError:
            g = None
        if g:
            names.append(g)
    names += _gpu_from_windows()
    for n in names:
        if "nvidia" in n.lower() and "rtx" in n.lower():
            return n
    return None


def supports_frame_gen(gpu):
    """Generación de fotogramas: solo RTX 40xx y 50xx."""
    m = re.search(r"RTX\s*(\d{2})\d{2}", gpu or "", re.I)
    return bool(m and int(m.group(1)) >= 40)


def msfs_running():
    if sys.platform != "win32":
        return False
    try:
        r = subprocess.run(["tasklist", "/FI", "IMAGENAME eq FlightSimulator2024.exe", "/NH"],
                           capture_output=True, text=True, timeout=10,
                           creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
        return "flightsimulator2024.exe" in r.stdout.lower()
    except (OSError, subprocess.SubprocessError):
        return False


def _set(text, key, value):
    """Cambia «key valor» (no la versión VR). Si no existe, la añade tras AntiAliasing."""
    pat = re.compile(rf"^(\s*){key}(\s+)\S+[ \t]*$", re.M)
    if pat.search(text):
        return pat.sub(lambda m: f"{m.group(1)}{key}{m.group(2)}{value}", text)
    aa = re.compile(r"^(\s*)AntiAliasing\s+\S+[ \t]*$", re.M).search(text)
    if not aa:
        return text
    return text[:aa.end()] + f"\n{aa.group(1)}{key} {value}" + text[aa.end():]


def apply(mode="QUALITY", frame_gen=None):
    """Pone DLSS en MSFS. Devuelve (ok, mensaje)."""
    mode = mode if mode in MODES else "QUALITY"
    gpu = detect_gpu()
    if not gpu:
        return False, "No hay una NVIDIA RTX en este PC: DLSS no está disponible"
    if msfs_running():
        return False, "Cierra MSFS: DLSS se pondrá solo la próxima vez que abras SimDirect"
    paths = usercfg_paths()
    if not paths:
        return False, "No encuentro UserCfg.opt: abre MSFS 2024 una vez y vuelve a probar"
    fg = supports_frame_gen(gpu) if frame_gen is None else bool(frame_gen and supports_frame_gen(gpu))
    done = 0
    for p in paths:
        try:
            text = p.read_text(encoding="utf-8", errors="replace")
            if not re.search(r"^\s*AntiAliasing\s", text, re.M):
                continue
            new = _set(text, "AntiAliasing", "DLSS")
            new = _set(new, "DLSSMode", mode)
            new = _set(new, "DLSSG", "1" if fg else "0")
            if new != text:
                bak = p.with_name(p.name + BACKUP_SUFFIX)
                if not bak.exists():
                    shutil.copy2(p, bak)
                p.write_text(new, encoding="utf-8")
            done += 1
        except OSError:
            continue
    if not done:
        return False, "No se pudo cambiar UserCfg.opt"
    return True, f"DLSS puesto en MSFS ({gpu}{', con generación de fotogramas' if fg else ''})"


def status():
    gpu = detect_gpu()
    return {"gpu": gpu, "nvidia": bool(gpu), "frame_gen": supports_frame_gen(gpu)}
