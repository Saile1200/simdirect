#!/usr/bin/env python3
"""
SimDirect - servidor local que conecta Microsoft Flight Simulator 2024 (SimConnect)
con la interfaz web (plan de vuelo + mapa en vivo).

Ejecuta:  python server.py
Luego abre http://localhost:8765 (en el PC) o la IP que aparece en pantalla (móvil/tablet).
Si el simulador no está abierto, la app funciona en MODO DEMO con un avión simulado.
"""
import asyncio
import urllib.request
import json
import math
import re
import socket
import threading
import time
import webbrowser
from pathlib import Path

from aiohttp import web, WSMsgType

BASE = Path(__file__).resolve().parent
WEB_DIR = BASE / "web"
PLANS_DIR = BASE / "planes"          # planes guardados por la app (json)
PLN_DIR = BASE / "planes_msfs"       # planes exportados para cargar en MSFS (.pln)
PORT = 8765

# Variables del simulador que leemos: clave -> (nombre SimVar, unidades)
SIMVARS = {
    "lat": ("PLANE LATITUDE", "degrees"),
    "lon": ("PLANE LONGITUDE", "degrees"),
    "alt": ("PLANE ALTITUDE", "feet"),
    "agl": ("PLANE ALT ABOVE GROUND", "feet"),
    "ias": ("AIRSPEED INDICATED", "knots"),
    "gs": ("GROUND VELOCITY", "knots"),
    "vs": ("VERTICAL SPEED", "feet per minute"),
    "hdg": ("PLANE HEADING DEGREES TRUE", "degrees"),
    "on_ground": ("SIM ON GROUND", "bool"),
    "eng": ("GENERAL ENG COMBUSTION:1", "bool"),
    "seatbelt": ("CABIN SEATBELTS ALERT SWITCH", "bool"),
    "n1": ("TURB ENG N1:1", "percent"),
    "n1b": ("TURB ENG N1:2", "percent"),
    "rpm": ("GENERAL ENG PCT MAX RPM:1", "percent"),
    "gear": ("GEAR HANDLE POSITION", "bool"),
    "flaps": ("FLAPS HANDLE INDEX", "number"),
    "spoilers": ("SPOILERS HANDLE POSITION", "percent over 100"),
    "apu": ("APU PCT RPM", "percent over 100"),
    "beacon": ("LIGHT BEACON", "bool"),
    "door": ("EXIT OPEN:0", "percent over 100"),
    "parkbrake": ("BRAKE PARKING POSITION", "bool"),
    "pushback": ("PUSHBACK STATE", "enum"),
    "sim_disabled": ("SIM DISABLED", "bool"),
    "camera": ("CAMERA STATE", "number"),
    # avión y pesos (sirve para cualquier avión)
    "title": ("TITLE", "String"),
    "atc_model": ("ATC MODEL", "String"),
    "w_empty": ("EMPTY WEIGHT", "pounds"),
    "w_max": ("MAX GROSS WEIGHT", "pounds"),
    "w_total": ("TOTAL WEIGHT", "pounds"),
    "w_fuel": ("FUEL TOTAL QUANTITY WEIGHT", "pounds"),
    "fuel_cap": ("FUEL TOTAL CAPACITY", "gallons"),
    "fuel_wpg": ("FUEL WEIGHT PER GALLON", "pounds"),
    "cg": ("CG PERCENT", "percent over 100"),
    "n_eng": ("NUMBER OF ENGINES", "number"),
    "eng_type": ("ENGINE TYPE", "enum"),
    "ff1": ("ENG FUEL FLOW PPH:1", "pounds per hour"),
    "ff2": ("ENG FUEL FLOW PPH:2", "pounds per hour"),
    "ff3": ("ENG FUEL FLOW PPH:3", "pounds per hour"),
    "ff4": ("ENG FUEL FLOW PPH:4", "pounds per hour"),
    "d_cruise_alt": ("DESIGN CRUISE ALT", "feet"),
    "d_vc": ("DESIGN SPEED VC", "knots"),
    "d_vs0": ("DESIGN SPEED VS0", "knots"),
    "d_vs1": ("DESIGN SPEED VS1", "knots"),
    "tas": ("AIRSPEED TRUE", "knots"),
}

import planavion as PA
import diario as DI
import rendimiento as RP
import dlss as DL
import atc as ATCM

ATC = ATCM.RADIO

PLAN_INFO = {"dest": None, "cruiseAlt": 30000, "name": ""}
_lock = threading.Lock()
_telemetry = {"mode": "waiting", "data": None}
_demo_route = []          # [{lat, lon, alt}] enviado por la interfaz
clients = set()
_plan_sent = {}          # versión del plan del avión enviada a cada ventana


def set_telemetry(mode, data):
    with _lock:
        _telemetry["mode"] = mode
        _telemetry["data"] = data


def get_telemetry():
    with _lock:
        return dict(_telemetry)


# ---------------------------------------------------------------- SimConnect
import queue

EVENTS = queue.Queue()


def m_dist(a_lat, a_lon, b_lat, b_lon):
    k = math.cos(math.radians(a_lat))
    dx = (b_lon - a_lon) * k * 111320.0
    dy = (b_lat - a_lat) * 110540.0
    return math.hypot(dx, dy), (math.degrees(math.atan2(dx, dy)) + 360) % 360


def offset(lat, lon, hdg, meters):
    r = math.radians(hdg)
    return (lat + math.cos(r) * meters / 110540.0,
            lon + math.sin(r) * meters / (111320.0 * math.cos(math.radians(lat))))


def ang_diff(a, b):
    return (a - b + 540) % 360 - 180


class Pushback:
    """Dirige el remolcador de MSFS siguiendo una curva suave hasta el punto y rumbo elegidos en el mapa."""

    LOOK = 10.0     # metros de anticipación (persecución pura marcha atrás)

    def __init__(self):
        self.active = False
        self.msg = "Listo"
        self.target = None
        self.final = 0.0
        self.path = []
        self.idx = 0
        self.started = 0.0

    def _build_path(self, lat, lon, hdg):
        """Curva de Bézier: sale marcha atrás recto y llega con el morro en el rumbo final."""
        tl, to = self.target
        dist, _ = m_dist(lat, lon, tl, to)
        L = max(8.0, dist * 0.45)
        p0 = (lat, lon)
        p1 = offset(lat, lon, (hdg + 180) % 360, L)          # sale en dirección de la cola
        p2 = offset(tl, to, self.final, L)                   # llega desde delante del morro final
        p3 = (tl, to)
        pts = []
        n = max(20, int(dist / 1.5))
        for i in range(n + 1):
            t = i / n
            u = 1 - t
            pts.append((u ** 3 * p0[0] + 3 * u * u * t * p1[0] + 3 * u * t * t * p2[0] + t ** 3 * p3[0],
                        u ** 3 * p0[1] + 3 * u * u * t * p1[1] + 3 * u * t * t * p2[1] + t ** 3 * p3[1]))
        return pts

    def start(self, lat, lon, heading, d):
        if not d or not d.get("on_ground"):
            return False, "El avión tiene que estar en tierra"
        if d.get("gs", 0) > 3:
            return False, "Para el avión antes de empezar"
        self.target = (lat, lon)
        self.final = heading % 360
        dist, _ = m_dist(d["lat"], d["lon"], lat, lon)
        if dist < 3:
            return False, "El punto está demasiado cerca"
        self.path = self._build_path(d["lat"], d["lon"], d["hdg"])
        self.idx = 0
        self.min_dist = dist
        self.active = True
        self.started = time.time()
        self.msg = "Conectando el remolcador…"
        if d.get("parkbrake"):
            EVENTS.put(("PARKING_BRAKES", 0))          # quita el freno de parking
        if d.get("pushback", 3) == 3:
            EVENTS.put(("TOGGLE_PUSHBACK", 0))         # conecta el remolcador
        return True, "Pushback en marcha"

    def stop(self, msg="Pushback terminado"):
        if self.active:
            EVENTS.put(("TOGGLE_PUSHBACK", 0))
        self.active = False
        self.msg = msg

    def step(self, d):
        if not self.active or not d:
            return
        if not d.get("on_ground"):
            return self.stop("Cancelado: el avión no está en tierra")
        if time.time() - self.started > 600:
            return self.stop("Cancelado por tiempo")
        lat, lon = d["lat"], d["lon"]
        # punto de la curva más cercano (solo hacia delante)
        best, bi = 1e9, self.idx
        for i in range(self.idx, min(len(self.path), self.idx + 40)):
            dd, _ = m_dist(lat, lon, *self.path[i])
            if dd < best:
                best, bi = dd, i
        self.idx = bi
        dist_t, brg_t = m_dist(lat, lon, *self.target)
        # punto de anticipación sobre la curva
        look = self.path[-1]
        acc = 0.0
        for i in range(bi, len(self.path) - 1):
            acc += m_dist(*self.path[i], *self.path[i + 1])[0]
            if acc >= self.LOOK:
                look = self.path[i + 1]
                break
        if acc < self.LOOK and dist_t < self.LOOK:
            # tramo final: prolonga la recta del rumbo final para llegar alineado
            look = offset(*self.target, (self.final + 180) % 360, self.LOOK - dist_t)
        _, brg_l = m_dist(lat, lon, *look)
        want = (brg_l + 180) % 360        # marcha atrás: el morro mira al lado contrario del movimiento
        self.msg = f"Retrocediendo · faltan {dist_t:.0f} m"
        self.min_dist = min(self.min_dist, dist_t)
        if dist_t > self.min_dist + 12:
            return self.stop("Parado: giro demasiado cerrado para ese espacio. Elige un punto más lejos.")
        along = math.cos(math.radians(ang_diff(brg_t, (d["hdg"] + 180) % 360)))
        if dist_t < 1.5 or (dist_t < 5 and along < 0.2):
            return self.stop(f"✔ Pushback terminado · rumbo {d['hdg']:.0f}°")
        EVENTS.put(("KEY_TUG_HEADING", int((want % 360) / 360.0 * 4294967295)))

    def status(self):
        return {"active": self.active, "msg": self.msg, "target": self.target, "final": self.final,
                "path": self.path[::3] if self.active else []}


PUSH = Pushback()


import sonidos_sim as SND


def sound_ctx(d):
    """Datos para los anuncios: destino, altitud y tiempo restante."""
    ctx = {"dest": PLAN_INFO.get("dest")}
    alt = round(d.get("alt", 0) / 1000) * 1000
    ctx["alt_es"] = f"{alt:,}".replace(",", ".") + " pies"
    ctx["alt_en"] = f"{alt:,} feet"
    route = list(_demo_route)
    if len(route) >= 2 and d.get("gs", 0) > 60:
        rem = hav_nm(d, route[-1])
        m = max(1, round(rem / d["gs"] * 60))
        ctx["eta_es"] = f"{m // 60} hora{'s' if m >= 120 else ''} y {m % 60} minutos" if m >= 60 else f"{m} minutos"
        ctx["eta_en"] = f"{m // 60} hour{'s' if m >= 120 else ''} and {m % 60} minutes" if m >= 60 else f"{m} minutes"
    return ctx


SND.ENGINE.ctx_fn = sound_ctx


class SimReader(threading.Thread):
    """Lee datos de MSFS en segundo plano. Reintenta cada 5 s si el simulador no está abierto."""

    def __init__(self):
        super().__init__(daemon=True)
        self.live = False

    def run(self):
        try:
            from SimConnect import SimConnect
            try:
                from SimConnect import Request
            except ImportError:
                from SimConnect.RequestList import Request
        except Exception as exc:  # librería no instalada o no es Windows
            print(f"[!] SimConnect no disponible ({exc}). Solo modo demo.")
            return

        warned = False
        while True:
            sm = None
            try:
                sm = SimConnect()
                RISKY = {"title", "atc_model", "sim_disabled", "camera"} | PA.GPS_TEXT
                reqs = {
                    key: Request((name.encode(), unit.encode()), sm, _time=100)
                    for key, (name, unit) in {**SIMVARS, **PA.GPS_VARS, **DI.VARS}.items()
                    if not (getattr(self, "safe", False) and key in RISKY)
                }
                self.t_conn = time.time()
                print(time.strftime("[%H:%M:%S]"), "[OK] Conectado a Microsoft Flight Simulator"
                      + (" (modo seguro)" if getattr(self, "safe", False) else ""), flush=True)
                SND.ENGINE.reset()
                try:
                    from SimConnect import Event
                except ImportError:
                    from SimConnect.EventList import Event
                events = {}
                while not EVENTS.empty():      # descartar órdenes viejas
                    EVENTS.get_nowait()
                self.live = True
                PA.PLAN.on_connect()
                threading.Thread(target=skies_on_connect, daemon=True).start()
                warned = False
                fails = 0
                while True:
                    loop_n = getattr(self, "_n", 0) + 1
                    self._n = loop_n
                    slow_skip = PERF["on"] and loop_n % RP.SLOW_EVERY != 1
                    last = getattr(self, "_last_raw", {})
                    raw = {}
                    for k, r in reqs.items():
                        if slow_skip and k not in RP.FAST and k in last:
                            raw[k] = last[k]          # modo rendimiento: los datos lentos, cada 2 s
                        else:
                            raw[k] = r.value
                    self._last_raw = raw
                    for k in SIMVARS:
                        raw.setdefault(k, None)
                    if raw["lat"] is None or raw["lon"] is None:
                        fails += 1
                        if fails > 25:
                            raise RuntimeError("el simulador no responde")
                    else:
                        fails = 0
                        d = normalize(raw)
                        set_telemetry("sim", d)
                        PUSH.step(d)
                        try:
                            DI.LOG.tick(raw, d)
                        except Exception as exc:  # noqa: BLE001
                            print(f"[!] Diario: {exc}", flush=True)
                        try:
                            ATC.update(d, DI.LOG.phase, {"dep": PLAN_INFO.get("dep_code"), "arr": PLAN_INFO.get("arr_code")}, ATC_NET["net"])
                        except Exception as exc:  # noqa: BLE001
                            print(f"[!] Radio: {exc}", flush=True)
                        try:
                            PA.PLAN.perf = PERF["on"]
                            PA.PLAN.tick(sm, raw)
                        except Exception as exc:  # noqa: BLE001
                            print(f"[!] Plan del avión: {exc}", flush=True)
                        try:
                            SND.ENGINE.update(d, float(PLAN_INFO.get("cruiseAlt") or 30000))
                        except Exception as exc:  # noqa: BLE001
                            print(f"[!] Sonidos: {exc}", flush=True)
                    while not EVENTS.empty():
                        name, val = EVENTS.get_nowait()
                        try:
                            ev = events.get(name) or events.setdefault(name, Event(name.encode(), sm))
                            ev(int(val))
                        except Exception as exc:  # noqa: BLE001
                            print(f"[!] Evento {name}: {exc}")
                    time.sleep(0.2)
            except Exception as exc:
                try:
                    DI.LOG.disconnected(get_telemetry().get("data"))
                except Exception:  # noqa: BLE001
                    pass
                if self.live:
                    dur = time.time() - getattr(self, "t_conn", time.time())
                    print(time.strftime("[%H:%M:%S]"), f"[!] Conexión con MSFS perdida tras {dur:.0f} s: {exc}", flush=True)
                    if dur < 30 and not getattr(self, "safe", False):
                        self.safe = True
                        print(time.strftime("[%H:%M:%S]"), "[i] Se cortó enseguida: reconecto en modo seguro (solo datos básicos)", flush=True)
                elif not warned or str(exc) != getattr(self, "_last_err", ""):
                    print(f"[i] Esperando a MSFS 2024... ({type(exc).__name__}: {exc})", flush=True)
                    self._last_err = str(exc)
                    warned = True
                self.live = False
                try:
                    if sm:
                        sm.exit()
                except Exception:
                    pass
                time.sleep(5)


LB = 0.45359237
_ac_cache = {"t": 0, "v": None}


def _txt(v):
    if isinstance(v, bytes):
        v = v.split(b"\0")[0].decode("utf-8", "ignore")
    return str(v or "").strip()


def aircraft_info(raw):
    """Datos del avión cargado (cualquiera): nombre, pesos en kg, combustible, CG y consumo real."""
    def f(k):
        try:
            return float(raw.get(k) or 0)
        except (TypeError, ValueError):
            return 0.0
    n = int(f("n_eng") or 0)
    ff = sum(f(f"ff{i}") for i in range(1, min(4, max(1, n)) + 1))
    cap_kg = f("fuel_cap") * f("fuel_wpg") * LB
    info = {
        "title": _txt(raw.get("title")), "model": _txt(raw.get("atc_model")),
        "empty": round(f("w_empty") * LB), "max": round(f("w_max") * LB), "total": round(f("w_total") * LB),
        "fuel": round(f("w_fuel") * LB), "fuel_cap": round(cap_kg),
        "cg": round(f("cg") * 100, 1), "engines": n, "eng_type": int(f("eng_type")),
        "ff": round(ff * LB), "cruise_alt": round(f("d_cruise_alt")), "vc": round(f("d_vc")),
        "vs0": round(f("d_vs0")), "vs1": round(f("d_vs1")),
    }
    info["payload"] = max(0, info["total"] - info["empty"] - info["fuel"])
    return info


def normalize(raw):
    def num(v, nd=1):
        try:
            return round(float(v), nd)
        except (TypeError, ValueError):
            return 0.0

    return {
        "lat": num(raw["lat"], 6),
        "lon": num(raw["lon"], 6),
        "alt": num(raw["alt"], 0),
        "agl": num(raw["agl"], 0),
        "ias": num(raw["ias"], 0),
        "gs": num(raw["gs"], 0),
        "vs": num(raw["vs"], 0),
        "hdg": num(raw["hdg"], 1) % 360,
        "on_ground": bool(raw["on_ground"]),
        "eng": bool(raw.get("eng")),
        "seatbelt": bool(raw.get("seatbelt")),
        "n1": num(max(num(raw.get("n1")), num(raw.get("n1b")), num(raw.get("rpm")))),
        "gear": bool(raw.get("gear")),
        "flaps": int(num(raw.get("flaps"), 0)),
        "spoilers": num(raw.get("spoilers"), 2),
        "apu": num(raw.get("apu"), 2),
        "beacon": bool(raw.get("beacon")),
        "door": num(raw.get("door"), 2),
        "parkbrake": bool(raw.get("parkbrake")),
        "pushback": int(num(raw.get("pushback"), 0)) if raw.get("pushback") is not None else 3,
        "tas": num(raw.get("tas"), 0),
        "paused": bool(raw.get("sim_disabled")) or int(num(raw.get("camera"), 0)) in (11, 12, 13, 14, 15, 17, 21),
        "aircraft": aircraft_info(raw),
    }


SIM = SimReader()


# ---------------------------------------------------------------- Modo demo
def hav_nm(a, b):
    la1, lo1, la2, lo2 = map(math.radians, (a["lat"], a["lon"], b["lat"], b["lon"]))
    h = math.sin((la2 - la1) / 2) ** 2 + math.cos(la1) * math.cos(la2) * math.sin((lo2 - lo1) / 2) ** 2
    return 2 * 3440.065 * math.asin(min(1.0, math.sqrt(h)))


def bearing(a, b):
    la1, lo1, la2, lo2 = map(math.radians, (a["lat"], a["lon"], b["lat"], b["lon"]))
    y = math.sin(lo2 - lo1) * math.cos(la2)
    x = math.cos(la1) * math.sin(la2) - math.sin(la1) * math.cos(la2) * math.cos(lo2 - lo1)
    return (math.degrees(math.atan2(y, x)) + 360) % 360


def demo_extra(d):
    """Completa el avión demo con motores, tren, flaps... coherentes con la fase."""
    agl, vs, gs, g = d["agl"], d["vs"], d["gs"], d["on_ground"]
    climbing, descending = vs > 300, vs < -300
    d.update({
        "n1": 22 if g and gs < 40 else 92 if (g or climbing) else 38 if descending else 84,
        "gear": g or agl < 2500,
        "flaps": 0 if agl > 6000 else (2 if climbing or g else 3 if agl < 2000 else 1),
        "spoilers": 0.0,
        "apu": 0.0,
        "beacon": True,
        "door": 0.0,
        "parkbrake": False,
    })
    return d


async def demo_loop():
    """Avión simulado que recorre el plan de vuelo (acelerado x25) cuando MSFS no está conectado."""
    along = 0.0
    prev_alt = None
    last = time.time()
    angle = 0.0
    route_sig = None
    while True:
        await asyncio.sleep(0.25)
        now = time.time()
        dt = now - last
        last = now
        if SIM.live:
            continue
        route = list(_demo_route)
        if len(route) < 2:
            angle += dt * 0.15
            lat, lon = 40.42 + 0.35 * math.cos(angle), -3.70 + 0.45 * math.sin(angle)
            set_telemetry("demo", demo_extra({"lat": round(lat, 6), "lon": round(lon, 6), "alt": 8000, "agl": 6000,
                                   "ias": 180, "gs": 190, "vs": 0,
                                   "hdg": round((math.degrees(-angle) + 360) % 360, 1), "on_ground": False, "eng": True, "seatbelt": False}))
            continue
        sig = json.dumps(route)
        if sig != route_sig:          # plan nuevo -> empezar desde el principio
            route_sig, along, prev_alt = sig, 0.0, None
        legs = [hav_nm(route[i], route[i + 1]) for i in range(len(route) - 1)]
        total = sum(legs)
        if total <= 0:
            continue
        # posición actual
        d, i = along, 0
        while i < len(legs) - 1 and d > legs[i]:
            d -= legs[i]
            i += 1
        t = min(1.0, d / legs[i]) if legs[i] else 1.0
        a, b = route[i], route[i + 1]
        lat = a["lat"] + (b["lat"] - a["lat"]) * t
        lon = a["lon"] + (b["lon"] - a["lon"]) * t
        alt = a["alt"] + (b["alt"] - a["alt"]) * t
        gs = 140 + min(1.0, alt / 35000) * 310
        vs = 0 if prev_alt is None or dt <= 0 else (alt - prev_alt) / (dt * 25) * 60
        prev_alt = alt
        set_telemetry("demo", demo_extra({"lat": round(lat, 6), "lon": round(lon, 6), "alt": round(alt),
                               "agl": round(alt), "ias": round(gs * 0.8), "gs": round(gs),
                               "vs": round(vs), "hdg": round(bearing(a, b), 1),
                               "on_ground": along < 0.5 or along > total - 0.5, "eng": True, "seatbelt": alt < 10000}))
        along += gs / 3600 * dt * 25
        if along >= total:
            await asyncio.sleep(3)
            along, prev_alt = 0.0, None


async def broadcaster():
    while True:
        await asyncio.sleep(0.25)
        tel = get_telemetry()
        if not clients:
            continue
        if not SIM.live:
            tel = {"mode": "waiting", "data": None}
        msg = json.dumps({"type": "telemetry", **tel, "push": PUSH.status(), "snd": SND.ENGINE.status(),
                          "diario": DI.LOG.status(), "atc": ATC.status()})
        pv = PA.PLAN.ver
        pmsg = json.dumps({"type": "simplan", **PA.PLAN.status()}) if PA.PLAN.data else None
        for ws in list(clients):
            try:
                await ws.send_str(msg)
                if pmsg and _plan_sent.get(ws) != pv:
                    await ws.send_str(pmsg)
                    _plan_sent[ws] = pv
            except Exception:
                clients.discard(ws)
                _plan_sent.pop(ws, None)


# ---------------------------------------------------------------- HTTP / WS
async def ws_handler(request):
    global _demo_route
    ws = web.WebSocketResponse(heartbeat=20)
    await ws.prepare(request)
    clients.add(ws)
    try:
        async for msg in ws:
            if msg.type != WSMsgType.TEXT:
                continue
            try:
                data = json.loads(msg.data)
            except ValueError:
                continue
            if data.get("type") == "plan":
                PLAN_INFO.update({k: data.get(k) for k in ("dest", "cruiseAlt", "name") if data.get(k) is not None})
                PLAN_INFO["dep_code"] = (str(data.get("depCode") or "").upper()[:8]) or None
                PLAN_INFO["arr_code"] = (str(data.get("arrCode") or "").upper()[:8]) or None
                route = []
                for p in data.get("route", [])[:200]:
                    try:
                        route.append({"lat": float(p["lat"]), "lon": float(p["lon"]), "alt": float(p.get("alt", 0))})
                    except (KeyError, TypeError, ValueError):
                        pass
                _demo_route = route
    finally:
        clients.discard(ws)
    return ws


def safe_name(name):
    name = re.sub(r"[^\w\- ]", "", str(name), flags=re.UNICODE).strip()
    return (name or "plan")[:60]


async def list_plans(_):
    PLANS_DIR.mkdir(exist_ok=True)
    items = sorted(PLANS_DIR.glob("*.json"), key=lambda p: p.stat().st_mtime, reverse=True)
    return web.json_response([p.stem for p in items])


async def get_plan(request):
    path = PLANS_DIR / f"{safe_name(request.match_info['name'])}.json"
    if not path.exists():
        raise web.HTTPNotFound()
    return web.json_response(json.loads(path.read_text(encoding="utf-8")))


async def save_plan(request):
    body = await request.json()
    PLANS_DIR.mkdir(exist_ok=True)
    name = safe_name(body.get("name", "plan"))
    (PLANS_DIR / f"{name}.json").write_text(json.dumps(body.get("plan", {}), ensure_ascii=False, indent=1),
                                            encoding="utf-8")
    return web.json_response({"ok": True, "name": name})


async def delete_plan(request):
    path = PLANS_DIR / f"{safe_name(request.match_info['name'])}.json"
    if path.exists():
        path.unlink()
    return web.json_response({"ok": True})


async def export_pln(request):
    body = await request.json()
    PLN_DIR.mkdir(exist_ok=True)
    path = PLN_DIR / f"{safe_name(body.get('name', 'plan'))}.pln"
    path.write_text(str(body.get("xml", "")), encoding="utf-8")
    return web.json_response({"ok": True, "path": str(path)})


# ---------------------------------------------------------------- Asistente de configuración
import os
import shutil
import subprocess
import sys

CONFIG_FILE = BASE / "config.json"
CAM_SCRIPT = BASE / "camara" / "camara_fisica.py"
CAM_SETTINGS = BASE / "camara" / "camara_ajustes.json"
RESHADE_DIR = BASE / "reshade"
MSFS_EXE_NAMES = ("FlightSimulator2024.exe",)
camera_proc = {"p": None, "mode": None}


def load_config():
    try:
        return json.loads(CONFIG_FILE.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {}


def save_config(cfg):
    CONFIG_FILE.write_text(json.dumps(cfg, ensure_ascii=False, indent=1), encoding="utf-8")


def steam_libraries():
    libs = []
    if sys.platform != "win32":
        return libs
    try:
        import winreg
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER, r"Software\Valve\Steam") as k:
            steam = Path(winreg.QueryValueEx(k, "SteamPath")[0])
        libs.append(steam)
        vdf = steam / "steamapps" / "libraryfolders.vdf"
        if vdf.exists():
            for m in re.finditer(r'"path"\s+"([^"]+)"', vdf.read_text(encoding="utf-8", errors="ignore")):
                libs.append(Path(m.group(1).replace("\\\\", "\\")))
    except OSError:
        pass
    return libs


def find_msfs():
    """Busca el ejecutable de MSFS 2024 (Steam y Microsoft Store / Xbox)."""
    candidates = []
    for lib in steam_libraries():
        common = lib / "steamapps" / "common"
        candidates.append(common / "Microsoft Flight Simulator 2024")
        candidates.append(common / "MSFS2024")
        try:
            candidates += [d for d in common.iterdir() if d.is_dir()]
        except OSError:
            pass
    if sys.platform == "win32":
        for letter in "CDEFGHIJ":
            root = Path(f"{letter}:\\")
            for sub in ("XboxGames\\Microsoft Flight Simulator 2024\\Content",
                        "XboxGames\\Microsoft Flight Simulator 2024",
                        "Program Files\\WindowsApps\\Microsoft.Limitless_1.0.0.0_x64__8wekyb3d8bbwe"):
                candidates.append(root / sub)
    for folder in candidates:
        try:
            for name in MSFS_EXE_NAMES:
                if (folder / name).is_file():
                    return folder
        except OSError:
            continue
    return None


def find_opentrack():
    if sys.platform != "win32":
        return None
    for env in ("ProgramFiles(x86)", "ProgramFiles"):
        base = os.environ.get(env)
        if base:
            exe = Path(base) / "opentrack" / "opentrack.exe"
            if exe.is_file():
                return exe
    return None


def setup_status():
    cfg = load_config()
    msfs = Path(cfg["msfs_dir"]) if cfg.get("msfs_dir") else find_msfs()
    if msfs and not msfs.is_dir():
        msfs = None
    reshade = bool(msfs and (msfs / "dxgi.dll").exists() and (msfs / "ReShade.ini").exists())
    presets = bool(msfs and all((msfs / p.name).exists() for p in RESHADE_DIR.glob("*.ini")))
    ot = find_opentrack()
    p = camera_proc["p"]
    running = bool(p and p.poll() is None)
    try:
        cam_settings = json.loads(CAM_SETTINGS.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        cam_settings = {}
    return {
        "windows": sys.platform == "win32",
        "msfs_dir": str(msfs) if msfs else None,
        "reshade": reshade,
        "presets": presets,
        "opentrack": str(ot) if ot else None,
        "camera": camera_proc["mode"] if running else None,
        "sim_connected": SIM.live,
        "cam_settings": cam_settings,
        "done": cfg.get("done", {}),
        "store": H.is_store_install(msfs) if msfs else False,
        "tracking": H.find_tracking_files(),
        "autostart": H.msfs_autostart_enabled(),
        "camera_autostart": cfg.get("camera_autostart", True),
        "msfs_open_window": cfg.get("msfs_open_window", True),
        "background": cfg.get("background", False),
        "version": H.app_version(),
        "update_url": cfg.get("update_url", ""),
        "reshade_version": cfg.get("reshade_version"),
    }


async def api_setup_status(_):
    return web.json_response(await asyncio.to_thread(setup_status))


async def api_setup_msfs(request):
    body = await request.json()
    path = Path(str(body.get("path", "")).strip().strip('"'))
    if path.is_file():
        path = path.parent
    if not any((path / n).is_file() for n in MSFS_EXE_NAMES):
        return web.json_response({"ok": False, "error": "En esa carpeta no está FlightSimulator2024.exe"})
    cfg = load_config()
    cfg["msfs_dir"] = str(path)
    save_config(cfg)
    return web.json_response({"ok": True})


async def api_setup_done(request):
    body = await request.json()
    cfg = load_config()
    cfg.setdefault("done", {})[str(body.get("step"))] = bool(body.get("value"))
    save_config(cfg)
    return web.json_response({"ok": True})


async def api_copy_presets(_):
    st = await asyncio.to_thread(setup_status)
    if not st["msfs_dir"]:
        return web.json_response({"ok": False, "error": "Primero hay que encontrar la carpeta de MSFS"})
    try:
        for p in RESHADE_DIR.glob("*.ini"):
            shutil.copy2(p, Path(st["msfs_dir"]) / p.name)
    except OSError as exc:
        return web.json_response({"ok": False, "error": f"No se pudo copiar ({exc}). Prueba a abrir SimDirect como administrador."})
    return web.json_response({"ok": True})


async def api_open(request):
    """Abre en el PC una carpeta de SimDirect o un programa ya instalado (solo rutas conocidas)."""
    what = (await request.json()).get("what")
    st = await asyncio.to_thread(setup_status)
    target = {"reshade_folder": RESHADE_DIR, "msfs_folder": st["msfs_dir"], "opentrack": st["opentrack"],
              "pln_folder": PLN_DIR}.get(what)
    if not target or sys.platform != "win32":
        return web.json_response({"ok": False, "error": "No disponible"})
    Path(target).mkdir(exist_ok=True) if what == "pln_folder" else None
    os.startfile(str(target))
    return web.json_response({"ok": True})


async def api_camera(request):
    body = await request.json()
    action = body.get("action")
    p = camera_proc["p"]
    if p and p.poll() is None:
        p.terminate()
        try:
            p.wait(3)
        except subprocess.TimeoutExpired:
            p.kill()
    camera_proc["p"] = camera_proc["mode"] = None
    if action in ("start", "test"):
        args = [sys.executable, str(CAM_SCRIPT)] + (["--prueba"] if action == "test" else [])
        flags = getattr(subprocess, "CREATE_NO_WINDOW", 0) | (RP.NORMAL_PRIORITY_FLAG if sys.platform == "win32" else 0)
        camera_proc["p"] = subprocess.Popen(args, cwd=str(CAM_SCRIPT.parent), creationflags=flags)
        camera_proc["mode"] = action
    return web.json_response({"ok": True, "camera": camera_proc["mode"]})


async def api_camera_settings(request):
    body = await request.json()
    clean = {k: max(0.0, min(3.0, float(v))) for k, v in body.items()
             if k in ("general", "g", "virajes", "pista", "aterrizaje", "buffet", "motor", "suavidad")}
    CAM_SETTINGS.write_text(json.dumps(clean, indent=1), encoding="utf-8")
    return web.json_response({"ok": True})


# ---------------------------------------------------------------- ReShade personalizado
RS_DEFAULTS = {"sharpen": 0.45, "vibrance": 0.12, "contrast": 0.12, "exposure": 0.0, "gamma": 1.0,
               "saturation": 0.0, "warmth": 0.5, "vignette": 0.0, "deband": 1.0}
RS_FILE = BASE / "reshade" / "ajustes_reshade.json"
RS_PRESET = "SimDirect_Personal.ini"


def build_reshade_ini(v):
    w = v["warmth"]
    techs = ["Deband@Deband.fx"] if v["deband"] >= 0.5 else []
    techs += ["Tonemap@Tonemap.fx", "LiftGammaGain@LiftGammaGain.fx", "Vibrance@Vibrance.fx",
              "Curves@Curves.fx", "ContrastAdaptiveSharpen@CAS.fx"]
    if v["vignette"] > 0.01:
        techs.append("Vignette@Vignette.fx")
    t = ",".join(techs)
    f = lambda x: f"{x:.6f}"
    return f"""PreprocessorDefinitions=
Techniques={t}
TechniqueSorting={t}

[CAS.fx]
Contrast=0.000000
Sharpening={f(v["sharpen"])}

[Curves.fx]
Contrast={f(v["contrast"])}
Formula=2
Mode=0

[Deband.fx]
banding_depth=1.000000
debug_output=0
enable_depthbuffer=0
enable_sdeviation=1
enable_weber=1
iterations=1
range=24.000000
t1=0.007000
t2=0.040000

[LiftGammaGain.fx]
RGB_Gain={f(1 + 0.03 * w)},{f(1 + 0.01 * w)},{f(1 - 0.02 * w)}
RGB_Gamma=1.000000,1.000000,1.000000
RGB_Lift={f(1 - 0.03 * w)},{f(1 - 0.01 * w)},{f(1 + 0.03 * w)}

[Tonemap.fx]
Bleach=0.000000
Defog=0.000000
Exposure={f(v["exposure"])}
FogColor=0.000000,0.000000,1.000000
Gamma={f(v["gamma"])}
Saturation={f(v["saturation"])}

[Vibrance.fx]
Vibrance={f(v["vibrance"])}
VibranceRGBBalance=1.000000,1.000000,1.000000
Vibrance_Luma=0

[Vignette.fx]
Amount={f(-v["vignette"])}
Center=0.500000,0.500000
Radius=2.000000
Ratio=1.000000
Slope=2
Type=0
"""


class ReshadeReloader:
    """Cuando cambias los gráficos, ReShade tiene que recargar el preset. Lo hace solo:
    en cuanto la ventana de MSFS está delante, la app pulsa Ctrl+Mayús+Alt+F12 (tecla de recarga)."""

    def __init__(self):
        self.pending = 0.0
        threading.Thread(target=self.loop, daemon=True).start()

    def request(self):
        self.pending = time.time()

    @staticmethod
    def msfs_in_front():
        if sys.platform != "win32":
            return False
        import ctypes
        from ctypes import wintypes
        u, k = ctypes.windll.user32, ctypes.windll.kernel32
        hwnd = u.GetForegroundWindow()
        pid = wintypes.DWORD()
        u.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
        h = k.OpenProcess(0x1000, False, pid.value)
        if not h:
            return False
        try:
            buf = ctypes.create_unicode_buffer(520)
            n = wintypes.DWORD(520)
            k.QueryFullProcessImageNameW(h, 0, buf, ctypes.byref(n))
            return buf.value.lower().endswith(("flightsimulator2024.exe", "flightsimulator.exe"))
        finally:
            k.CloseHandle(h)

    @staticmethod
    def press():
        import ctypes
        u = ctypes.windll.user32
        VK = [0x11, 0x10, 0x12, 0x7B]          # Ctrl, Mayús, Alt, F12
        for v in VK:
            u.keybd_event(v, u.MapVirtualKeyW(v, 0), 0, 0)
            time.sleep(0.02)
        time.sleep(0.05)
        for v in reversed(VK):
            u.keybd_event(v, u.MapVirtualKeyW(v, 0), 2, 0)
            time.sleep(0.02)

    def loop(self):
        while True:
            time.sleep(0.5)
            try:
                if self.pending and time.time() - self.pending > 0.6 and self.msfs_in_front():
                    self.pending = 0.0
                    time.sleep(0.4)
                    self.press()
                    print(f"[{time.strftime('%H:%M:%S')}] ReShade: gráficos aplicados en el juego", flush=True)
            except Exception as exc:  # noqa: BLE001
                print(f"[!] ReShade recarga: {exc}", flush=True)
                self.pending = 0.0


RS_RELOAD = ReshadeReloader()


async def api_reshade_get(_):
    try:
        vals = {**RS_DEFAULTS, **json.loads(RS_FILE.read_text(encoding="utf-8"))}
    except (OSError, ValueError):
        vals = dict(RS_DEFAULTS)
    return web.json_response(vals)


async def api_reshade_set(request):
    body = await request.json()
    lim = {"sharpen": (0, 1), "vibrance": (-1, 1), "contrast": (-1, 1), "exposure": (-1, 1), "gamma": (0.5, 1.5),
           "saturation": (-1, 1), "warmth": (-2, 2), "vignette": (0, 1), "deband": (0, 1)}
    vals = dict(RS_DEFAULTS)
    for k, (lo, hi) in lim.items():
        try:
            vals[k] = max(lo, min(hi, float(body.get(k, vals[k]))))
        except (TypeError, ValueError):
            pass
    RS_FILE.write_text(json.dumps(vals, indent=1), encoding="utf-8")
    ini = build_reshade_ini(vals)
    (BASE / "reshade" / RS_PRESET).write_text(ini, encoding="utf-8")
    st = await asyncio.to_thread(setup_status)
    where = None
    if st["msfs_dir"]:
        def _apply():
            try:
                (Path(st["msfs_dir"]) / RS_PRESET).write_text(ini, encoding="utf-8")
            except OSError:
                pass
            return H.set_reshade_preset(st["msfs_dir"], RS_PRESET, ini)   # mover deslizadores = «Mi preset»
        if await asyncio.to_thread(_apply):
            where = st["msfs_dir"]
            RS_RELOAD.request()
    return web.json_response({"ok": True, "copied_to_msfs": bool(where),
                              "msg": "Se aplica en cuanto vuelvas a la ventana de MSFS" if where else ""})


# ---------------------------------------------------------------- Sonidos propios
SOUNDS_DIR = BASE / "sonidos"


async def api_sounds(_):
    SOUNDS_DIR.mkdir(exist_ok=True)
    exts = {".mp3", ".wav", ".ogg", ".m4a"}
    return web.json_response(sorted(p.name for p in SOUNDS_DIR.iterdir() if p.suffix.lower() in exts))


async def on_cleanup(_):
    p = camera_proc["p"]
    if p and p.poll() is None:
        p.terminate()


async def index(_):
    """La página siempre con la versión actual: cada archivo lleva ?v=versión para que nunca se quede el viejo en caché."""
    v = H.app_version() + "-" + str(int((WEB_DIR / "app.js").stat().st_mtime))
    html = (WEB_DIR / "index.html").read_text(encoding="utf-8")
    html = re.sub(r'(src|href)="((?!https?:)[^"]+\.(?:js|css))"', lambda m: f'{m.group(1)}="{m.group(2)}?v={v}"', html)
    return web.Response(text=html, content_type="text/html",
                        headers={"Cache-Control": "no-store, no-cache, must-revalidate", "Pragma": "no-cache"})


@web.middleware
async def no_cache(request, handler):
    resp = await handler(request)
    if not request.path.startswith(("/lib/", "/sonidos/")):
        resp.headers["Cache-Control"] = "no-cache, must-revalidate"
    return resp


async def on_startup(app):
    RP.set_priority(PERF["on"])       # modo rendimiento: MSFS primero
    SIM.start()
    app["tasks"] = [asyncio.create_task(broadcaster()), asyncio.create_task(traffic_recorder())]   # sin modo demo
    SND.start()
    def _rs_fix():
        try:
            d = load_config().get("msfs_dir")
            if d and (Path(d) / "ReShade.ini").exists():
                if not (Path(d) / H.RS_ACTIVE).exists():
                    H.set_reshade_preset(d, load_config().get("reshade_preset") or RS_PRESET)
                H.ensure_reshade_ini(d)
        except Exception as exc:  # noqa: BLE001
            print(f"[!] ReShade: {exc}", flush=True)
    threading.Thread(target=_rs_fix, daemon=True).start()
    def _dlss():
        c = load_config()
        if c.get("dlss_auto"):
            print(f"[DLSS] {DL.apply(c.get('dlss_mode') or 'QUALITY')[1]}", flush=True)
    threading.Thread(target=_dlss, daemon=True).start()
    threading.Thread(target=AP.load, daemon=True).start()          # base de aeropuertos
    cfg = load_config()
    if cfg.get("ai_model") == "qwen2.5:7b" and not cfg.get("ai_model_user"):   # el 7b es lento: usar el rápido
        cfg["ai_model"] = "qwen2.5:3b"
        cfg["ai_auto_done"] = False
        save_config(cfg)
    def _warm():
        H.start_ollama()
        ai_warmup(load_config().get("ai_model") or "qwen2.5:3b")
    threading.Thread(target=_warm, daemon=True).start()
    if not cfg.get("ai_auto_done") and sys.platform == "win32":     # IA gratis: se instala sola la primera vez
        cfg["ai_auto_done"] = True
        save_config(cfg)
        run_job("ai", H.install_ai, cfg.get("ai_model") or "qwen2.5:3b")


def local_ip():
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        s.connect(("10.255.255.255", 1))
        return s.getsockname()[0]
    except OSError:
        return "127.0.0.1"
    finally:
        s.close()


# ---------------------------------------------------------------- Instalaciones automáticas
import herramientas as H

JOBS = {}
AUTO_MODE = False


def run_job(name, fn, *args):
    if JOBS.get(name, {}).get("running"):
        return
    JOBS[name] = {"running": True, "msg": "Empezando…", "result": None}

    def progress(m):
        JOBS[name]["msg"] = m

    def work():
        try:
            res = fn(*args, progress) if name in ("reshade", "tracking", "ai") else fn(*args)
        except Exception as exc:  # noqa: BLE001
            res = {"ok": False, "error": str(exc)}
        JOBS[name] = {"running": False, "msg": "", "result": res}

    threading.Thread(target=work, daemon=True).start()


async def api_auto(request):
    job = request.match_info["job"]
    body = await request.json() if request.can_read_body else {}
    st = await asyncio.to_thread(setup_status)
    if job == "reshade":
        if not st["msfs_dir"]:
            return web.json_response({"ok": False, "error": "Primero hay que encontrar la carpeta de MSFS"})
        preset = body.get("preset") or "SimDirect_Personal.ini"
        if preset == "SimDirect_Personal.ini" and not (RESHADE_DIR / preset).exists():
            shutil.copy2(RESHADE_DIR / "SimDirect_Realista.ini", RESHADE_DIR / preset)
        run_job("reshade", H.install_reshade, st["msfs_dir"])
    elif job == "reshade_uninstall":
        run_job("reshade_uninstall", H.uninstall_reshade, st["msfs_dir"])
    elif job == "reshade_preset":
        ok = await asyncio.to_thread(H.set_reshade_preset, st["msfs_dir"], body.get("preset", "SimDirect_Personal.ini"))
        if ok:
            RS_RELOAD.request()
        return web.json_response({"ok": ok})
    elif job == "tracking":
        run_job("tracking", H.install_tracking)
    elif job == "ai":
        run_job("ai", H.install_ai, body.get("model") or load_config().get("ai_model") or "qwen2.5:3b")
    elif job == "shortcuts":
        run_job("shortcuts", H.create_shortcuts)
    elif job == "autostart":
        cfg = load_config()
        for k in ("camera_autostart", "msfs_open_window"):
            if k in body:
                cfg[k] = bool(body[k])
        save_config(cfg)
        if "background" in body:
            return web.json_response(await asyncio.to_thread(H.set_startup, bool(body["background"])))
        if "enable" in body:
            return web.json_response(await asyncio.to_thread(H.msfs_autostart, bool(body["enable"])))
        return web.json_response({"ok": True})
    elif job == "update_check":
        return web.json_response(await asyncio.to_thread(H.check_update))
    elif job == "update_apply":
        res = await asyncio.to_thread(H.apply_update, body.get("zip", ""))
        if res.get("ok"):
            asyncio.get_running_loop().call_later(0.8, restart_app)
        return web.json_response(res)
    elif job == "update_url":
        cfg = load_config()
        cfg["update_url"] = str(body.get("url", "")).strip()
        save_config(cfg)
        return web.json_response({"ok": True})
    else:
        raise web.HTTPNotFound()
    return web.json_response({"ok": True, "started": True})


async def api_pushback(request):
    body = await request.json()
    if body.get("action") == "stop":
        PUSH.stop("Detenido")
        return web.json_response({"ok": True})
    tel = get_telemetry()
    if tel["mode"] != "sim" or not SIM.live:
        return web.json_response({"ok": False, "error": "El pushback necesita MSFS abierto y conectado"})
    try:
        ok, msg = PUSH.start(float(body["lat"]), float(body["lon"]), float(body["heading"]), tel["data"])
    except (KeyError, TypeError, ValueError):
        return web.json_response({"ok": False, "error": "Datos no válidos"})
    return web.json_response({"ok": ok, "error": None if ok else msg, "msg": msg})


async def api_auto_status(_):
    return web.json_response(JOBS)


# ---------------------------------------------------------------- IA local gratis (Ollama)
import aiohttp
from urllib.parse import urlencode

OLLAMA = "http://127.0.0.1:11434"
AI_MODELS = {"qwen2.5:3b": "Rápida (2 GB) · recomendada", "qwen2.5:1.5b": "Muy rápida (1 GB) · menos precisa",
             "qwen2.5:7b": "Más lista pero LENTA (4,7 GB) · solo con buena gráfica"}


def ai_warmup(model):
    """Carga el modelo con LAS MISMAS opciones que el chat (si no, Ollama lo recarga y tarda)
    y deja el prompt del sistema ya procesado en caché."""
    try:
        body = {"model": model, "stream": False, "keep_alive": "60m",
                "messages": [{"role": "system", "content": AI_SYSTEM}, {"role": "user", "content": "hola"}],
                "options": {"temperature": 0.4, "num_ctx": 2048, "num_predict": 1, "top_k": 30}}
        req = urllib.request.Request(OLLAMA + "/api/chat", data=json.dumps(body).encode(), headers={"Content-Type": "application/json"})
        urllib.request.urlopen(req, timeout=180).read()
        with urllib.request.urlopen(OLLAMA + "/api/ps", timeout=5) as r:
            for m in json.loads(r.read()).get("models", []):
                gpu = m.get("size_vram", 0) / max(1, m.get("size", 1)) * 100
                print(f"[OK] SimCopilot listo: {m.get('name')} ({gpu:.0f}% en la tarjeta gráfica)", flush=True)
    except Exception as exc:  # noqa: BLE001
        print(f"[i] SimCopilot precarga: {exc}", flush=True)


AI_SYSTEM = """Eres «SimCopilot 1.1», el copiloto de SimDirect (app para Microsoft Flight Simulator 2024). Respondes SIEMPRE en español, breve (máximo 6-8 frases), cercano y claro. Eres experto en aviación y simulación.
REGLAS: nunca escribas código, JSON, tablas ni bloques ``` ; solo texto normal (puedes usar **negrita** y listas con guiones). Los planes de vuelo los genera la app automáticamente y aparecen como tarjeta con botón «Poner en Plan»: tú solo los comentas, nunca escribas coordenadas.
La app tiene: Plan (salida/llegada, checkpoints en el mapa, altitudes, combustible, T/D, exportar .pln, SID/STAR), Vuelo (datos en directo), FMC (FPLN, PERF de despegue V1/VR/V2/FLEX, APPR VREF/VAPP), Checklists, Peso (pasajeros, carga, combustible), Pushback (marcas en el mapa dónde te deja), Anuncios de cabina, Skies (tiempo, atmósfera, luz y hora con presets de cielo), Ajustes (cámara y ReShade), Configurar (instalaciones y actualizaciones) y jugadores online en el mapa (MSFS, VATSIM, IVAO).
Glosario: T/D = Top of Descent (inicio del descenso); T/C = Top of Climb; V1 decisión; VR rotación; V2 seguridad; VREF referencia de aterrizaje; VAPP = VREF + viento; FLEX empuje reducido; ZFW sin combustible; TOW al despegue; LW al aterrizaje; SID salida; STAR llegada; FL nivel de vuelo. No inventes funciones."""


async def ai_status(_):
    try:
        async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=2)) as cs:
            async with cs.get(OLLAMA + "/api/tags") as r:
                tags = await r.json()
        models = [m["name"] for m in tags.get("models", [])]
        running = True
    except Exception:  # noqa: BLE001
        models, running = [], False
    cfg = load_config()
    model = cfg.get("ai_model") or next((m for m in models if m in AI_MODELS), models[0] if models else "qwen2.5:3b")
    installed = running or bool(H.find_ollama())
    return web.json_response({"running": running, "installed": installed, "models": models,
                              "model": model, "choices": AI_MODELS})


async def ai_chat(request):
    body = await request.json()
    cfg = load_config()
    model = body.get("model") or cfg.get("ai_model") or "qwen2.5:3b"
    ctx = str(body.get("context", ""))[:600]
    hist = [m for m in body.get("messages", []) if m.get("role") in ("user", "assistant")][-4:]
    last = str(hist[-1].get("content", "")) if hist else ""
    resp = web.StreamResponse(headers={"Content-Type": "text/plain; charset=utf-8", "Cache-Control": "no-cache"})
    await resp.prepare(request)
    # 1) planes reales calculados por la app al instante
    plans = None
    try:
        import copilot_plans as CP
        plans = await asyncio.get_running_loop().run_in_executor(None, CP.plans_from_text, last)
        if plans:
            nav = None
            if SIM.live:
                import msfs_nav
                nav = msfs_nav.fetch_airport
            plans = await asyncio.to_thread(CP.add_procedures, plans, nav)
    except Exception as exc:  # noqa: BLE001
        print(f"[!] SimCopilot rutas: {exc}", flush=True)
    sysmsg = AI_SYSTEM + ("\nSituación: " + ctx if ctx else "")
    predict = 450
    if plans:
        for p in plans:
            dist = p.pop("_dist", 0)
            await resp.write(("```plan\n" + json.dumps(p, ensure_ascii=False) + "\n```\n").encode("utf-8"))
        def _d(p):
            pr, inf = p.get("proc", {}), p.get("procInfo", {})
            t = (f"{p['dep']['name']} ({p['dep']['code']}) a {p['arr']['name']} ({p['arr']['code']}), crucero {p['cruiseAlt']} ft, "
                 f"{'avioneta' if p['aircraft'] == 'c172' else 'avión de línea'}")
            if pr.get("depRwy"):
                t += f", despegue pista {pr['depRwy']} ({inf.get('depWhy')})"
            if pr.get("sid"):
                t += f", SID {pr['sid']}"
            if pr.get("star"):
                t += f", STAR {pr['star']}"
            if pr.get("appr"):
                t += f", aproximación {pr['appr']}"
            if pr.get("arrRwy"):
                t += f", aterrizaje pista {pr['arrRwy']} ({inf.get('arrWhy')})"
            return t
        desc = "; ".join(_d(p) for p in plans)
        nosim = not any(p.get("procInfo", {}).get("msfs") for p in plans) and plans[0]["aircraft"] != "c172"
        sysmsg += ("\nLa app YA ha creado estos planes y el usuario los ve como tarjetas: " + desc +
                   ". Coméntalos en 2-4 frases: di SIEMPRE las pistas de despegue y aterrizaje y, si las hay, la SID, la STAR y la aproximación "
                   "exactamente con esos nombres (no inventes otros), y da algún consejo. No escribas coordenadas ni código."
                   + (" No hay SID/STAR porque MSFS está cerrado: dile que si abre MSFS 2024 y lo vuelve a pedir, saldrán las reales." if nosim else ""))
        predict = 200
    msgs = [{"role": "system", "content": sysmsg}]
    for m in hist:
        c = re.sub(r"```[\s\S]*?(```|$)", "", str(m.get("content", "")))[:1200]
        msgs.append({"role": m["role"], "content": c})
    try:
        async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=300)) as cs:
            async with cs.post(OLLAMA + "/api/chat", json={
                    "model": model, "messages": msgs, "stream": True, "keep_alive": "60m",
                    "options": {"temperature": 0.4, "num_ctx": 2048, "num_predict": predict, "top_k": 30}}) as r:
                if r.status != 200:
                    await resp.write(f"\n(La IA no respondió: {r.status})".encode())
                async for line in r.content:
                    try:
                        j = json.loads(line)
                    except ValueError:
                        continue
                    piece = j.get("message", {}).get("content", "")
                    if piece:
                        await resp.write(piece.encode("utf-8"))
                    if j.get("done"):
                        break
    except Exception as exc:  # noqa: BLE001
        if not plans:
            await resp.write(f"\n(No pude hablar con la IA local: {exc})".encode())
    await resp.write_eof()
    return resp


async def ai_model(request):
    body = await request.json()
    cfg = load_config()
    cfg["ai_model"] = str(body.get("model", "qwen2.5:3b"))
    cfg["ai_model_user"] = True
    save_config(cfg)
    threading.Thread(target=ai_warmup, args=(cfg["ai_model"],), daemon=True).start()
    return web.json_response({"ok": True})


# ---------------------------------------------------------------- Perfil / inicio de sesión con Steam
STEAM_OPENID = "https://steamcommunity.com/openid/login"


async def auth_steam(request):
    base = f"http://{request.host}"
    params = {
        "openid.ns": "http://specs.openid.net/auth/2.0",
        "openid.mode": "checkid_setup",
        "openid.return_to": base + "/auth/steam/callback",
        "openid.realm": base + "/",
        "openid.identity": "http://specs.openid.net/auth/2.0/identifier_select",
        "openid.claimed_id": "http://specs.openid.net/auth/2.0/identifier_select",
    }
    raise web.HTTPFound(STEAM_OPENID + "?" + urlencode(params))


async def auth_steam_callback(request):
    q = dict(request.query)
    if q.get("openid.mode") != "id_res":
        raise web.HTTPFound("/auth/done?login=cancel")
    check = dict(q)
    check["openid.mode"] = "check_authentication"
    try:
        async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=15)) as cs:
            async with cs.post(STEAM_OPENID, data=check) as r:
                ok = "is_valid:true" in await r.text()
            m = re.search(r"/openid/id/(\d+)$", q.get("openid.claimed_id", ""))
            if not ok or not m:
                raise web.HTTPFound("/auth/done?login=error")
            sid = m.group(1)
            name, avatar = "Piloto de Steam", ""
            try:
                async with cs.get(f"https://steamcommunity.com/profiles/{sid}/?xml=1") as r2:
                    xml = await r2.text()
                n = re.search(r"<steamID><!\[CDATA\[(.*?)\]\]></steamID>", xml, re.S)
                a = re.search(r"<avatarFull><!\[CDATA\[(.*?)\]\]></avatarFull>", xml, re.S)
                name = n.group(1) if n else name
                avatar = a.group(1) if a else ""
            except Exception:  # noqa: BLE001
                pass
    except web.HTTPException:
        raise
    except Exception:  # noqa: BLE001
        raise web.HTTPFound("/auth/done?login=error")
    cfg = load_config()
    prof = cfg.get("profile", {})
    prof.update({"provider": "steam", "steam_id": sid, "name": name, "avatar": avatar})
    cfg["profile"] = prof
    save_config(cfg)
    raise web.HTTPFound("/auth/done?login=ok")


# ---------------------------------------------------------------- Google y Microsoft/Xbox (OAuth con PKCE)
import base64
import hashlib
import secrets

_oauth = {}   # state -> {verifier, provider, t}


def _pkce():
    v = secrets.token_urlsafe(64)
    c = base64.urlsafe_b64encode(hashlib.sha256(v.encode()).digest()).rstrip(b"=").decode()
    return v, c


def _save_profile(**kw):
    cfg = load_config()
    prof = cfg.get("profile", {})
    prof.update({k: v for k, v in kw.items() if v})
    cfg["profile"] = prof
    save_config(cfg)


def _jwt_claims(tok):
    try:
        part = tok.split(".")[1]
        return json.loads(base64.urlsafe_b64decode(part + "=" * (-len(part) % 4)))
    except Exception:  # noqa: BLE001
        return {}


async def auth_google(request):
    cfg = load_config()
    cid = cfg.get("google_client_id")
    if not cid:
        raise web.HTTPFound("/auth/done?login=noconfig_google")
    state = secrets.token_urlsafe(16)
    v, c = _pkce()
    _oauth[state] = {"verifier": v, "provider": "google", "t": time.time()}
    params = {"client_id": cid, "redirect_uri": f"http://{request.host}/auth/google/callback", "response_type": "code",
              "scope": "openid email profile", "state": state, "code_challenge": c, "code_challenge_method": "S256",
              "prompt": "select_account"}
    raise web.HTTPFound("https://accounts.google.com/o/oauth2/v2/auth?" + urlencode(params))


async def auth_google_cb(request):
    st = _oauth.pop(request.query.get("state", ""), None)
    code = request.query.get("code")
    if not st or not code:
        raise web.HTTPFound("/auth/done?login=cancel")
    cfg = load_config()
    data = {"code": code, "client_id": cfg.get("google_client_id"), "client_secret": cfg.get("google_client_secret", ""),
            "redirect_uri": f"http://{request.host}/auth/google/callback", "grant_type": "authorization_code",
            "code_verifier": st["verifier"]}
    try:
        async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=20)) as cs:
            async with cs.post("https://oauth2.googleapis.com/token", data=data) as r:
                tok = await r.json()
        claims = _jwt_claims(tok.get("id_token", ""))
        if not claims.get("email"):
            raise ValueError(tok.get("error_description") or tok.get("error") or "sin datos")
    except Exception as exc:  # noqa: BLE001
        print(f"[!] Google: {exc}", flush=True)
        raise web.HTTPFound("/auth/done?login=error")
    _save_profile(provider="google", name=claims.get("name") or claims["email"].split("@")[0],
                  email=claims.get("email"), avatar=claims.get("picture", ""))
    raise web.HTTPFound("/auth/done?login=ok_google")


async def auth_ms(request):
    cfg = load_config()
    cid = cfg.get("ms_client_id")
    if not cid:
        raise web.HTTPFound("/auth/done?login=noconfig_xbox")
    state = secrets.token_urlsafe(16)
    v, c = _pkce()
    _oauth[state] = {"verifier": v, "provider": "xbox", "t": time.time()}
    params = {"client_id": cid, "redirect_uri": f"http://localhost:{PORT}/auth/xbox/callback", "response_type": "code",
              "scope": "XboxLive.signin offline_access", "state": state, "code_challenge": c,
              "code_challenge_method": "S256", "prompt": "select_account"}
    raise web.HTTPFound("https://login.microsoftonline.com/consumers/oauth2/v2.0/authorize?" + urlencode(params))


async def auth_ms_cb(request):
    st = _oauth.pop(request.query.get("state", ""), None)
    code = request.query.get("code")
    if not st or not code:
        raise web.HTTPFound("/auth/done?login=cancel")
    cfg = load_config()
    try:
        async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=25)) as cs:
            async with cs.post("https://login.microsoftonline.com/consumers/oauth2/v2.0/token", data={
                    "client_id": cfg.get("ms_client_id"), "code": code, "grant_type": "authorization_code",
                    "redirect_uri": f"http://localhost:{PORT}/auth/xbox/callback", "code_verifier": st["verifier"],
                    "scope": "XboxLive.signin offline_access"}) as r:
                tok = await r.json()
            at = tok.get("access_token")
            if not at:
                raise ValueError(tok.get("error_description") or "sin token")
            async with cs.post("https://user.auth.xboxlive.com/user/authenticate", json={
                    "Properties": {"AuthMethod": "RPS", "SiteName": "user.auth.xboxlive.com", "RpsTicket": "d=" + at},
                    "RelyingParty": "http://auth.xboxlive.com", "TokenType": "JWT"},
                    headers={"x-xbl-contract-version": "1"}) as r:
                xbl = await r.json()
            async with cs.post("https://xsts.auth.xboxlive.com/xsts/authorize", json={
                    "Properties": {"SandboxId": "RETAIL", "UserTokens": [xbl["Token"]]},
                    "RelyingParty": "http://xboxlive.com", "TokenType": "JWT"},
                    headers={"x-xbl-contract-version": "1"}) as r:
                xsts = await r.json()
            xui = xsts["DisplayClaims"]["xui"][0]
            gamertag, uhs = xui.get("gtg", "Jugador de Xbox"), xui.get("uhs")
            avatar = ""
            try:
                async with cs.get("https://profile.xboxlive.com/users/me/profile/settings?settings=GameDisplayPicRaw",
                                  headers={"Authorization": f"XBL3.0 x={uhs};{xsts['Token']}", "x-xbl-contract-version": "2"}) as r:
                    pj = await r.json()
                avatar = pj["profileUsers"][0]["settings"][0]["value"]
            except Exception:  # noqa: BLE001
                pass
    except Exception as exc:  # noqa: BLE001
        print(f"[!] Xbox: {exc}", flush=True)
        raise web.HTTPFound("/auth/done?login=error")
    _save_profile(provider="xbox", name=gamertag, avatar=avatar)
    raise web.HTTPFound("/auth/done?login=ok_xbox")


async def auth_discord(request):
    cfg = load_config()
    cid = cfg.get("discord_client_id")
    if not cid:
        raise web.HTTPFound("/auth/done?login=noconfig_discord")
    state = secrets.token_urlsafe(16)
    _oauth[state] = {"provider": "discord", "t": time.time()}
    params = {"client_id": cid, "redirect_uri": f"http://localhost:{PORT}/auth/discord/callback", "response_type": "code",
              "scope": "identify email", "state": state, "prompt": "consent"}
    raise web.HTTPFound("https://discord.com/oauth2/authorize?" + urlencode(params))


async def auth_discord_cb(request):
    st = _oauth.pop(request.query.get("state", ""), None)
    code = request.query.get("code")
    if not st or not code:
        raise web.HTTPFound("/auth/done?login=cancel")
    cfg = load_config()
    try:
        async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=20)) as cs:
            async with cs.post("https://discord.com/api/oauth2/token", data={
                    "client_id": cfg.get("discord_client_id"), "client_secret": cfg.get("discord_client_secret", ""),
                    "grant_type": "authorization_code", "code": code,
                    "redirect_uri": f"http://localhost:{PORT}/auth/discord/callback"}) as r:
                tok = await r.json()
            at = tok.get("access_token")
            if not at:
                raise ValueError(tok.get("error_description") or tok.get("error") or "sin token")
            async with cs.get("https://discord.com/api/users/@me", headers={"Authorization": f"Bearer {at}"}) as r:
                me = await r.json()
    except Exception as exc:  # noqa: BLE001
        print(f"[!] Discord: {exc}", flush=True)
        raise web.HTTPFound("/auth/done?login=error")
    avatar = f"https://cdn.discordapp.com/avatars/{me['id']}/{me['avatar']}.png?size=128" if me.get("avatar") else ""
    _save_profile(provider="discord", name=me.get("global_name") or me.get("username"), email=me.get("email", ""), avatar=avatar)
    raise web.HTTPFound("/auth/done?login=ok_discord")


AUTH_MSG = {"ok": "Sesión iniciada con Steam", "ok_google": "Sesión iniciada con Google", "ok_xbox": "Sesión iniciada con Xbox",
            "ok_discord": "Sesión iniciada con Discord", "cancel": "Inicio de sesión cancelado"}


async def auth_done(request):
    code = request.query.get("login", "error")
    ok = code.startswith("ok")
    msg = AUTH_MSG.get(code, "Primero actívalo en tu perfil de SimDirect" if code.startswith("noconfig") else "No se pudo iniciar sesión")
    html = f"""<!doctype html><meta charset="utf-8"><title>SimDirect</title>
<body style="margin:0;height:100vh;display:grid;place-items:center;background:#0a0f15;color:#e4ecf4;font:16px system-ui">
<div style="text-align:center"><img src="/logo.svg" width="110"><h2>{'✔' if ok else '✖'} {msg}</h2>
<p style="color:#8197ab">Ya puedes cerrar esta pestaña y volver a SimDirect.</p></div>
<script>setTimeout(()=>window.close(),2500)</script></body>"""
    return web.Response(text=html, content_type="text/html")


async def auth_open(request):
    """Abre el inicio de sesión en el navegador normal del usuario (no dentro de la app)."""
    prov = (await request.json()).get("provider", "")
    if prov not in ("steam", "google", "xbox", "discord"):
        raise web.HTTPBadRequest()
    import webbrowser
    webbrowser.open(f"http://localhost:{PORT}/auth/{prov}")
    return web.json_response({"ok": True})


async def auth_config(request):
    body = await request.json()
    cfg = load_config()
    for k in ("google_client_id", "google_client_secret", "ms_client_id", "discord_client_id", "discord_client_secret"):
        if k in body:
            cfg[k] = str(body[k]).strip()
    save_config(cfg)
    return web.json_response({"ok": True})


async def auth_status(_):
    cfg = load_config()
    return web.json_response({"google": bool(cfg.get("google_client_id")), "xbox": bool(cfg.get("ms_client_id")),
                              "discord": bool(cfg.get("discord_client_id") and cfg.get("discord_client_secret"))})


async def profile_get(_):
    return web.json_response(load_config().get("profile") or {})


async def profile_set(request):
    body = await request.json()
    cfg = load_config()
    if body.get("logout"):
        cfg.pop("profile", None)
    else:
        prof = cfg.get("profile", {})
        for k in ("name", "email", "airline", "callsign", "home", "avatar"):
            if k in body:
                prof[k] = str(body[k])[:200]
        prof.setdefault("provider", "local")
        cfg["profile"] = prof
    save_config(cfg)
    return web.json_response({"ok": True, "profile": cfg.get("profile") or {}})


# ---------------------------------------------------------------- Aeropuertos, pistas y procedimientos
import aeropuertos as AP


async def api_chart(request):
    try:
        s_, w, n, e = (float(x) for x in request.query.get("bbox", "").split(","))
        z = int(float(request.query.get("z", 6)))
    except ValueError:
        return web.json_response({"airports": [], "navaids": []})
    return web.json_response(await asyncio.to_thread(AP.chart, s_, w, n, e, z))


async def api_airport(request):
    code = request.match_info["icao"].upper()[:8]
    base = await asyncio.to_thread(AP.airport, code)
    out = base or {"code": code, "runways": []}
    out["sids"], out["stars"], out["approaches"], out["source"] = [], [], [], "ourairports" if base else None
    if SIM.live:
        try:
            import msfs_nav
            nav = await asyncio.to_thread(msfs_nav.fetch_airport, code)
            out["sids"], out["stars"], out["approaches"] = nav["sids"], nav["stars"], nav["approaches"]
            out["source"] = "msfs"
            if not out.get("lat") and nav.get("lat") is not None:
                out.update(lat=nav["lat"], lon=nav["lon"], elev=round((nav.get("alt_m") or 0) * 3.281), name=code)
            if nav["runways"] and not out["runways"]:
                out["runways"] = nav["runways"]
            out["msfs_runways"] = nav["runways"]
        except Exception as exc:  # noqa: BLE001
            out["nav_error"] = str(exc)
    if not out.get("lat"):
        return web.json_response({"ok": False, "error": f"No encuentro el aeropuerto {code}"})
    out["ok"] = True
    return web.json_response(out)


async def api_airport_search(request):
    return web.json_response(await asyncio.to_thread(AP.search, request.query.get("q", "")))


# ---------------------------------------------------------------- Cine (vídeos tipo película)
import cine as CINE


async def cine_state(_):
    st = CINE.studio().state()
    st["recordings"] = await asyncio.to_thread(CINE.list_recordings)
    st["sim"] = bool(SIM.live)
    return web.json_response(st)


def _cine_collector():
    while True:
        try:
            if CINE.collect_videos():
                print(f"[{time.strftime('%H:%M:%S')}] Cine: vídeo nuevo guardado en Cine\\Videos", flush=True)
        except Exception:  # noqa: BLE001
            pass
        time.sleep(15)


threading.Thread(target=_cine_collector, daemon=True).start()


async def cine_videos(_):
    await asyncio.to_thread(CINE.collect_videos)
    return web.json_response({"videos": await asyncio.to_thread(CINE.list_videos),
                              "dirs": [str(d) for d in CINE.video_dirs()]})


async def cine_video_file(request):
    p = CINE.find_video(request.match_info["name"])
    if not p:
        raise web.HTTPNotFound()
    return web.FileResponse(p, headers={"Cache-Control": "no-cache"})


async def cine_action(request):
    b = await request.json()
    S = CINE.studio()
    act = b.get("action")
    try:
        if act == "rec_start":
            ok = await asyncio.to_thread(S.rec_start, str(b.get("title", ""))[:60])
        elif act == "rec_stop":
            ok = bool(await asyncio.to_thread(S.rec_stop))
        elif act == "play":
            ok = await asyncio.to_thread(S.play_start, str(b["name"]), float(b.get("t", 0)), float(b.get("speed", 1)))
        elif act == "control":
            ok = S.play_control(b.get("paused"), b.get("speed"), b.get("t"))
        elif act == "stop":
            ok = await asyncio.to_thread(S.play_stop, bool(b.get("restore", True)))
        elif act == "shot":
            ok = await asyncio.to_thread(S.shot, str(b.get("shot")))
        elif act == "auto":
            ok = await asyncio.to_thread(S.set_auto, bool(b.get("on")), b.get("interval"))
        elif act == "video":
            ok = bool(S.video_toggle())
        elif act == "delete":
            ok = S.delete(str(b.get("name")))
        elif act == "video_delete":
            p = CINE.find_video(str(b.get("name", "")))
            ok = bool(p)
            if p:
                await asyncio.to_thread(p.unlink)
            return web.json_response({"ok": ok, "msg": "Vídeo borrado" if ok else "No lo encuentro"})
        elif act == "video_folder":
            p = CINE.find_video(str(b.get("name", "")))
            CINE.ensure_dirs()
            d = p.parent if p else (CINE.CINE_DIR if b.get("root") else CINE.VID_DIR)
            ok = bool(d)
            if d and sys.platform == "win32":
                if p:
                    subprocess.Popen(["explorer", "/select,", str(p)])
                else:
                    os.startfile(str(d))  # noqa: S606
            return web.json_response({"ok": ok, "msg": "Carpeta abierta" if ok else "No se pudo abrir"})
        else:
            return web.json_response({"ok": False, "error": "acción desconocida"})
        return web.json_response({"ok": bool(ok), "msg": S.msg})
    except Exception as exc:  # noqa: BLE001
        msg = str(exc)
        if "no está abierto" in msg or "SimConnect" in msg or "WinError" in msg:
            msg = "Abre MSFS 2024 y entra en un vuelo para usar el modo Cine"
        return web.json_response({"ok": False, "error": msg})


# ---------------------------------------------------------------- Sonidos (suenan con el avión)
async def snd_settings(request):
    if request.method == "POST":
        await asyncio.to_thread(SND.save_settings, await request.json())
    return web.json_response(SND.settings())


async def snd_play(request):
    b = await request.json()
    if b.get("key"):
        SND.announce(b["key"], sound_ctx(get_telemetry()["data"] or {}))
    elif b.get("chime"):
        s = SND.settings()
        SND.PLAYER.q.put(lambda: SND.play_chime(b["chime"], s))
    elif b.get("fx"):
        SND.effect(b["fx"], 0.6)
    return web.json_response({"ok": True})


async def snd_stop(_):
    SND.PLAYER.stop()
    return web.json_response({"ok": True})


async def snd_reset(_):
    SND.ENGINE.reset()
    return web.json_response({"ok": True})


async def snd_voices(_):
    def voices():
        try:
            import comtypes
            import comtypes.client
            comtypes.CoInitialize()
            v = comtypes.client.CreateObject("SAPI.SpVoice")
            toks = v.GetVoices()
            return [toks.Item(i).GetDescription() for i in range(toks.Count)]
        except Exception:  # noqa: BLE001
            return []
    return web.json_response(await asyncio.to_thread(voices))


# ---------------------------------------------------------------- Jugadores online (VATSIM / IVAO)
import trayectos as TR

_traffic = {"vatsim": (0, []), "ivao": (0, [])}


async def _fetch_traffic(net):
    t, data = _traffic[net]
    if time.time() - t < 14:
        return data
    url = {"vatsim": "https://data.vatsim.net/v3/vatsim-data.json",
           "ivao": "https://api.ivao.aero/v2/tracker/whazzup"}[net]
    out = []
    try:
        async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=15)) as cs:
            try:
                async with cs.get(url, headers={"User-Agent": "SimDirect/1.0"}) as r:
                    j = await r.json(content_type=None)
            except aiohttp.ClientConnectorCertificateError:
                # datos públicos de solo lectura: si su certificado caduca, se leen igualmente
                async with cs.get(url, headers={"User-Agent": "SimDirect/1.0"}, ssl=False) as r:
                    j = await r.json(content_type=None)
        try:
            ATCM.ONLINE[net] = ATCM.parse_vatsim_controllers(j) if net == "vatsim" else ATCM.parse_ivao_controllers(j)
        except Exception:  # noqa: BLE001
            pass
        if net == "vatsim":
            for p in j.get("pilots", []):
                fp = p.get("flight_plan") or {}
                out.append({"cs": p.get("callsign"), "lat": p.get("latitude"), "lon": p.get("longitude"),
                            "alt": p.get("altitude"), "gs": p.get("groundspeed"), "hdg": p.get("heading"),
                            "ac": fp.get("aircraft_short", ""), "dep": fp.get("departure", ""), "arr": fp.get("arrival", ""),
                            "net": "vatsim"})
        else:
            for p in (j.get("clients") or {}).get("pilots", []):
                tr = p.get("lastTrack") or {}
                fp = p.get("flightPlan") or {}
                out.append({"cs": p.get("callsign"), "lat": tr.get("latitude"), "lon": tr.get("longitude"),
                            "alt": tr.get("altitude"), "gs": tr.get("groundSpeed"), "hdg": tr.get("heading"),
                            "ac": fp.get("aircraftId", ""), "dep": fp.get("departureId", ""), "arr": fp.get("arrivalId", ""),
                            "net": "ivao"})
        out = [x for x in out if x["lat"] is not None and x["lon"] is not None]
        _traffic[net] = (time.time(), out)
        await asyncio.to_thread(TR.record, out)
    except Exception as exc:  # noqa: BLE001
        print(f"[!] Tráfico {net}: {exc}", flush=True)
        _traffic[net] = (time.time() - 10, data)
        return data
    return out


async def api_traffic(request):
    try:
        s_, w, n, e = (float(x) for x in request.query.get("bbox", "-90,-180,90,180").split(","))
    except ValueError:
        s_, w, n, e = -90, -180, 90, 180
    nets = request.query.get("nets", "msfs,vatsim,ivao").split(",")
    res = []
    if "msfs" in nets and SIM.live:
        try:
            import msfs_traffic
            mp = await asyncio.to_thread(msfs_traffic.fetch, 200000, 4.0, 8 if PERF["on"] else 4)
            TR.record(mp)
            res += mp
        except Exception as exc:  # noqa: BLE001
            print(f"[!] Tráfico MSFS: {exc}", flush=True)
    for net in ("vatsim", "ivao"):
        if net in nets:
            for p in await _fetch_traffic(net):
                if s_ <= p["lat"] <= n and (w <= p["lon"] <= e if w <= e else (p["lon"] >= w or p["lon"] <= e)):
                    res.append(p)
    return web.json_response({"count": len(res), "pilots": res[:800]})


async def traffic_recorder():
    """Graba en segundo plano el recorrido de los jugadores mientras «Jugadores online» está activado."""
    await asyncio.sleep(5)
    while True:
        try:
            cfg = load_config()
            ATC_NET["net"] = cfg.get("atc_net")
            if ATC_NET["net"] in ("vatsim", "ivao") and SIM.live and time.time() - _traffic[ATC_NET["net"]][0] > 60:
                await _fetch_traffic(ATC_NET["net"])      # controladores conectados para la radio
            if cfg.get("traffic_on"):
                nets = cfg.get("traffic_nets") or ["msfs", "vatsim", "ivao"]
                for net in ("vatsim", "ivao"):
                    if net in nets:
                        await _fetch_traffic(net)
                if "msfs" in nets and SIM.live and time.time() - getattr(traffic_recorder, "t_msfs", 0) >= (15 if PERF["on"] else 5):
                    traffic_recorder.t_msfs = time.time()
                    import msfs_traffic
                    TR.record(await asyncio.to_thread(msfs_traffic.fetch, 200000, 4.0, 8 if PERF["on"] else 4))
        except Exception as exc:  # noqa: BLE001
            print(f"[!] Grabando recorridos: {exc}", flush=True)
        await asyncio.sleep(5)


ATC_NET = {"net": None}


async def api_atc_net(request):
    b = await request.json()
    net = b.get("net") if b.get("net") in ("vatsim", "ivao") else None
    cfg = load_config()
    cfg["atc_net"] = net
    save_config(cfg)
    ATC_NET["net"] = net
    ATC.t = 0
    if net:
        asyncio.create_task(_fetch_traffic(net))
    return web.json_response({"ok": True, "net": net})


async def api_atc_com(request):
    b = await request.json()
    try:
        mhz = float(b.get("mhz"))
    except (TypeError, ValueError):
        return web.json_response({"ok": False, "error": "Frecuencia no válida"})
    if not 118 <= mhz < 137:
        return web.json_response({"ok": False, "error": "Fuera de la banda de COM"})
    if not SIM.live:
        return web.json_response({"ok": False, "error": "Entra en un vuelo de MSFS"})
    EVENTS.put(("COM_STBY_RADIO_SET_HZ", int(round(mhz * 1_000_000))))
    if b.get("swap"):
        EVENTS.put(("COM_STBY_RADIO_SWAP", 0))
    return web.json_response({"ok": True, "msg": f"{mhz:.3f} en COM1 {'activa' if b.get('swap') else 'standby'}"})


async def api_atc_airport(request):
    code = request.match_info["code"].upper()[:8]
    return web.json_response({"airport": code, "list": await asyncio.to_thread(ATCM.freqs_for, code, ATC_NET["net"])})


PERF = {"on": RP.enabled()}


async def api_perf_get(_):
    return web.json_response({"on": PERF["on"]})


async def api_perf_set(request):
    b = await request.json()
    on = bool(b.get("on"))
    cfg = load_config()
    cfg["perf_mode"] = on
    save_config(cfg)
    PERF["on"] = on
    RP.set_priority(on)
    def _rs():
        d = cfg.get("msfs_dir")
        return bool(d and (Path(d) / "ReShade.ini").exists() and H.ensure_reshade_ini(d))
    if await asyncio.to_thread(_rs):
        RS_RELOAD.request()
    return web.json_response({"ok": True, "on": on})


async def api_dlss_get(_):
    cfg = load_config()
    st = await asyncio.to_thread(DL.status)
    return web.json_response({**st, "on": bool(cfg.get("dlss_auto")), "mode": cfg.get("dlss_mode") or "QUALITY"})


async def api_dlss_set(request):
    b = await request.json()
    cfg = load_config()
    on = bool(b.get("on"))
    mode = b.get("mode") if b.get("mode") in DL.MODES else (cfg.get("dlss_mode") or "QUALITY")
    cfg["dlss_auto"], cfg["dlss_mode"] = on, mode
    save_config(cfg)
    if not on:
        return web.json_response({"ok": True, "on": False, "msg": "DLSS automático desactivado"})
    ok, msg = await asyncio.to_thread(DL.apply, mode)
    return web.json_response({"ok": ok, "on": True, "mode": mode, "msg": msg})


async def api_traffic_on(request):
    b = await request.json()
    cfg = load_config()
    cfg["traffic_on"] = bool(b.get("on"))
    if isinstance(b.get("nets"), list):
        cfg["traffic_nets"] = [n for n in b["nets"] if n in ("msfs", "vatsim", "ivao")]
    save_config(cfg)
    return web.json_response({"ok": True})


async def api_traffic_track(request):
    net, cs = request.query.get("net", ""), request.query.get("cs", "")
    t = TR.get(net, cs)
    if not t:
        return web.json_response({"pts": [], "dep": None, "arr": None})
    def _apt(code):
        if not code:
            return None
        try:
            a = AP.airport(code)
        except Exception:  # noqa: BLE001
            a = None
        return {"code": code, "lat": a["lat"], "lon": a["lon"]} if a and a.get("lat") is not None else None
    dep, arr = await asyncio.to_thread(_apt, t["dep"]), await asyncio.to_thread(_apt, t["arr"])
    return web.json_response({"pts": t["pts"], "dep": dep, "arr": arr, "since": t["since"], "now": int(time.time())})


# ---------------------------------------------------------------- Skies (tiempo, atmósfera y luz)
import skies as SKY


def _rs_user():
    try:
        return {**RS_DEFAULTS, **json.loads(RS_FILE.read_text(encoding="utf-8"))}
    except (OSError, ValueError):
        return dict(RS_DEFAULTS)


def _skies_msfs():
    st = setup_status()
    return st["msfs_dir"] if st["reshade"] else None


def _skies_event(name, val):
    EVENTS.put((name, val))


async def skies_state(_):
    def _st():
        return {"state": SKY.load_state(), "presets": SKY.load_presets(), "sim": bool(SIM.live),
                "weather_dirs": [str(d) for d in SKY.weather_dirs()], "reshade": bool(_skies_msfs())}
    return web.json_response(await asyncio.to_thread(_st))


async def skies_apply(request):
    b = await request.json()
    parts = b.get("parts") or {}
    parts = {k: bool(parts.get(k, True)) for k in ("weather", "look", "time")}
    def _do():
        return SKY.apply(b.get("values"), SKY.safe_name(b.get("name")), parts, _skies_msfs(), _rs_user(),
                         _skies_event, bool(SIM.live))
    res = await asyncio.to_thread(_do)
    if res.get("look"):
        RS_RELOAD.request()
    print(time.strftime("[%H:%M:%S]"), "Skies:", " | ".join(res["msgs"]), flush=True)
    return web.json_response(res)


async def skies_reset(_):
    res = await asyncio.to_thread(lambda: SKY.reset(_skies_msfs()))
    RS_RELOAD.request()
    return web.json_response(res)


async def skies_presets(request):
    b = await request.json()
    return web.json_response({"ok": True, "presets": await asyncio.to_thread(SKY.save_presets, b.get("presets"))})


async def skies_auto(request):
    b = await request.json()
    st = await asyncio.to_thread(SKY.save_state, auto=bool(b.get("auto")))
    return web.json_response({"ok": True, "auto": st["auto"]})


def skies_on_connect():
    """Al entrar en un vuelo: si «Cargar al volar» está activo, vuelve a poner la imagen y la hora."""
    try:
        st = SKY.load_state()
        if not st.get("auto") or not st.get("applied"):
            return
        time.sleep(4)
        res = SKY.apply(st.get("values"), st.get("name"), {"weather": True, "look": True, "time": True},
                        _skies_msfs(), _rs_user(), _skies_event, True)
        if res.get("look"):
            RS_RELOAD.request()
        print(time.strftime("[%H:%M:%S]"), "Skies al volar:", " | ".join(res["msgs"]), flush=True)
    except Exception as exc:  # noqa: BLE001
        print(f"[!] Skies: {exc}", flush=True)


# ---------------------------------------------------------------- Diario de vuelos
async def diario_list(_):
    return web.json_response(await asyncio.to_thread(DI.list_flights))


async def diario_get(request):
    r = await asyncio.to_thread(DI.get_flight, request.match_info["id"][:20])
    return web.json_response(r or {"error": "No existe"}, status=200 if r else 404)


async def diario_delete(request):
    return web.json_response({"ok": await asyncio.to_thread(DI.delete_flight, request.match_info["id"][:20])})


# ---------------------------------------------------------------- Plan del avión
async def simplan_state(_):
    return web.json_response({**PA.PLAN.status(), "sim": bool(SIM.live)})


async def simplan_read(_):
    if not SIM.live:
        return web.json_response({"ok": False, "msg": "Entra en un vuelo de MSFS para leer el plan del avión"})
    PA.PLAN.request()
    return web.json_response({"ok": True, "msg": "Leyendo el plan del avión…"})


_loop = None
_runner = None


def restart_app():
    """Reinicia SimDirect tras una actualización (la ventana abierta se recarga sola)."""
    import subprocess as sp
    try:
        TR.save(force=True)
    except Exception:  # noqa: BLE001
        pass
    exe = Path(sys.executable)
    pyw = exe.with_name("pythonw.exe") if exe.with_name("pythonw.exe").exists() else exe
    try:
        sp.Popen([str(pyw), str(BASE / "SimDirect.pyw"), "--restart"], cwd=str(BASE),
                 creationflags=getattr(sp, "DETACHED_PROCESS", 0) | getattr(sp, "CREATE_NEW_PROCESS_GROUP", 0))
    finally:
        os._exit(0)


def shutdown():
    try:
        TR.save(force=True)
    except Exception:  # noqa: BLE001
        pass
    if _loop and _loop.is_running():
        _loop.call_soon_threadsafe(_loop.stop)


def build_app():
    app = web.Application(middlewares=[no_cache])
    app.on_startup.append(on_startup)
    app.router.add_get("/", index)
    app.router.add_get("/index.html", index)
    app.router.add_get("/ws", ws_handler)
    app.router.add_get("/api/plans", list_plans)
    app.router.add_get("/api/plans/{name}", get_plan)
    app.router.add_post("/api/plans", save_plan)
    app.router.add_delete("/api/plans/{name}", delete_plan)
    app.router.add_post("/api/export-pln", export_pln)
    app.router.add_get("/api/setup/status", api_setup_status)
    app.router.add_post("/api/setup/msfs", api_setup_msfs)
    app.router.add_post("/api/setup/done", api_setup_done)
    app.router.add_post("/api/setup/copy-presets", api_copy_presets)
    app.router.add_post("/api/setup/open", api_open)
    app.router.add_post("/api/camera", api_camera)
    app.router.add_post("/api/camera/settings", api_camera_settings)
    app.router.add_get("/api/reshade", api_reshade_get)
    app.router.add_post("/api/reshade", api_reshade_set)
    app.router.add_get("/api/sounds", api_sounds)
    app.router.add_post("/api/auto/{job}", api_auto)
    app.router.add_get("/api/auto/status", api_auto_status)
    app.router.add_post("/api/pushback", api_pushback)
    app.router.add_get("/api/ai/status", ai_status)
    app.router.add_route("*", "/api/sound/settings", snd_settings)
    app.router.add_post("/api/sound/play", snd_play)
    app.router.add_post("/api/sound/stop", snd_stop)
    app.router.add_post("/api/sound/reset", snd_reset)
    app.router.add_get("/api/sound/voices", snd_voices)
    app.router.add_get("/api/airport/{icao}", api_airport)
    app.router.add_get("/api/chart", api_chart)
    app.router.add_get("/api/traffic", api_traffic)
    app.router.add_get("/api/traffic/track", api_traffic_track)
    app.router.add_post("/api/traffic/on", api_traffic_on)
    app.router.add_get("/api/perf", api_perf_get)
    app.router.add_post("/api/perf", api_perf_set)
    app.router.add_get("/api/dlss", api_dlss_get)
    app.router.add_post("/api/dlss", api_dlss_set)
    app.router.add_post("/api/atc/net", api_atc_net)
    app.router.add_post("/api/atc/com", api_atc_com)
    app.router.add_get("/api/atc/airport/{code}", api_atc_airport)
    app.router.add_get("/api/cine", cine_state)
    app.router.add_get("/api/skies", skies_state)
    app.router.add_get("/api/simplan", simplan_state)
    app.router.add_get("/api/diario", diario_list)
    app.router.add_get("/api/diario/{id}", diario_get)
    app.router.add_delete("/api/diario/{id}", diario_delete)
    app.router.add_post("/api/simplan/read", simplan_read)
    app.router.add_post("/api/skies/apply", skies_apply)
    app.router.add_post("/api/skies/reset", skies_reset)
    app.router.add_post("/api/skies/presets", skies_presets)
    app.router.add_post("/api/skies/auto", skies_auto)
    app.router.add_post("/api/cine", cine_action)
    app.router.add_get("/api/cine/videos", cine_videos)
    app.router.add_get("/api/cine/video/{name}", cine_video_file)
    app.router.add_get("/api/airports/search", api_airport_search)
    app.router.add_post("/api/ai/chat", ai_chat)
    app.router.add_post("/api/ai/model", ai_model)
    app.router.add_get("/auth/steam", auth_steam)
    app.router.add_get("/auth/steam/callback", auth_steam_callback)
    app.router.add_get("/api/profile", profile_get)
    app.router.add_get("/auth/google", auth_google)
    app.router.add_get("/auth/google/callback", auth_google_cb)
    app.router.add_get("/auth/xbox", auth_ms)
    app.router.add_get("/auth/xbox/callback", auth_ms_cb)
    app.router.add_get("/auth/discord", auth_discord)
    app.router.add_get("/auth/discord/callback", auth_discord_cb)
    app.router.add_post("/api/auth/config", auth_config)
    app.router.add_get("/auth/done", auth_done)
    app.router.add_post("/api/auth/open", auth_open)
    app.router.add_get("/api/auth/status", auth_status)
    app.router.add_post("/api/profile", profile_set)
    SOUNDS_DIR.mkdir(exist_ok=True)
    app.router.add_static("/sonidos/", SOUNDS_DIR)
    app.on_cleanup.append(on_cleanup)
    app.router.add_static("/", WEB_DIR)
    return app


def main(open_browser=True):
    global _loop, _runner
    print("=" * 56)
    print(f"  SimDirect {H.app_version()} para MSFS 2024")
    print(f"  En este PC:        http://localhost:{PORT}")
    print(f"  Móvil / tablet:    http://{local_ip()}:{PORT}")
    print("=" * 56, flush=True)
    _loop = asyncio.new_event_loop()
    asyncio.set_event_loop(_loop)
    _runner = web.AppRunner(build_app())
    _loop.run_until_complete(_runner.setup())
    _loop.run_until_complete(web.TCPSite(_runner, "0.0.0.0", PORT).start())
    if open_browser:
        threading.Timer(1.0, lambda: webbrowser.open(f"http://localhost:{PORT}")).start()
    try:
        _loop.run_forever()
    except KeyboardInterrupt:
        pass
    finally:
        _loop.run_until_complete(_runner.cleanup())


if __name__ == "__main__":
    main()
