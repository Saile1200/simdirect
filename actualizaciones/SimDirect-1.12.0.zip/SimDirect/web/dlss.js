'use strict';
/* DLSS automático (Ajustes) */
(() => {
  const box = document.getElementById('dlssOn'); if (!box) return;
  const mode = document.getElementById('dlssMode');
  const gpu = document.getElementById('dlssGpu');
  const wrap = box.closest('.perf-box');
  async function load() {
    try {
      const r = await (await fetch('/api/dlss')).json();
      box.checked = !!r.on; mode.value = r.mode || 'QUALITY';
      gpu.textContent = r.nvidia ? `(${r.gpu})` : '(necesita una NVIDIA RTX)';
      box.disabled = mode.disabled = !r.nvidia && !r.on;
      wrap.classList.toggle('off', !r.nvidia);
    } catch (e) { gpu.textContent = ''; }
  }
  async function save() {
    try {
      const r = await post('/api/dlss', { on: box.checked, mode: mode.value });
      toast((r.ok ? '🟢 ' : '') + r.msg, 4200);
    } catch (e) { toast('Sin conexión con SimDirect'); }
  }
  box.onchange = save;
  mode.onchange = () => { if (box.checked) save(); };
  document.querySelectorAll('.tab[data-tab="adjust"]').forEach((t) => t.addEventListener('click', load));
  setTimeout(load, 2500);
})();
